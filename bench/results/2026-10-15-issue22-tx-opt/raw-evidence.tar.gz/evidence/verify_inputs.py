from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path(__file__).resolve().parent;repo=r.parents[2]
j=lambda name:json.loads((r/name).read_text())
checked=0
for name,sha in j('evidence-sha256.json').items():
 assert hashlib.sha256((r/name).read_bytes()).hexdigest()==sha,name
 checked+=1
inputs=j('inputs-sha256.json');count=0
with tarfile.open(r/'inputs.tar.gz','r:gz') as t:
 for v,files in inputs.items():
  for rel,sha in files.items():
   data=t.extractfile(v+'/'+rel).read();assert hashlib.sha256(data).hexdigest()==sha,(v,rel)
   if v=='D' and rel.startswith('src/'):
    original=subprocess.run(['git','show','c2ae50439e50c081940b951bd075a6ce4bb41335:'+rel],cwd=repo,capture_output=True,check=True).stdout
    assert data==original,(v,rel,'not main')
   if v in ['F','F2'] and rel.startswith('src/'):assert data==(repo/rel).read_bytes(),(v,rel,'not worktree')
   count+=1
 assert t.extractfile('P1/src/budget.rs').read()==(r/'budget-p1.rs').read_bytes()
assert inputs['F']==inputs['F2'],'independent sources differ'
for rel,sha in inputs['D'].items():
 if rel in ['Cargo.toml','Cargo.lock','bench/Cargo.toml','examples/pareto_probe.rs'] or rel.startswith('bench/src/'):
  for v in ['P1','F','F2']:assert inputs[v][rel]==sha,(v,rel,'nonuniform harness/lock/probe')
for rel,sha in inputs['P1'].items():
 if rel.startswith('src/') and rel!='src/budget.rs':assert sha==inputs['D'][rel],rel
bins=j('binary-manifest.json')
for name in ['micro','ablation','large']:
 meta=j(name+'-meta.json')
 for v,sha in meta['binary_sha256'].items():
  base='/root/zfverify22-20261015' if v in ['B','D'] else '/root/zfopt22-20261015'
  assert bins[f'{base}/target-{v}/release/examples/pareto_probe']==sha,(name,v)
for v,b in j('network-meta.json')['binaries'].items():assert bins[b['path']]==b['sha256'],v
env=j('environment-after.json')
assert not env['test_processes']['stdout'].strip(),env['test_processes']
assert 'zfbns' not in env['namespaces']['stdout']
assert 'zfbA' not in env['links']['stdout'] and 'zfbB' not in env['links']['stdout']
assert '1.96.0' in env['default_rustc']['stdout'],env['default_rustc']
assert not env['governors'],'unexpected cpufreq interface'
assert subprocess.run(['git','diff','--','src/budget.rs','src/buf.rs'],cwd=repo,capture_output=True,check=True).stdout==(r/'candidate.patch').read_bytes()
assert 'Finished' in (r/'clippy-linux.log').read_text()
assert 'Finished' in (r/'no-default-linux.log').read_text()
print(f'Validated {checked} evidence hashes, {count} archived input files; main/source/patch and independent builds match; uniform lock/probe/harness; all measured binary hashes match; Linux lint/build completed; cleanup and original default Rust checked.')
