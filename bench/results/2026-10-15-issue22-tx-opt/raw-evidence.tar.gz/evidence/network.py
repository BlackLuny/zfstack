from pathlib import Path
import subprocess,json,time,hashlib
r=Path('/root/zfopt22-20261015')
bins={'D':Path('/root/zfverify22-20261015/target-D/release/zfbench'),'F':r/'target-F/release/zfbench'}
common=['--stack','zfstack-cubic','--client-cc','cubic','--seed','1']
cases=[
 ('mixed64',12,['--test','mixed','--rtt-ms','12','--queue-bdp','2','--rr-size','64','--secs','6','--warmup','1','--idle-rr-secs','2','--rr-interval-ms','5']),
 ('connect1000',12,['--test','connect','--rtt-ms','12','--conns','4000','--concurrency','1000']),
 ('down8',5,['--test','down','--rate-mbps','0','--rtt-ms','1','--queue-bytes','67108864','--flows','8','--secs','6','--warmup','1']),
 ('up8',5,['--test','up','--rate-mbps','0','--rtt-ms','1','--queue-bytes','67108864','--flows','8','--secs','6','--warmup','1']),
]
assert not Path('/sys/class/net/zfbA').exists(),'TUN name already in use'
meta={'cases':cases,'common':common,'affinity':'0-3','warmup_pairs':1,'mtu':1420,'up8_tun_tx_queue_len':100000,'binaries':{v:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for v,p in bins.items()},'started':time.time()}
(r/'network-meta.json').write_text(json.dumps(meta,indent=2))
def cleanup():subprocess.run([str(bins['F']),'--cleanup'],check=True,capture_output=True,timeout=30)
with (r/'network.jsonl').open('x',buffering=1) as out:
 try:
  for ci,(case,reps,args) in enumerate(cases):
   for rep in range(-1,reps):
    for v in (['D','F'] if (ci+rep)%2==0 else ['F','D']):
     cleanup();cmd=['taskset','-c','0-3',str(bins[v]),*common,*args];start=time.time();p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
     try:
      deadline=time.monotonic()+5;flags=Path('/sys/class/net/zfbA/flags')
      while time.monotonic()<deadline:
       try:up=bool(int(flags.read_text().strip(),16)&1)
       except FileNotFoundError:up=False
       try:queue_ready=int(Path('/sys/class/net/zfbA/tx_queue_len').read_text())==10000
       except FileNotFoundError:queue_ready=False
       if up and queue_ready:
        ready_qdisc=subprocess.run(['tc','qdisc','show','dev','zfbA'],capture_output=True,text=True,check=True).stdout
        if 'pfifo' in ready_qdisc and 'limit 10000p' in ready_qdisc:break
       if p.poll() is not None:raise RuntimeError('benchmark exited before TUN up')
       time.sleep(.001)
      else:raise RuntimeError('TUN did not finish setup (UP and qlen10000)')
      if case=='up8':subprocess.run(['ip','link','set','dev','zfbA','txqueuelen','100000'],check=True)
      actual=int(Path('/sys/class/net/zfbA/tx_queue_len').read_text());assert actual==(100000 if case=='up8' else 10000),actual
      qdisc=subprocess.run(['tc','qdisc','show','dev','zfbA'],capture_output=True,text=True,check=True).stdout
      stdout,stderr=p.communicate(timeout=180)
     except BaseException:p.kill();p.communicate();raise
     m=json.loads(stdout);row={'case':case,'rep':rep,'warmup':rep<0,'variant':v,'command':cmd,'started':start,'elapsed':time.time()-start,'exit_code':p.returncode,'measurement':m,'stdout':stdout,'stderr':stderr,'tun_tx_queue_len':actual,'qdisc':qdisc,'loadavg':Path('/proc/loadavg').read_text()}
     out.write(json.dumps(row)+'\n');print(case,rep,v,p.returncode,m['ok'],flush=True)
     assert p.returncode==0 and m['ok'] and not m['errors']
     assert m['server_app']['pattern_errors']==m['server_app']['bad_headers']==0
     if case.startswith('connect'):assert m['results']['success']==m['results']['attempted']==4000 and not m['results']['failures']
 finally:cleanup()
meta['finished']=time.time();(r/'network-meta.json').write_text(json.dumps(meta,indent=2));print('ALL_DONE',flush=True)
