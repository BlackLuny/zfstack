#!/usr/bin/env python3
import json,subprocess,random,time,hashlib,os
from pathlib import Path
r=Path('/root/zfopt22-20261015')
variants=['B','D','F','F2']; cases=[]
for mode in ['tx-alloc','tx-alloc-pooled','tx-alloc-migrate']:
 for size in [1,64,512,1400,4096,65536]:
  n=min(2000000,max(20000,134217728//size))
  cases.append({'name':f'{mode}_{size}','args':[mode,'--iterations',str(n),'--payload',str(size)]})
for name,args in [
 ('budget',['budget','--iterations','3000000','--flows','8','--payload','2112']),
 ('budget_handle',['budget-handle','--iterations','3000000','--flows','8','--payload','2112']),
 ('rx64',['rx-chunk','--iterations','1000000','--flows','8','--payload','64']),
 ('heap_pop',['heap-pop','--iterations','10000','--flows','4096']),
 ('down8',['pump-down','--iterations','2','--flows','8','--payload','4194304']),
 ('up8',['pump-up','--iterations','2','--flows','8','--payload','4194304']),
 ('short64',['pump-bidi','--iterations','20','--flows','64','--payload','4096','--no-pacing']),
 ('short256',['pump-bidi','--iterations','5','--flows','256','--payload','4096','--no-pacing']),
 ('up256',['pump-up','--iterations','1','--flows','256','--payload','262144']),
]: cases.append({'name':name,'args':args})
(r/'cases.json').write_text(json.dumps(cases,indent=2))
bins={v:(r if v in ['F','F2'] else Path('/root/zfverify22-20261015'))/f'target-{v}/release/examples/pareto_probe' for v in variants}
hashes={v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in bins.items()}
meta={'versions':json.loads((r/'versions.json').read_text()),'pairs':12,'warmup_blocks':1,'affinity':'3','binary_sha256':hashes,'cases':cases,'order':'deterministic shuffled complete blocks seed=122+case*100+block','started':time.time()}
(r/'micro-meta.json').write_text(json.dumps(meta,indent=2))
with (r/'micro.jsonl').open('x',buffering=1) as out:
 for ci,case in enumerate(cases):
  for rep in range(-1,12):
   order=variants.copy();random.Random(122+ci*100+rep).shuffle(order)
   for pos,v in enumerate(order):
    cmd=['taskset','-c','3',str(bins[v]),*case['args']]
    before=Path('/proc/stat').read_text().splitlines()[:9];start=time.time()
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
    row={'case':case['name'],'rep':rep,'warmup':rep<0,'variant':v,'position':pos,'command':cmd,'binary_sha256':hashes[v],'exit_code':p.returncode,'started':start,'elapsed':time.time()-start,'stdout':p.stdout,'stderr':p.stderr,'proc_stat_before':before,'loadavg':Path('/proc/loadavg').read_text()}
    try: row['measurement']=json.loads(p.stdout)
    except: row['measurement']=None
    out.write(json.dumps(row)+'\n')
    m=row['measurement']
    if p.returncode or not m or not m['ok'] or m['checksum_u64']!=m['expected_checksum_u64'] or m['final_reserved_bytes']!=0:
     raise RuntimeError(f'Invalid {case["name"]} {v} {rep}: {p.stderr}')
   print(case['name'],rep,'done',flush=True)
meta['finished']=time.time();(r/'micro-meta.json').write_text(json.dumps(meta,indent=2))
