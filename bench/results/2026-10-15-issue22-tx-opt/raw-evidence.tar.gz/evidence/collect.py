from pathlib import Path
import subprocess,json,hashlib,time,tarfile
r=Path('/root/zfopt22-20261015');old=Path('/root/zfverify22-20261015')
commands={'uname':['uname','-a'],'cpu':['lscpu'],'namespaces':['ip','netns','list'],'links':['ip','-br','link'],'test_processes':['ps','-C','zfbench','-C','pareto_probe','-o','pid=,comm='],'default_rustc':['/root/.cargo/bin/rustc','-V'],'rustup':['/root/.cargo/bin/rustup','--version']}
env={'captured_at':time.time(),'loadavg':Path('/proc/loadavg').read_text(),'meminfo':Path('/proc/meminfo').read_text(),'governors':{str(p):p.read_text().strip() for p in Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_governor')}}
for k,cmd in commands.items():
 p=subprocess.run(cmd,capture_output=True,text=True);env[k]={'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(r/'environment-after.json').write_text(json.dumps(env,indent=2))
inputs={}
roots={v:(old if v in ['B','D'] else r)/v for v in ['B','D','P1','F','F2']}
with tarfile.open(r/'inputs.tar.gz','w:gz') as archive:
 for v,p in roots.items():
  inputs[v]={}
  for sub in ['Cargo.toml','Cargo.lock','src','tests','examples','bench/src','bench/Cargo.toml','bench/README.md']:
   base=p/sub
   if not base.exists():continue
   archive.add(base,arcname=v+'/'+sub)
   for f in ([base] if base.is_file() else sorted(base.rglob('*'))):
    if f.is_file():inputs[v][str(f.relative_to(p))]=hashlib.sha256(f.read_bytes()).hexdigest()
(r/'inputs-sha256.json').write_text(json.dumps(inputs,indent=2))
binaries={}
for v,p in roots.items():
 parent=p.parent;b=parent/f'target-{v}/release/examples/pareto_probe';binaries[str(b)]=hashlib.sha256(b.read_bytes()).hexdigest()
for v in ['D','F']:
 b=roots[v].parent/f'target-{v}/release/zfbench';binaries[str(b)]=hashlib.sha256(b.read_bytes()).hexdigest()
(r/'binary-manifest.json').write_text(json.dumps(binaries,indent=2))
files=[p for p in r.iterdir() if p.is_file() and p.name not in ['evidence-sha256.json','post-checks.log'] and p.suffix in ['.json','.jsonl','.log','.txt','.py','.sh','.patch','.gz']]
(r/'evidence-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},indent=2))
print('Collected',len(files),'evidence files; process list:',repr(env['test_processes']['stdout']))
