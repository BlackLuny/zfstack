#!/bin/bash
set -euo pipefail
r=/root/zfopt22-20261015
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_PANIC=abort CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
cp -a "$r/F" "$r/F2"
rustup run 1.92.0 rustc -Vv > "$r/rustc.txt"
for v in F F2; do
 cargo +1.92.0 build --locked --release --features tokio,test-peer --example pareto_probe --manifest-path "$r/$v/Cargo.toml" --target-dir "$r/target-$v" > "$r/build-$v.log" 2>&1
 if [[ $v == F ]]; then
  cargo +1.92.0 build --locked --release -p zfbench --manifest-path "$r/$v/Cargo.toml" --target-dir "$r/target-$v" >> "$r/build-$v.log" 2>&1
  cargo +1.92.0 test --locked --release -p zfstack --features tokio,test-peer --manifest-path "$r/$v/Cargo.toml" --target-dir "$r/target-test" > "$r/test-F.log" 2>&1
  cargo +1.92.0 test --locked --release -p zfstack --features tokio,test-peer --manifest-path "$r/$v/Cargo.toml" --target-dir "$r/target-test" issue37_splice_256_streams_keep_progressing_with_delayed_acks -- --ignored > "$r/test-256.log" 2>&1
 fi
 echo "$v ready"
done
sha256sum "$r"/target-{F,F2}/release/examples/pareto_probe "$r"/target-F/release/zfbench > "$r/binary-sha256.txt"
python3 "$r/measure.py" > "$r/micro.log" 2>&1
