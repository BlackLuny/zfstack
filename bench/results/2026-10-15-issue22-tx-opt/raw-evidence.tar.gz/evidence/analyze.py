from pathlib import Path
import json,statistics as S,random,collections,hashlib
r=Path(__file__).resolve().parent

def paired(a,b):
 vals=[(y/x-1)*100 for x,y in zip(a,b)]
 rng=random.Random(22);boot=sorted(S.median(rng.choices(vals,k=len(vals))) for _ in range(5000))
 return {'n':len(vals),'median':S.median(vals),'ci95':[boot[125],boot[4875]],'values':vals}
def get(x,path):
 for k in path.split('.'):x=x[k]
 return x
def analyze_micro(name,variants):
 meta=json.loads((r/(name+'-meta.json')).read_text());assert 'finished' in meta
 rows=[json.loads(l) for l in (r/(name+'.jsonl')).read_text().splitlines()];g=collections.defaultdict(dict);seen=set()
 for row in rows:
  key=(row['case'],row['rep'],row['variant']);assert key not in seen;seen.add(key)
  assert row['warmup']==(row['rep']<0)
  m=row['measurement'];assert row['exit_code']==0 and m['ok'] and m['checksum_u64']==m['expected_checksum_u64'] and m['final_reserved_bytes']==0,key
  assert row['binary_sha256']==meta['binary_sha256'][row['variant']]
  g[(row['case'],row['rep'])][row['variant']]=m
 for key,v in g.items():
  assert set(v)==set(variants),(key,v.keys())
  for f in ['operations','effective_bytes','allocation_requested_bytes','checksum_u64','expected_checksum_u64','connections_checked']:
   assert len({m[f] for m in v.values()})==1,(key,f)
  if key[0].startswith('tx-alloc'):
   for f in ['warmup_reserved_bytes','retained_reserved_bytes_before_drop']:
    assert len({m[f] for k,m in v.items() if k!='B'})==1,(key,f)
 assert len(rows)==len(meta['cases'])*(meta['pairs']+1)*len(variants)
 assert seen=={(c['name'],rep,v) for c in meta['cases'] for rep in range(-1,meta['pairs']) for v in variants}
 out={}
 for case in sorted({key[0] for key in g}):
  groups=[v for (c,rep),v in sorted(g.items()) if c==case and rep>=0];assert len(groups)==meta['pairs']
  entry={'n':len(groups),'ns_per_op':{},'comparisons':{},'ledger':{}}
  for v in variants:
   entry['ns_per_op'][v]=S.median(p[v]['work_cpu_ns_per_operation'] for p in groups)
   entry['ledger'][v]={f:S.median(p[v][f] for p in groups) for f in ['warmup_reserved_bytes','retained_reserved_bytes_before_drop'] if groups[0][v][f] is not None}
  comparisons=([('B','D'),('D','F'),('B','F'),('F','F2')] if 'B' in variants else ([('D','P1'),('P1','F'),('D','F'),('F','F2')] if 'F2' in variants else [('D','P1'),('P1','F'),('D','F')]))
  for a,b in comparisons:entry['comparisons'][b+'/'+a]=paired([p[a]['work_cpu_ns'] for p in groups],[p[b]['work_cpu_ns'] for p in groups])
  out[case]=entry
 return {'rows':len(rows),'cases':out}

out={'micro':analyze_micro('micro',['B','D','F','F2'])}
if (r/'ablation.jsonl').exists():out['ablation']=analyze_micro('ablation',['D','P1','F'])
if (r/'large.jsonl').exists():
 out['large_followup']=analyze_micro('large',['D','P1','F','F2'])
 out['large_combined']={}
 for c,e in out['large_followup']['cases'].items():
  out['large_combined'][c]={}
  for k in ['F/D','F2/F']:
   vals=out['micro']['cases'][c]['comparisons'][k]['values']+e['comparisons'][k]['values']
   out['large_combined'][c][k]=paired([100.0]*len(vals),[100+v for v in vals])
if (r/'network.jsonl').exists():
 meta=json.loads((r/'network-meta.json').read_text());assert 'finished' in meta
 rows=[json.loads(l) for l in (r/'network.jsonl').read_text().splitlines()];g=collections.defaultdict(dict);seen=set();connections=0
 for row in rows:
  key=(row['case'],row['rep'],row['variant']);assert key not in seen;seen.add(key)
  m=row['measurement'];assert row['exit_code']==0 and m['ok'] and not m['errors']
  assert m['server_app']['pattern_errors']==m['server_app']['bad_headers']==0
  assert m['link']['softnet_backlog_drops']==0
  assert all(m['link']['tun_a'][f]==0 for f in ['qdisc_drops','rx_dropped','tx_dropped']),(key,m['link']['tun_a'])
  if row['case']=='connect1000':
   assert m['results']['success']==m['results']['attempted']==4000 and not m['results']['failures']
   if not row['warmup']:connections+=4000
  g[(row['case'],row['rep'])][row['variant']]=m
 assert len(rows)==sum((n+1)*2 for _,n,_ in meta['cases'])
 assert seen=={(c,rep,v) for c,n,_ in meta['cases'] for rep in range(-1,n) for v in ['D','F']}
 for key,vs in g.items():assert set(vs)=={'D','F'}
 net={}
 for case,reps,_ in meta['cases']:
  groups=[v for (c,rep),v in sorted(g.items()) if c==case and rep>=0];assert len(groups)==reps
  fields=['results.goodput_mbps_window','cpu.cpu_sec_per_effective_GB','cpu.stack_thread_window_sec'] if case in ['down8','up8'] else (['results.rr_loaded.p50_ms','results.rr_loaded.p99_ms','results.rr_loaded.p999_ms'] if case=='mixed64' else ['results.latency_connect.p50_ms','results.latency_connect.p99_ms','results.latency_total.p999_ms'])
  net[case]={'n':reps,'D':{},'F':{},'F/D':{}}
  for f in fields:
   vals={v:[get(p[v],f) for p in groups] for v in ['D','F']}
   for v in vals:net[case][v][f]=S.median(vals[v])
   if all(x>0 for a in vals.values() for x in a):net[case]['F/D'][f]=paired(vals['D'],vals['F'])
 out['network']={'rows':len(rows),'formal_successful_connections':connections,'cases':net}
(r/'summary.json').write_text(json.dumps(out,indent=2))
for c,e in out['micro']['cases'].items():
 print(c,' '.join(f'{k}: {x["median"]:+.2f}% [{x["ci95"][0]:+.2f},{x["ci95"][1]:+.2f}]' for k,x in e['comparisons'].items()))
for c,e in out.get('network',{}).get('cases',{}).items():
 print(c,{f:{k:round(v,3) if isinstance(v,float) else v for k,v in x.items() if k!='values'} for f,x in e['F/D'].items()})
print('Validated micro:',out['micro']['rows'],'ablation:',out.get('ablation',{}).get('rows'),'large:',out.get('large_followup',{}).get('rows'),'network:',out.get('network',{}).get('rows','not yet analyzed'))
