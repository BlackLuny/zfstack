#!/bin/bash
set -euo pipefail
r=/root/zfopt22-20261015
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/.rustup CARGO_BUILD_JOBS=1
rustup run stable rustc -Vv > "$r/lint-rustc.txt"
cargo +stable clippy --locked --workspace --all-targets --features zfstack/tokio --manifest-path "$r/F/Cargo.toml" --target-dir "$r/target-lint" > "$r/clippy-linux.log" 2>&1
cargo +stable build --locked -p zfstack --no-default-features --manifest-path "$r/F/Cargo.toml" --target-dir "$r/target-lint" > "$r/no-default-linux.log" 2>&1
sha256sum --check "$r/binary-sha256.txt" > "$r/binary-check.txt"
python3 "$r/collect.py"
