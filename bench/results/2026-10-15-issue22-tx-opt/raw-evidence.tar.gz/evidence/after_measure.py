from pathlib import Path
import json,time,subprocess
r=Path('/root/zfopt22-20261015');deadline=time.monotonic()+1800
while True:
 try:
  m=json.loads((r/'micro-meta.json').read_text())
  if 'finished' in m:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.monotonic()>deadline:raise RuntimeError('micro did not complete')
 time.sleep(2)
for name in ['ablation','network']:
 with (r/(name+'.log')).open('x') as out:subprocess.run(['python3',str(r/(name+'.py'))],stdout=out,stderr=subprocess.STDOUT,check=True)
 print(name,'finished',flush=True)
