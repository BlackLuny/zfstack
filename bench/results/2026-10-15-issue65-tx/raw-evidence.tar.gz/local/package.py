"""Package raw evidence without committing hundreds of generated log files."""
from pathlib import Path
import tarfile,gzip,hashlib,json
r=Path(__file__).resolve().parent
curated=['.gitignore','.gitattributes','README.md','summary.json','qualification.json','cpu-table.csv','network-summary.json','network-connect-confirmation-summary.json','network-bulk-confirmation-summary.json','current-quota-layout.json','allocation-table.csv','allocation-summary.json','allocation_table.py','source-proof.json','inputs-sha256.json','binary-manifest.json','environment-after.json','tx-owner.png','tx-owner.pdf','zf65-current-quota-summary.json','zf65-current-quota-report.md','qa-current-quota-evidence.tar.gz','inputs.tar.gz','analyze.py','network_current_quota_analyze.py','qualify.py','plot.py','replay_stats.py','raw-evidence.tar.gz','SHA256SUMS']
remote_names=set()
with (r/'raw-evidence.tar.gz').open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as out:
 with tarfile.open(r/'raw-remote.tar.gz') as old:
  for m in old.getmembers():
   assert m.isfile() and m.name.startswith('remote/') and '..' not in Path(m.name).parts
   remote_names.add(Path(m.name).name);out.addfile(m,old.extractfile(m))
 for p in sorted(r.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=p.relative_to(r)
  if len(rel.parts)==1 and (p.name in curated or p.name in remote_names or p.name in ['raw-remote.tar.gz','report_draft.md','README-draft.md','report-tables.md','.gitignore']):continue
  if p.suffix not in ['.json','.jsonl','.py','.sh','.txt','.log','.rs','.md','.gz']:continue
  m=out.gettarinfo(str(p),'local/'+str(rel));m.uid=m.gid=0;m.uname=m.gname='';m.mtime=0
  with p.open('rb') as src:out.addfile(m,src)
assert all((r/f).exists() for f in curated if f!='SHA256SUMS')
(r/'.gitignore').write_text('*\n'+''.join('!'+f+'\n' for f in curated))
(r/'SHA256SUMS').write_text(''.join(hashlib.sha256((r/f).read_bytes()).hexdigest()+'  '+f+'\n' for f in sorted(curated) if f!='SHA256SUMS'))
print('Curated:',len(curated),'files; raw archive', (r/'raw-evidence.tar.gz').stat().st_size,'bytes')
