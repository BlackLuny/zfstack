"""Generate report fragments from validated, final-arm summaries."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent;s=json.loads((r/'summary.json').read_text());out=[]
def ci(v):return f"{v['median_pct']:+.2f}% [{v['ci95_pct'][0]:+.2f}, {v['ci95_pct'][1]:+.2f}]"
out+=['| API / 窗口 | 场景 | T CPU ns/op | U CPU ns/op | U/T 配对变化 [95% CI] |','|---|---|---:|---:|---:|']
for api in ['push','write']:
 for w in [1,2]:
  e=s[f'current-quota-{api}-window{w}']['cases']
  for case,label in [('tx-alloc_64','64B cache0'),('tx-alloc-migrate_64','64B 交替 peer'),('tx-alloc-pooled_64','64B 同 peer 缓存'),('tx-alloc-migrate_65536','64KiB 交替 peer')]:
   v=e[case];out.append(f"| {api} / {w} | {label} | {v['ns_per_op']['T']:.2f} | {v['ns_per_op']['U']:.2f} | {ci(v['comparisons']['U/T'])} |")
out+=['','完整 96 个 API/窗口/case 的 CPU/op、CPU/byte、独立构建 A/A 与区间见 `cpu-table.csv`；CPU/byte 由每操作字节数换算，不另行计时。CPU probe 的时间包括完整逐字节校验及 checksum，因此不能将 CPU/op 当作纯写入函数耗时。','']
for name in ['current-quota-pump-guards','current-quota-f56-context','current-quota-write-tiny-long-window1','current-quota-write-tiny-long-window2','current-quota-pump-long-window1','current-quota-pump-long-window2']:
 if name not in s:continue
 out+=['### '+name,'','| 场景 | 对照 | 配对变化 [95% CI] |','|---|---|---:|']
 for case,e in s[name]['cases'].items():
  for comp,v in e['comparisons'].items():out.append(f'| {case} | {comp} | {ci(v)} |')
 out.append('')
if (r/'network-summary.json').exists():
 n=json.loads((r/'network-summary.json').read_text());out+=['### socket/TUN','', '| 场景 | 指标 | T 中位数 | U 中位数 | 配对变化 [95% CI] |','|---|---|---:|---:|---:|']
 for case,metrics in n.items():
  for field,v in metrics.items():out.append(f"| {case} | {field} | {v['T_median']:.5g} | {v['U_median']:.5g} | {ci(v)} |")
(r/'report-tables.md').write_text('\n'.join(out)+'\n')
