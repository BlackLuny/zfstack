# QA PASS

Tested SHA: `3ae01f6fc685d7ff1ec92fcd0212f08cbcb95771`
Coverage: 17/17 required instances.
Plan: `6198773265c5b5b988ac2f16552b12c42e5efe222f0128aadd0bf80424097c6a`

| Case | Layer | Functional | Validity | Performance |
|---|---|---|---|---|
| QA-no-default | CORE | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-core | CORE | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-adapter | A1 | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-adapter-directed | A0 | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-budget-directed | A1 | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-harness | L0-C | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-tools | META | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-l2-tools | META | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-perf-tools | META | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-coverage | META | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-features | CORE | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-l0-eager | L0-C | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-l0-event-only | L0-E | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-replay-external-owner | L0-E | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-replay-network-recovery | L0-E | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-replay-scripted-arrivals | L0-E | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |
| QA-replay-sink-recovery | L0-E | PASS | functional=VALID, performance=UNKNOWN | NOT_APPLICABLE |

## Replay and input identities

Use the original frozen plan and tested checkout. Each attempt needs a new output directory; integration/performance also require the same reviewed node inputs and physical-domain lease.

```sh
python -m qa run-plan --plan plan.json --output qa/results/new-attempt
```

| Case | Build manifest | Environment | Configuration |
|---|---|---|---|
| QA-no-default | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-core | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-adapter | eb5d59a3d0e991cc40ab144f54041c850c99fa9e1027430d7a27e165e25e35e3 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-adapter-directed | eb5d59a3d0e991cc40ab144f54041c850c99fa9e1027430d7a27e165e25e35e3 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-budget-directed | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-harness | 92885a7c95962519b9ff7e9dd210a79a46a46a1dd43fe23e5365e53a3f08ad53 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-tools | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-l2-tools | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-perf-tools | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-coverage | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-features | 62915fe2be704da88ecc51222142bbe7fb4a88951dc18cf85ef6b7a8cd2fe013 | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a |
| QA-l0-eager | 6b8f38fedb4a08e651b38252f8463719978bea5a9f8bfd4c246e5b4ddee2e9ef | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | c95caec0358a961e290345d155343ea659f02d5accc50f807dbedd472ed7a1b6 |
| QA-l0-event-only | 6b8f38fedb4a08e651b38252f8463719978bea5a9f8bfd4c246e5b4ddee2e9ef | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 85a9e192a062d81f5794eb0c321dfdad31f30f86fb3a2f5b82d586a3b28f6b6e |
| QA-replay-external-owner | 6b8f38fedb4a08e651b38252f8463719978bea5a9f8bfd4c246e5b4ddee2e9ef | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 372b35d433ff998f50a5023a19043c031fe584e42569c9e3073045d2abb542de |
| QA-replay-network-recovery | 6b8f38fedb4a08e651b38252f8463719978bea5a9f8bfd4c246e5b4ddee2e9ef | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 12b10e38992ba6c698d030f9786f1529a5ca8eca8cb1d23ea779c229d7a5b5a9 |
| QA-replay-scripted-arrivals | 6b8f38fedb4a08e651b38252f8463719978bea5a9f8bfd4c246e5b4ddee2e9ef | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | eac473363b6f3391f47be06a918bae4ee65cc91f170a1897a20e9259ce1a0151 |
| QA-replay-sink-recovery | 6b8f38fedb4a08e651b38252f8463719978bea5a9f8bfd4c246e5b4ddee2e9ef | cc71e7bbabb0e65c3a5d267bfb7672adac18e43439e0b916edd520fc63f204df | 24af525fda5035c2c0edd7462bd67142f5b7c7ea860b34b80610620b6cf6a073 |

Only the declared case instances and native platform; shadow metrics are not performance certification.
