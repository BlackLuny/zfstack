"""One longer, fixed cohort for bulk guards whose primary CI is inconclusive."""
from pathlib import Path
import ast,sys,json
p=Path(sys.argv[1]);s=p.read_text();summary=json.loads((p.parent/'network-summary.json').read_text());selected=[];triggers={}
for case in ['down8','up8']:
 e=summary[case];why=[]
 if e['results.goodput_mbps_window']['ci95_pct'][0]<-5:why.append('throughput CI does not exclude -5%')
 if e['cpu.cpu_sec_per_effective_GB']['ci95_pct'][1]>2:why.append('CPU/GB CI does not exclude +2%')
 if why:selected.append(case);triggers[case]=why
assert selected,'No unresolved bulk guard; do not rerun'
tree=ast.parse(s);assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets));cases=ast.literal_eval(assignment.value);new=[]
for case,_,args in cases:
 if case not in selected:continue
 args=list(args);args[args.index('--secs')+1]='30';args[args.index('--warmup')+1]='5';new.append((case,24,args))
lines=s.splitlines(keepends=True);s=''.join(lines[:assignment.lineno-1])+f'cases={repr(new)}\n'+''.join(lines[assignment.end_lineno:]);s=s.replace('network-meta.json','network-bulk-confirmation-meta.json').replace('network.jsonl','network-bulk-confirmation.jsonl');Path(sys.argv[2]).write_text(s)
(p.parent/'network-bulk-confirmation-plan.json').write_text(json.dumps({'selected_cases':selected,'triggers':triggers,'pairs_per_case':24,'secs':30,'warmup':5,'window_secs':25,'decision':'Analyze separately; no pooling with original 12-pair cohort; retain any unresolved or regression result.'},indent=2)+'\n')
