#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$r/target-checks"
cd "$r/checks-U"
cargo +1.92.0 test --locked --release -p zfstack --features tokio,test-peer > "$r/linux-U-library-tests.log" 2>&1
cargo +1.92.0 test --locked --release -p zfstack --features tokio,test-peer --example pareto_probe > "$r/linux-U-probe-tests.log" 2>&1
cargo +1.92.0 test --locked --release -p zfstack --features tokio,test-peer issue37_splice_256_streams_keep_progressing_with_delayed_acks -- --ignored --nocapture > "$r/linux-U-256-tests.log" 2>&1
cargo +1.92.0 build --locked -p zfstack --no-default-features > "$r/linux-U-no-default.log" 2>&1
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s bench/pareto -p 'test_*.py' > "$r/linux-U-python-tests.log" 2>&1
printf 'CHECKS_DONE\n'
