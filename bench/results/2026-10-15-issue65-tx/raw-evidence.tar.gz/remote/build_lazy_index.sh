#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_PANIC=abort
[[ ! -e "$r/V" && ! -e "$r/V2" ]]
cp -a "$r/U" "$r/V"
cp "$r/budget-lazy-index.rs" "$r/V/src/budget.rs"
cp "$r/buf-lazy-index.rs" "$r/V/src/buf.rs"
printf '%s\n' aefc7dc54120a0e49736801af5434300dfa82b61 > "$r/V/.zfstack_commit"
cp -a "$r/V" "$r/V2"
for v in V V2; do
 CARGO_TARGET_DIR="$r/target-$v" cargo +1.92.0 build --locked --release --manifest-path "$r/$v/Cargo.toml" --features test-peer --example pareto_probe --example tx_write_probe > "$r/build-$v.log" 2>&1
done
printf 'LAZY_INDEX_BUILD_DONE\n'
