"""Same 4000-attempt/concurrency1000 protocol; larger fixed paired cohort."""
from pathlib import Path
import ast,sys
p=Path(sys.argv[1]);s=p.read_text();tree=ast.parse(s);assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets));cases=ast.literal_eval(assignment.value);case=next(c for c in cases if c[0]=='connect1000');case=(case[0],192,case[2]);lines=s.splitlines(keepends=True);s=''.join(lines[:assignment.lineno-1])+f'cases={repr([case])}\n'+''.join(lines[assignment.end_lineno:]);s=s.replace("network-meta.json","network-connect-confirmation-meta.json").replace("network.jsonl","network-connect-confirmation.jsonl");Path(sys.argv[2]).write_text(s)
