#!/usr/bin/env bash
set -euo pipefail
root=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_PANIC=abort
cp -a "$root/M" "$root/C"
cp "$root/budget.rs" "$root/C/src/budget.rs"
cp "$root/buf.rs" "$root/C/src/buf.rs"
cp -a "$root/C" "$root/C2"
for variant in C C2; do
 export CARGO_TARGET_DIR="$root/target-$variant"
 cargo +1.92.0 build --locked --release --manifest-path "$root/$variant/Cargo.toml" --features test-peer --example pareto_probe --example tx_write_probe > "$root/build-$variant.log" 2>&1
done
export CARGO_TARGET_DIR="$root/target-C"
cargo +1.92.0 build --locked --release --manifest-path "$root/C/Cargo.toml" --features test-peer --example tx_alloc_diag --example tx_write_diag > "$root/build-C-diag.log" 2>&1
