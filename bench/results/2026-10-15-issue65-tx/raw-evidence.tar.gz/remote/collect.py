"""Collect immutable, source-only evidence after all measured work has stopped."""
from pathlib import Path
import json,hashlib,subprocess,platform,os,tarfile,time
r=Path(__file__).resolve().parent
expected=json.loads((r/'expected-sources.json').read_text());proof={};inputs={};binaries={}
variants=['F56','M','P','Q','Q2','N','C','C2','R','R2','T','U','U2','V','V2']
for v in variants:
 d=Path('/root/zftxmigrate22-20261015/FV') if v=='F56' else r/v;actual={str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((d/'src').rglob('*')) if p.is_file()}
 key='V' if v=='V2' else 'U' if v=='U2' else 'R' if v=='R2' else 'C' if v=='C2' else v
 if key in expected:
  proof[v]={'git_sha':expected[key]['git_sha'],'src_matches':actual==expected[key]['src']}
  if v in ['F56','M','R','R2','T','U','U2','V','V2']:assert proof[v]['src_matches'],(v,proof[v])
 files=[]
 for child in ['Cargo.toml','Cargo.lock','src','examples','bench/Cargo.toml','bench/src'] + (['.zfstack_commit'] if (d/'.zfstack_commit').exists() else []):
  p=d/child
  files.extend([p] if p.is_file() else [f for f in p.rglob('*') if f.is_file()])
 inputs[v]={str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
 bp=Path('/root/zftxmigrate22-20261015/target-FV/release') if v=='F56' else r/f'target-{v}/release'
 binaries[v]={str(p.relative_to(bp)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted((bp/'examples').glob('*')) if p.is_file() and p.suffix not in ['.d']}
 if (bp/'zfbench').exists():binaries[v]['zfbench']={'sha256':hashlib.sha256((bp/'zfbench').read_bytes()).hexdigest(),'bytes':(bp/'zfbench').stat().st_size}
checks={str(p.relative_to(r/'checks')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((r/'checks/src').rglob('*')) if p.is_file()}
proof['native_checks']={'src_matches_R':checks==expected['R']['src']};assert proof['native_checks']['src_matches_R']
proof['R2_inputs_match_R']=inputs['R2']==inputs['R'];assert proof['R2_inputs_match_R']
proof['V2_inputs_match_V']=inputs['V2']==inputs['V'];assert proof['V2_inputs_match_V']
proof['U2_inputs_match_U']=inputs['U2']==inputs['U'];assert proof['U2_inputs_match_U']
checks_u={str(p.relative_to(r/'checks-U')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((r/'checks-U/src').rglob('*')) if p.is_file()}
proof['native_checks_U']={'src_matches_U':checks_u==expected['U']['src'],'cargo_inputs_sha256':{f:hashlib.sha256((r/'checks-U'/f).read_bytes()).hexdigest() for f in ['Cargo.toml','Cargo.lock']}};assert proof['native_checks_U']['src_matches_U']
# Every completed run still refers to the same on-disk executable, even after
# sidecar/network builds with a different feature graph.
verified=[]
for p in sorted(r.glob('*-meta.json')):
 m=json.loads(p.read_text())
 if 'variants' not in m or 'binary_sha256' not in m:continue
 assert m.get('finished') and m['binary_hashes_unchanged'],p.name
 for v,path in m['variants'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==m['binary_sha256'][v],(p.name,v)
 verified.append(p.name)
proof['completed_micro_manifests_verified']=verified
proof['completed_network_binary_hashes_verified']=[]
for name in ['network-meta.json','network-connect-confirmation-meta.json','network-bulk-confirmation-meta.json']:
 network_meta=json.loads((r/name).read_text());assert network_meta.get('finished')
 assert network_meta['namespace_net']!=network_meta['host_net'] and network_meta['namespace_pid']!=network_meta['host_pid']
 for v,b in network_meta['binaries'].items():assert hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256'],v
 proof['completed_network_binary_hashes_verified'].append(name)
(r/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
(r/'inputs-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
(r/'binary-manifest.json').write_text(json.dumps(binaries,indent=2)+'\n')
with tarfile.open(r/'inputs.tar.gz','w:gz',compresslevel=9) as t:
 for v,files in inputs.items():
  for rel in files:t.add((Path('/root/zftxmigrate22-20261015/FV') if v=='F56' else r/v)/rel,arcname=v+'/'+rel,recursive=False)
env={'collected_utc_epoch':time.time(),'kernel':platform.uname()._asdict(),'cpus':os.cpu_count(),'cpu_model':[line.strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')][:1],'meminfo':Path('/proc/meminfo').read_text(),'loadavg':Path('/proc/loadavg').read_text(),'disk_available_bytes':os.statvfs(r).f_bavail*os.statvfs(r).f_frsize,'governor_paths':list(map(str,Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_governor'))),'host_tun_exists':Path('/sys/class/net/zfbA').exists(),'ns_registry_exists':Path('/run/netns/zfbns').exists()}
cmd_env={**os.environ,'PATH':'/root/.cargo/bin:'+os.environ.get('PATH',''),'RUSTUP_HOME':'/root/zfverify22-20261015/rustup'}
env['collector_shell_build_env']={k:os.environ.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER']}
env['cargo_config_files']={str(p):({'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} if p.exists() else None) for p in [Path('/root/.cargo/config'),Path('/root/.cargo/config.toml'),r/'.cargo/config',r/'.cargo/config.toml']}
env['perf_rustc']=subprocess.check_output(['rustup','run','1.92.0','rustc','-Vv'],env=cmd_env,text=True)
assert not env['host_tun_exists'] and not env['ns_registry_exists']
env['processes']=subprocess.check_output(['ps','-eo','pid,comm,pcpu','--sort=-pcpu'],text=True).splitlines()[:20]
(r/'environment-after.json').write_text(json.dumps(env,indent=2)+'\n')
with tarfile.open(r/'raw-remote.tar.gz','w:gz',compresslevel=9) as t:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ['.json','.jsonl','.py','.sh','.txt','.log']:
   t.add(p,arcname='remote/'+p.name,recursive=False)
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(r.iterdir()) if p.is_file() and p.name!='evidence-sha256.json' and p.suffix!='.data'}
(r/'evidence-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Collected',len(manifest),'evidence files; matched final source and all completed-run binary hashes.')
