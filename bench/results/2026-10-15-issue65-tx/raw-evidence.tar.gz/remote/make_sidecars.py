"""Make common write_with and allocator-only diagnostic probes from frozen verifier."""
from pathlib import Path
import sys
root=Path(sys.argv[1]);source=(root/'examples/pareto_probe.rs').read_text()
old='''        if !black_box(&mut tx).push(black_box(&mut pool), black_box(&mut budget), peer, black_box(&src)) {
            return Err("TX allocation failed during measured work".into());
        }'''
new='''        let mut offset = 0;
        while offset < src.len() {
            let n = black_box(&mut tx).write_with(black_box(&mut pool), black_box(&mut budget), peer, src.len() - offset, |[a, b]| -> Result<usize, String> {
                let first = a.len().min(src.len() - offset);
                a[..first].copy_from_slice(&src[offset..offset + first]);
                let second = b.len().min(src.len() - offset - first);
                b[..second].copy_from_slice(&src[offset + first..offset + first + second]);
                Ok(first + second)
            })?.ok_or("write_with allocation refused")?;
            if n == 0 { return Err("write_with made no progress".into()); }
            offset += n;
        }'''
assert source.count(old)==1
writer=source.replace(old,new)
writer=writer.replace('("verification_method", quote("portable_full_scan_v1")),','("verification_method", quote("portable_full_scan_v1")),\n        ("tx_api", quote("write_with")),')
(root/'examples/tx_write_probe.rs').write_text(writer)
allocator='''
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicU64, Ordering};
struct CountAlloc;
static ALLOC: AtomicU64 = AtomicU64::new(0);
static FREE: AtomicU64 = AtomicU64::new(0);
static ALLOC_BYTES: AtomicU64 = AtomicU64::new(0);
static WORK_ALLOC: AtomicU64 = AtomicU64::new(0);
static WORK_FREE: AtomicU64 = AtomicU64::new(0);
static WORK_BYTES: AtomicU64 = AtomicU64::new(0);
unsafe impl GlobalAlloc for CountAlloc {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        ALLOC.fetch_add(1, Ordering::Relaxed);
        ALLOC_BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
        System.alloc(layout)
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        FREE.fetch_add(1, Ordering::Relaxed);
        System.dealloc(ptr, layout)
    }
    unsafe fn realloc(&self, ptr: *mut u8, old: Layout, size: usize) -> *mut u8 {
        ALLOC.fetch_add(1, Ordering::Relaxed);
        FREE.fetch_add(1, Ordering::Relaxed);
        ALLOC_BYTES.fetch_add(size as u64, Ordering::Relaxed);
        System.realloc(ptr, old, size)
    }
}
#[global_allocator]
static ALLOCATOR: CountAlloc = CountAlloc;
'''
for name,base in [('tx_alloc_diag',source),('tx_write_diag',writer)]:
 base=base.replace('type ProbeResult<T> = Result<T, String>;',allocator+'\ntype ProbeResult<T> = Result<T, String>;')
 needle='''    let timer = Timer::start();
    for iteration in 0..a.iterations {'''
 repl='''    let alloc_start = [ALLOC.load(Ordering::Relaxed), FREE.load(Ordering::Relaxed), ALLOC_BYTES.load(Ordering::Relaxed)];
    let timer = Timer::start();
    for iteration in 0..a.iterations {'''
 assert base.count(needle)==1;base=base.replace(needle,repl)
 needle='''    let (work_wall_ns, work_cpu_ns) = timer.stop();
    let retained_reserved_bytes_before_drop = global.reserved();'''
 repl='''    let (work_wall_ns, work_cpu_ns) = timer.stop();
    WORK_ALLOC.store(ALLOC.load(Ordering::Relaxed) - alloc_start[0], Ordering::Relaxed);
    WORK_FREE.store(FREE.load(Ordering::Relaxed) - alloc_start[1], Ordering::Relaxed);
    WORK_BYTES.store(ALLOC_BYTES.load(Ordering::Relaxed) - alloc_start[2], Ordering::Relaxed);
    let retained_reserved_bytes_before_drop = global.reserved();'''
 assert base.count(needle)==1;base=base.replace(needle,repl)
 base=base.replace('("verification_method", quote("portable_full_scan_v1")),','''("verification_method", quote("portable_full_scan_v1")),
        ("diagnostic_only", "true".into()),
        ("work_alloc_calls", WORK_ALLOC.load(Ordering::Relaxed).to_string()),
        ("work_free_calls", WORK_FREE.load(Ordering::Relaxed).to_string()),
        ("work_alloc_bytes", WORK_BYTES.load(Ordering::Relaxed).to_string()),''')
 (root/f'examples/{name}.rs').write_text(base)
