#!/usr/bin/env bash
set -euo pipefail
root=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export PATH=/root/.cargo/bin:$PATH
export RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
export CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_PANIC=abort
for variant in "$@"; do
  export CARGO_TARGET_DIR="$root/target-$variant"
  cargo +1.92.0 build --locked --release --manifest-path "$root/$variant/Cargo.toml" --features test-peer --example pareto_probe --example tx_write_probe --example tx_alloc_diag --example tx_write_diag > "$root/build-$variant-sidecars.log" 2>&1
done
