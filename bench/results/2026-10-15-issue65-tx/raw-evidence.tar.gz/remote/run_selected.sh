#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
for tag in refined-push-window1 refined-write-window1 refined-push-window2 refined-write-window2 ablation pump-guards f56-context; do
 python3 "$r/run_micro.py" "$r/$tag-config.json" > "$r/$tag.log" 2>&1
done
python3 "$r/analyze.py" scope-pilot scope-fast-pilot push-window1 write-window1 push-window2 write-window2 refined-pilot refined-long-pilot refined-push-window1 refined-write-window1 refined-push-window2 refined-write-window2 ablation pump-guards f56-context > "$r/summary.txt"
bash "$r/post_micro.sh"
bash "$r/run_checks.sh"
bash "$r/run_network.sh" > "$r/network.log" 2>&1
python3 "$r/network_analyze.py" > "$r/network-summary.txt"
printf 'SELECTED_ALL_DONE\n'
