"""Add isolated first-write counters to the common allocator diagnostics."""
from pathlib import Path
import sys
r=Path(sys.argv[1])
for name in ['tx_alloc','tx_write']:
 s=(r/f'examples/{name}_diag.rs').read_text()
 s=s.replace('struct CountAlloc;', 'struct CountAlloc;\nstatic COLD_ALLOC: AtomicU64 = AtomicU64::new(0);\nstatic COLD_FREE: AtomicU64 = AtomicU64::new(0);\nstatic COLD_BYTES: AtomicU64 = AtomicU64::new(0);')
 old='''    if !tx.push(&mut pool, &mut budget, PeerId(1), &src) {
        return Err("TX warmup allocation failed".into());
    }'''
 if name=='tx_write':
  new='''    let mut cold_offset = 0;
    while cold_offset < src.len() {
        let n = tx.write_with(&mut pool, &mut budget, PeerId(1), src.len() - cold_offset, |[a, b]| -> Result<usize, String> {
            let first = a.len().min(src.len() - cold_offset);
            a[..first].copy_from_slice(&src[cold_offset..cold_offset + first]);
            let second = b.len().min(src.len() - cold_offset - first);
            b[..second].copy_from_slice(&src[cold_offset + first..cold_offset + first + second]);
            Ok(first + second)
        })?.ok_or("cold write_with refused")?;
        if n == 0 { return Err("cold write_with made no progress".into()); }
        cold_offset += n;
    }'''
 else:new=old
 assert s.count(old)==1
 s=s.replace(old,'''    let cold_start = [ALLOC.load(Ordering::Relaxed), FREE.load(Ordering::Relaxed), ALLOC_BYTES.load(Ordering::Relaxed)];
'''+new+'''
    COLD_ALLOC.store(ALLOC.load(Ordering::Relaxed) - cold_start[0], Ordering::Relaxed);
    COLD_FREE.store(FREE.load(Ordering::Relaxed) - cold_start[1], Ordering::Relaxed);
    COLD_BYTES.store(ALLOC_BYTES.load(Ordering::Relaxed) - cold_start[2], Ordering::Relaxed);''')
 s=s.replace('("diagnostic_only", "true".into()),','''("diagnostic_only", "true".into()),
        ("cold_alloc_calls", COLD_ALLOC.load(Ordering::Relaxed).to_string()),
        ("cold_free_calls", COLD_FREE.load(Ordering::Relaxed).to_string()),
        ("cold_alloc_bytes", COLD_BYTES.load(Ordering::Relaxed).to_string()),''')
 (r/f'examples/{name}_cold_diag.rs').write_text(s)
