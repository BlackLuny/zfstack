#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_PANIC=abort
for v in T U; do
 CARGO_TARGET_DIR="$r/target-$v" cargo +1.92.0 build --locked --release --manifest-path "$r/$v/Cargo.toml" --features test-peer --example tx_alloc_diag --example tx_write_diag > "$r/build-$v-diag.log" 2>&1
done
for v in T U; do
 CARGO_TARGET_DIR="$r/target-$v" cargo +1.92.0 build --locked --release --manifest-path "$r/$v/Cargo.toml" -p zfbench > "$r/build-$v-zfbench.log" 2>&1
done
python3 "$r/inspect_current_quota_layout.py" > "$r/layout.log" 2>&1
python3 - <<'PY'
from pathlib import Path
import json,subprocess,hashlib
r=Path('/root/zf65-20261015');out=[]
for v in ['T','U']:
 for example in ['tx_alloc_diag','tx_write_diag']:
  binary=r/f'target-{v}/release/examples/{example}'
  for case in ['tx-alloc','tx-alloc-pooled','tx-alloc-migrate']:
   for n in [1,64,512,1400,4096,65535,65536,65537]:
    cmd=['taskset','-c','3',str(binary),case,'--iterations','10000','--payload',str(n)]
    p=subprocess.run(cmd,capture_output=True,text=True,check=True);m=json.loads(p.stdout)
    assert m['ok'] and m['checksum_u64']==m['expected_checksum_u64'] and m['final_reserved_bytes']==0
    out.append({'variant':v,'api':example,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'command':cmd,'measurement':m})
(r/'current-quota-allocation-diagnostics.json').write_text(json.dumps(out,indent=2)+'\n')
PY
for v in T U; do
 for case in tx-alloc tx-alloc-migrate; do
  perf record -q -e cpu-clock:u -F 997 -o "$r/profile-$v-$case.data" -- taskset -c 3 "$r/target-$v/release/examples/pareto_probe" "$case" --payload 64 --iterations 20000000 > "$r/profile-$v-$case.json" 2> "$r/profile-$v-$case.log"
  perf report --stdio --no-children -i "$r/profile-$v-$case.data" > "$r/profile-$v-$case.txt"
 done
done
printf 'POST_MICRO_DONE\n'
