from pathlib import Path
import subprocess,re,hashlib,json
r=Path(__file__).resolve().parent;out={}
for example in ['pareto_probe','tx_write_probe']:
 arm={}
 for v in ['T','U','U2']:
  p=r/f'target-{v}/release/examples/{example}';dis=subprocess.check_output(['objdump','-Cd',str(p)],text=True);symbol=example+'::verify'
  m=re.search(r'^([0-9a-f]+) <'+symbol+r'>:\n(.*?)(?=\n[0-9a-f]+ <)',dis,re.M|re.S);assert m
  start=int(m[1],16);fn=m[0];assert 'bcmp@' not in fn and 'memcmp@' not in fn and start%4096==0
  (r/f'{v}-{example}-verify.txt').write_text(fn);instructions={};loops=[]
  for line in fn.splitlines()[1:]:
   match=re.match(r'\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s*(.*)',line)
   if not match:continue
   addr=int(match[1],16);b=bytes.fromhex(match[2]);instructions[addr]=b
   branch=re.search(r'\bj\w+\s+([0-9a-f]+) <'+symbol+r'\+0x',match[3])
   if branch and start<=int(branch[1],16)<addr:
    a=int(branch[1],16);end=addr+len(b);code=b''.join(instructions[k] for k in sorted(instructions) if a<=k<end);loops.append({'offset':hex(a-start),'start':hex(a),'mod64':a%64,'length':end-a,'sha256':hashlib.sha256(code).hexdigest()})
  arm[v]={'binary_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'verify_start':hex(start),'loops':loops,'no_bcmp_memcmp_calls':True,'source_sha256':hashlib.sha256((r/v/'examples'/f'{example}.rs').read_bytes()).hexdigest()}
 assert len({x['source_sha256'] for x in arm.values()})==1
 # Page offsets and loop bytes must match even if the linker places pages differently.
 signatures={v:[{k:x for k,x in loop.items() if k!='start'} for loop in arm[v]['loops']] for v in arm}
 assert signatures['T']==signatures['U']==signatures['U2']
 out[example]=arm
(r/'current-quota-layout.json').write_text(json.dumps(out,indent=2)+'\n');print('Verifier source, loop bytes and page offsets match for both APIs.')
