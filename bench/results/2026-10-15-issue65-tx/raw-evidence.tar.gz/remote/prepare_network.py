"""Derive the matched #56 network protocol; execute only inside isolated namespaces."""
from pathlib import Path
import sys
old=Path(sys.argv[1]).read_text()
old=old.replace("r=Path('/root/zfopt22-20261015')", "r=Path('/root/zf65-20261015')")
old=old.replace("bins={'D':Path('/root/zfverify22-20261015/target-D/release/zfbench'),'F':r/'target-F/release/zfbench'}", "bins={'M':r/'target-M/release/zfbench','R':r/'target-R/release/zfbench'}")
old=old.replace("('down8',5,", "('down8',12,").replace("('up8',5,", "('up8',12,")
old=old.replace("'--secs','6','--warmup','1'", "'--secs','12','--warmup','3'")
old=old.replace("bins['F']", "bins['R']").replace("['D','F']", "['M','R']").replace("['F','D']", "['R','M']")
old=old.replace("from pathlib import Path", "from pathlib import Path\nimport fcntl,os\nlock=os.fdopen(os.dup(int(os.environ['ZF65_PERF_LEASE_FD'])),'w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)\nassert os.environ.get('QA_NETNS_ISOLATED')=='1'\nassert os.environ.get('QA_PRIVATE_PIDNS')=='1'")
old=old.replace("meta={'cases':cases", "meta={'namespace_net':str(Path('/proc/self/ns/net').readlink()),'namespace_pid':str(Path('/proc/self/ns/pid').readlink()),'host_net':os.environ.get('QA_HOST_NETNS_ID'),'host_pid':os.environ.get('QA_HOST_PIDNS_ID'),'cases':cases")
# Python3.8 has no Path.readlink, unlike the local tooling runtime.
old=old.replace("str(Path('/proc/self/ns/net').readlink())", "os.readlink('/proc/self/ns/net')").replace("str(Path('/proc/self/ns/pid').readlink())", "os.readlink('/proc/self/ns/pid')")
old=old.replace("(r/'network-meta.json').write_text", "assert meta['namespace_net']!=meta['host_net'] and meta['namespace_pid']!=meta['host_pid']\n(r/'network-meta.json').write_text",1)
Path(sys.argv[2]).write_text(old)
