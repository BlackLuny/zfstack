#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
bash "$r/run_connect_confirmation.sh" > "$r/network-connect-confirmation.log" 2>&1
bash "$r/run_bulk_confirmation.sh" > "$r/network-bulk-confirmation.log" 2>&1
printf 'NETWORK_CONFIRMATIONS_DONE\n'
