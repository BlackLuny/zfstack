#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
bash "$r/run_current_quota_supplement.sh"
bash "$r/post_current_quota.sh"
bash "$r/run_current_quota_checks.sh"
bash "$r/run_current_quota_network.sh" > "$r/network.log" 2>&1
python3 "$r/network_current_quota_analyze.py" > "$r/network-summary.txt"
printf 'CURRENT_QUOTA_ALL_DONE\n'
