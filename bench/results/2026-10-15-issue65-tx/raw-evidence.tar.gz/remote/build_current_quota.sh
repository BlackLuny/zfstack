#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_PANIC=abort
[[ ! -e "$r/U" && ! -e "$r/U2" ]]
cp -a "$r/T" "$r/U"
cp "$r/budget-current-quota.rs" "$r/U/src/budget.rs"
cp "$r/buf-current-quota.rs" "$r/U/src/buf.rs"
cp -a "$r/U" "$r/U2"
printf '%s\n' 88a2e3f7a2e86fb6948223054a377e8a7f831af1 > "$r/T/.zfstack_commit"
printf '%s\n' 2694c1406b7ebb5d1eef381a0c1a69e27f1ea743 > "$r/U/.zfstack_commit"
cp "$r/U/.zfstack_commit" "$r/U2/.zfstack_commit"
for v in T U U2; do
 CARGO_TARGET_DIR="$r/target-$v" cargo +1.92.0 build --locked --release --manifest-path "$r/$v/Cargo.toml" --features test-peer --example pareto_probe --example tx_write_probe > "$r/build-$v.log" 2>&1
done
