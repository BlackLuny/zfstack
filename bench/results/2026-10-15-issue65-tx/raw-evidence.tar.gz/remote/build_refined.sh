#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export PATH=/root/.cargo/bin:$PATH RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_PANIC=abort
[[ ! -e "$r/R" && ! -e "$r/R2" ]]
cp -a "$r/M" "$r/R"
cp "$r/budget-refined.rs" "$r/R/src/budget.rs"
cp "$r/buf-refined.rs" "$r/R/src/buf.rs"
cp -a "$r/R" "$r/R2"
for v in R R2; do
 CARGO_TARGET_DIR="$r/target-$v" cargo +1.92.0 build --locked --release --manifest-path "$r/$v/Cargo.toml" --features test-peer --example pareto_probe --example tx_write_probe > "$r/build-$v.log" 2>&1
done
