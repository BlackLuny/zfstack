#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
bash "$r/build_lazy_index.sh"
for api in push write; do
 python3 "$r/run_micro.py" "$r/lazy-index-$api-pilot-config.json" > "$r/lazy-index-$api-pilot.log" 2>&1
done
printf 'LAZY_INDEX_PILOT_DONE\n'
