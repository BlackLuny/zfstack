#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
for tag in push-window1 write-window1 push-window2 write-window2; do
 python3 "$r/run_micro.py" "$r/$tag-config.json" > "$r/$tag.log" 2>&1
done
python3 "$r/analyze.py" scope-pilot scope-fast-pilot push-window1 write-window1 push-window2 write-window2 > "$r/summary.txt"
