#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export ZF65_PERF_LEASE_FD=9
python3 "$r/prepare_connect_confirmation.py" "$r/network.py" "$r/network-connect-confirmation.py"
bash "$r/isolate-linux.sh" bash -c 'mount -t sysfs sysfs /sys; exec python3 /root/zf65-20261015/network-connect-confirmation.py'
python3 "$r/network_current_quota_analyze.py" network-connect-confirmation > "$r/network-connect-confirmation-summary.txt"
printf 'CONNECT_CONFIRMATION_DONE\n'
