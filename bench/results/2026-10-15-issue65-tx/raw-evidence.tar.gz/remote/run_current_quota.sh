#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
for tag in current-quota-preheat current-quota-push-window1 current-quota-write-window1 current-quota-push-window2 current-quota-write-window2 current-quota-pump-guards current-quota-f56-context; do
 python3 "$r/run_micro.py" "$r/$tag-config.json" > "$r/$tag.log" 2>&1
done
python3 "$r/analyze.py" current-quota-preheat current-quota-push-window1 current-quota-write-window1 current-quota-push-window2 current-quota-write-window2 current-quota-pump-guards current-quota-f56-context > "$r/current-quota-summary.txt"
bash "$r/post_current_quota.sh"
bash "$r/run_current_quota_checks.sh"
bash "$r/run_current_quota_network.sh" > "$r/network.log" 2>&1
python3 "$r/network_current_quota_analyze.py" > "$r/network-summary.txt"
printf 'CURRENT_QUOTA_ALL_DONE\n'
