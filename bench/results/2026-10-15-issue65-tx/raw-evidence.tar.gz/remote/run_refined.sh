#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
bash "$r/build_refined.sh"
python3 "$r/run_micro.py" "$r/refined-pilot-config.json" > "$r/refined-pilot.log" 2>&1
python3 "$r/analyze.py" refined-pilot > "$r/refined-pilot-summary.txt"
cat "$r/refined-pilot-summary.txt"
python3 - <<'PY2'
from pathlib import Path
import json
r=Path('/root/zf65-20261015');cs=json.loads((r/'summary.json').read_text())['refined-pilot']['cases']
for case in ['tx-alloc_64','tx-alloc-migrate_64']:
 assert cs[case]['comparisons']['R/M']['median_pct']<0,('pilot target did not improve',case)
for case in ['tx-alloc-pooled_64','tx-alloc-pooled_1400']:
 assert cs[case]['comparisons']['R/M']['median_pct']<2,('pilot guard',case)
PY2
for tag in refined-push-window1 refined-write-window1 refined-push-window2 refined-write-window2 ablation pump-guards f56-context; do
 python3 "$r/run_micro.py" "$r/$tag-config.json" > "$r/$tag.log" 2>&1
done
python3 "$r/analyze.py" scope-pilot scope-fast-pilot push-window1 write-window1 push-window2 write-window2 refined-pilot refined-push-window1 refined-write-window1 refined-push-window2 refined-write-window2 ablation pump-guards f56-context > "$r/summary.txt"
