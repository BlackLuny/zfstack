"""Prespecify a higher-precision confirmation of the original bulk protocol."""
from pathlib import Path
import ast, hashlib, json, time
r=Path('/root/zf65-20261015');s=(r/'network.py').read_text();tree=ast.parse(s)
n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets));base=ast.literal_eval(n.value)
for tag,pairs,aa in [('network-unrestricted-aa',12,True),('network-unrestricted-tu',64,False)]:
 cases=[]
 for case,_,args in base:
  if case not in ['down8','up8']:continue
  args=list(args);args[args.index('--secs')+1]='30';args[args.index('--warmup')+1]='5';cases.append((case,pairs,args))
 lines=s.splitlines(keepends=True);out=''.join(lines[:n.lineno-1])+f'cases={cases!r}\n'+''.join(lines[n.end_lineno:])
 out=out.replace('network-meta.json',tag+'-meta.json').replace('network.jsonl',tag+'.jsonl')
 if aa:out=out.replace("'U':r/'target-U/release/zfbench'", "'U':r/'target-T/release/zfbench'")
 out=out.replace("meta['finished']=time.time();", "assert all(hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256'] for b in meta['binaries'].values())\nmeta['finished']=time.time();")
 compile(out,tag,'exec');(r/(tag+'.py')).write_text(out)
plan={'registered_at':time.time(),'source_sha':'2694c1406b7ebb5d1eef381a0c1a69e27f1ea743','baseline_sha':'88a2e3f7a2e86fb6948223054a377e8a7f831af1','affinity':'0-3, unchanged original process placement; no thread pinner','cohorts':{'network-unrestricted-aa':{'pairs_per_direction':12,'binary':'T vs identical T','role':'Independent noise diagnostic; no A/A correction of T/U ratios'},'network-unrestricted-tu':{'pairs_per_direction':64,'binary':'T vs U','role':'Fixed final confirmation; analyse separately from all previous samples'}},'secs':30,'warmup':5,'window_secs':25,'unchanged':'MTU1420 CUBIC seed1 rate0 RTT1 queue64MiB 8flows; existing T/U binaries; original TUN queues; original all-core affinity','limits':{'cpu_upper_pct':2,'goodput_lower_pct':-5},'rationale':'Original 24-pair long cohort CPU/GB CI upper bounds 2.60/3.13 exceed +2. Increasing fixed N to 64 improves precision without changing the protocol. Per-role pinning A/A was substantially noisier, so that method is rejected and its T/U prefix cancelled without inference.','decision':'Execute these fixed complete cohorts once, without partial statistics or stopping on passing results. Preserve all prior cohorts, no pooling or A/A bias correction. If final intervals still cross guard limits, keep INCONCLUSIVE and do not mark ready to merge.'}
plan['runner_sha256']={tag:hashlib.sha256((r/(tag+'.py')).read_bytes()).hexdigest() for tag in plan['cohorts']}
(r/'network-unrestricted-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
