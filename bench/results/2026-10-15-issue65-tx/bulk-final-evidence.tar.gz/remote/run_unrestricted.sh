#!/usr/bin/env bash
set -euo pipefail
r=/root/zf65-20261015
exec 9>/var/lock/zfstack-issue65-perf.lock
flock -n 9
export ZF65_PERF_LEASE_FD=9
python3 "$r/prepare_unrestricted.py"
for tag in network-unrestricted-aa network-unrestricted-tu; do
  bash "$r/isolate-linux.sh" bash -c "mount -t sysfs sysfs /sys; exec python3 $r/$tag.py" > "$r/$tag.log" 2>&1
  python3 "$r/network_current_quota_analyze.py" "$tag" > "$r/$tag-summary.txt"
done
printf 'UNRESTRICTED_COHORTS_DONE\n'
