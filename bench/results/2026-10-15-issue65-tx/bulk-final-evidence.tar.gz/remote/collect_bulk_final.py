"""Read-only final identity checks; export new raw records after the lock is free."""
from pathlib import Path
import fcntl, hashlib, json, os, tarfile, time
r=Path('/root/zf65-20261015')
with open('/var/lock/zfstack-issue65-perf.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert 'UNRESTRICTED_COHORTS_DONE' in (r/'network-unrestricted.log').read_text()
 original=json.loads((r/'network-meta.json').read_text());identities={}
 for arm in ['T','U']:
  b=original['binaries'][arm];actual=hashlib.sha256(Path(b['path']).read_bytes()).hexdigest();assert actual==b['sha256'];identities[arm]={'path':b['path'],'sha256':actual}
 complete={}
 for tag,n in [('network-placement-aa',52),('network-unrestricted-aa',52),('network-unrestricted-tu',260)]:
  m=json.loads((r/(tag+'-meta.json')).read_text());assert m.get('finished')
  rows=[json.loads(x) for x in (r/(tag+'.jsonl')).read_text().splitlines()];assert len(rows)==n
  assert all(x['exit_code']==0 and x['measurement']['ok'] and not x['measurement']['errors'] for x in rows)
  complete[tag]={'runs':len(rows),'started':m['started'],'finished':m['finished']}
 assert not Path('/sys/class/net/zfbA').exists() and not Path('/run/netns/zfbns').exists()
 proof={'at':time.time(),'source_sha':'2694c1406b7ebb5d1eef381a0c1a69e27f1ea743','baseline_sha':'88a2e3f7a2e86fb6948223054a377e8a7f831af1','binaries':identities,'complete':complete,'host_tun_exists':False,'host_test_netns_exists':False,'uname':list(os.uname()),'meminfo':Path('/proc/meminfo').read_text(),'pressure':{name:Path('/proc/pressure/'+name).read_text() for name in ['cpu','memory','io']}}
 (r/'bulk-final-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 names=['network-placement-plan.json','network-placement-cancelled.json','network-unrestricted-plan.json','prepare_placement.py','run_placement.sh','prepare_unrestricted.py','run_unrestricted.sh','collect_bulk_final.py','network-placement.log','network-unrestricted.log','bulk-final-proof.json']
 for tag in ['network-placement-aa','network-placement-tu','network-unrestricted-aa','network-unrestricted-tu']:
  names += [tag+ext for ext in ['.jsonl','-meta.json','.py','.log']]
 assert all((r/n).is_file() for n in names)
 with tarfile.open(r/'bulk-final-evidence.tar.gz','w:gz') as t:
  for name in sorted(names):t.add(r/name,arcname='remote/'+name,recursive=False)
 print(json.dumps({'members':len(names),'archive_bytes':(r/'bulk-final-evidence.tar.gz').stat().st_size,'proof':proof['complete']}))
