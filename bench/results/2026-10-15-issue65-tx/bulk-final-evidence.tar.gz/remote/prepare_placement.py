"""Freeze same-binary calibration and a fixed, separately analysed T/U cohort."""
from pathlib import Path
import ast, hashlib, json, time
r = Path('/root/zf65-20261015')
s = (r/'network.py').read_text()
tree = ast.parse(s)
n = next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'cases' for t in n.targets))
base = ast.literal_eval(n.value)
monitor = '''
import threading
role_cpus={'zfb-stack':0,'zfb-link-down':1,'zfb-link-up':2}
def place_threads(pid, stop, audit):
 start=time.monotonic(); seen={}
 try:
  while not stop.is_set():
   for task in Path('/proc/%d/task'%pid).glob('*'):
    try:
     name=(task/'comm').read_text().strip(); tid=int(task.name); cpu=role_cpus.get(name,3)
     before=os.sched_getaffinity(tid)
     if before!={cpu}:os.sched_setaffinity(tid,{cpu})
     assert os.sched_getaffinity(tid)=={cpu}
     key=(tid,name,cpu)
     if key not in seen:seen[key]={'tid':tid,'name':name,'cpu':cpu,'first_sec':time.monotonic()-start}
    except (FileNotFoundError,ProcessLookupError):pass
   stop.wait(.02)
 except BaseException as e:audit['error']=repr(e)
 audit['threads']=list(seen.values())
'''
for tag, pairs, secs, warmup, aa in [('network-placement-aa',12,12,3,True),('network-placement-tu',32,30,5,False)]:
 cases=[]
 for case,_,args in base:
  if case not in ['down8','up8']:continue
  args=list(args);args[args.index('--secs')+1]=str(secs);args[args.index('--warmup')+1]=str(warmup)
  cases.append((case,pairs,args))
 lines=s.splitlines(keepends=True)
 out=''.join(lines[:n.lineno-1])+f'cases={cases!r}\n'+''.join(lines[n.end_lineno:])
 out=out.replace('network-meta.json',tag+'-meta.json').replace('network.jsonl',tag+'.jsonl')
 if aa:out=out.replace("'U':r/'target-U/release/zfbench'", "'U':r/'target-T/release/zfbench'")
 out=out.replace("assert not Path('/sys/class/net/zfbA').exists()",monitor+"\nassert not Path('/sys/class/net/zfbA').exists()")
 out=out.replace("'affinity':'0-3'", "'affinity':'0-3','thread_placement':{'zfb-stack':0,'zfb-link-down':1,'zfb-link-up':2,'others':3},'placement_poll_sec':0.02")
 out=out.replace("text=True)\n     try:", "text=True)\n     placement={}; placement_stop=threading.Event(); placer=threading.Thread(target=place_threads,args=(p.pid,placement_stop,placement));placer.start()\n     try:")
 out=out.replace("except BaseException:p.kill();p.communicate();raise", "except BaseException:p.kill();p.communicate();raise\n     finally:placement_stop.set();placer.join()\n     assert not placement.get('error'),placement\n     assert all(any(t['name']==name and t['cpu']==cpu and t['first_sec']<2 for t in placement['threads']) for name,cpu in role_cpus.items()),placement")
 out=out.replace("'loadavg':Path", "'placement':placement,'loadavg':Path")
 out=out.replace("meta['finished']=time.time();", "assert all(hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256'] for b in meta['binaries'].values())\nmeta['finished']=time.time();")
 compile(out,tag,'exec');(r/(tag+'.py')).write_text(out)
plan={'registered_at':time.time(),'source_sha':'2694c1406b7ebb5d1eef381a0c1a69e27f1ea743','baseline_sha':'88a2e3f7a2e86fb6948223054a377e8a7f831af1','cohorts':{'network-placement-aa':{'pairs_per_direction':12,'secs':12,'warmup':3,'binary':'T vs identical T'},'network-placement-tu':{'pairs_per_direction':32,'secs':30,'warmup':5,'binary':'T vs U'}},'placement':{'zfb-stack':0,'zfb-link-down':1,'zfb-link-up':2,'others':3},'unchanged':'MTU1420 CUBIC seed1 rate0 RTT1 queue64MiB 8flows; existing binaries and exact checks','limits':{'cpu_upper_pct':2,'goodput_lower_pct':-5},'calibration_gate':'A/A CPU/GB CI wholly within [-2,+2] and throughput CI wholly within [-5,+5] for both directions. Otherwise T/U is diagnostic only.','decision':'Run full fixed cohorts once. Do not inspect partial statistics, pool old samples, change source or stop on passing results. Preserve any failure/inconclusive result. This qualifies only the stated placement; previous unpinned intervals remain unchanged.'}
plan['runner_sha256']={tag:hashlib.sha256((r/(tag+'.py')).read_bytes()).hexdigest() for tag in plan['cohorts']}
(r/'network-placement-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
