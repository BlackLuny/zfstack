from pathlib import Path
import fcntl,os
lock=os.fdopen(os.dup(int(os.environ['ZF65_PERF_LEASE_FD'])),'w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert os.environ.get('QA_NETNS_ISOLATED')=='1'
assert os.environ.get('QA_PRIVATE_PIDNS')=='1'
import subprocess,json,time,hashlib
r=Path('/root/zf65-20261015')
bins={'T':r/'target-T/release/zfbench','U':r/'target-T/release/zfbench'}
common=['--stack','zfstack-cubic','--client-cc','cubic','--seed','1']
cases=[('down8', 12, ['--test', 'down', '--rate-mbps', '0', '--rtt-ms', '1', '--queue-bytes', '67108864', '--flows', '8', '--secs', '12', '--warmup', '3']), ('up8', 12, ['--test', 'up', '--rate-mbps', '0', '--rtt-ms', '1', '--queue-bytes', '67108864', '--flows', '8', '--secs', '12', '--warmup', '3'])]

import threading
role_cpus={'zfb-stack':0,'zfb-link-down':1,'zfb-link-up':2}
def place_threads(pid, stop, audit):
 start=time.monotonic(); seen={}
 try:
  while not stop.is_set():
   for task in Path('/proc/%d/task'%pid).glob('*'):
    try:
     name=(task/'comm').read_text().strip(); tid=int(task.name); cpu=role_cpus.get(name,3)
     before=os.sched_getaffinity(tid)
     if before!={cpu}:os.sched_setaffinity(tid,{cpu})
     assert os.sched_getaffinity(tid)=={cpu}
     key=(tid,name,cpu)
     if key not in seen:seen[key]={'tid':tid,'name':name,'cpu':cpu,'first_sec':time.monotonic()-start}
    except (FileNotFoundError,ProcessLookupError):pass
   stop.wait(.02)
 except BaseException as e:audit['error']=repr(e)
 audit['threads']=list(seen.values())

assert not Path('/sys/class/net/zfbA').exists(),'TUN name already in use'
meta={'namespace_net':os.readlink('/proc/self/ns/net'),'namespace_pid':os.readlink('/proc/self/ns/pid'),'host_net':os.environ.get('QA_HOST_NETNS_ID'),'host_pid':os.environ.get('QA_HOST_PIDNS_ID'),'cases':cases,'common':common,'affinity':'0-3','thread_placement':{'zfb-stack':0,'zfb-link-down':1,'zfb-link-up':2,'others':3},'placement_poll_sec':0.02,'warmup_pairs':1,'mtu':1420,'up8_tun_tx_queue_len':100000,'binaries':{v:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for v,p in bins.items()},'started':time.time()}
assert meta['namespace_net']!=meta['host_net'] and meta['namespace_pid']!=meta['host_pid']
(r/'network-placement-aa-meta.json').write_text(json.dumps(meta,indent=2))
def cleanup():subprocess.run([str(bins['U']),'--cleanup'],check=True,capture_output=True,timeout=30)
with (r/'network-placement-aa.jsonl').open('x',buffering=1) as out:
 try:
  for ci,(case,reps,args) in enumerate(cases):
   for rep in range(-1,reps):
    for v in (['T','U'] if (ci+rep)%2==0 else ['U','T']):
     cleanup();cmd=['taskset','-c','0-3',str(bins[v]),*common,*args];start=time.time();p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
     placement={}; placement_stop=threading.Event(); placer=threading.Thread(target=place_threads,args=(p.pid,placement_stop,placement));placer.start()
     try:
      deadline=time.monotonic()+5;flags=Path('/sys/class/net/zfbA/flags')
      while time.monotonic()<deadline:
       try:up=bool(int(flags.read_text().strip(),16)&1)
       except FileNotFoundError:up=False
       try:queue_ready=int(Path('/sys/class/net/zfbA/tx_queue_len').read_text())==10000
       except FileNotFoundError:queue_ready=False
       if up and queue_ready:
        ready_qdisc=subprocess.run(['tc','qdisc','show','dev','zfbA'],capture_output=True,text=True,check=True).stdout
        if 'pfifo' in ready_qdisc and 'limit 10000p' in ready_qdisc:break
       if p.poll() is not None:raise RuntimeError('benchmark exited before TUN up')
       time.sleep(.001)
      else:raise RuntimeError('TUN did not finish setup (UP and qlen10000)')
      if case=='up8':subprocess.run(['ip','link','set','dev','zfbA','txqueuelen','100000'],check=True)
      actual=int(Path('/sys/class/net/zfbA/tx_queue_len').read_text());assert actual==(100000 if case=='up8' else 10000),actual
      qdisc=subprocess.run(['tc','qdisc','show','dev','zfbA'],capture_output=True,text=True,check=True).stdout
      stdout,stderr=p.communicate(timeout=180)
     except BaseException:p.kill();p.communicate();raise
     finally:placement_stop.set();placer.join()
     assert not placement.get('error'),placement
     assert all(any(t['name']==name and t['cpu']==cpu and t['first_sec']<2 for t in placement['threads']) for name,cpu in role_cpus.items()),placement
     m=json.loads(stdout);row={'case':case,'rep':rep,'warmup':rep<0,'variant':v,'command':cmd,'started':start,'elapsed':time.time()-start,'exit_code':p.returncode,'measurement':m,'stdout':stdout,'stderr':stderr,'tun_tx_queue_len':actual,'qdisc':qdisc,'placement':placement,'loadavg':Path('/proc/loadavg').read_text()}
     out.write(json.dumps(row)+'\n');print(case,rep,v,p.returncode,m['ok'],flush=True)
     assert p.returncode==0 and m['ok'] and not m['errors']
     assert m['server_app']['pattern_errors']==m['server_app']['bad_headers']==0
     if case.startswith('connect'):assert m['results']['success']==m['results']['attempted']==4000 and not m['results']['failures']
 finally:cleanup()
assert all(hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256'] for b in meta['binaries'].values())
meta['finished']=time.time();(r/'network-placement-aa-meta.json').write_text(json.dumps(meta,indent=2));print('ALL_DONE',flush=True)
