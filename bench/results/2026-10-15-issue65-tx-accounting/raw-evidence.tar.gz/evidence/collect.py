#!/usr/bin/env python3
from pathlib import Path
import subprocess
import json
import hashlib
import time
import tarfile

r = Path(__file__).resolve().parent
exp = r.parent
repo = Path('/workspace')

commands = {
    'uname': ['uname', '-a'],
    'cpu': ['lscpu'],
    'test_processes': ['ps', '-C', 'zfbench', '-C', 'pareto_probe', '-o', 'pid=,comm='],
    'default_rustc': ['rustc', '-V'],
    'rustc_192': ['rustc', '+1.92.0', '-V'],
    'rustup': ['rustup', '--version'],
}
env = {
    'captured_at': time.time(),
    'loadavg': Path('/proc/loadavg').read_text(),
    'meminfo': Path('/proc/meminfo').read_text(),
    'governors': {
        str(p): p.read_text().strip()
        for p in Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_governor')
    },
}
for k, cmd in commands.items():
    p = subprocess.run(cmd, capture_output=True, text=True)
    env[k] = {
        'command': cmd,
        'returncode': p.returncode,
        'stdout': p.stdout,
        'stderr': p.stderr,
    }
(r / 'environment-after.json').write_text(json.dumps(env, indent=2))

versions = {
    'B': '8b3f418f15f473baf5dce043c981ab753f0a5a11 (#20)',
    'D': 'c2ae50439e50c081940b951bd075a6ce4bb41335 (main before #56)',
    'F': '3459562746e689fc5ec78c5b1764b0bba3465363 (#56 TX baseline; src/budget.rs and src/buf.rs identical to ebcd6dd961ecaf4063c5cf0d58e11653fed70c2c)',
    'P1': 'F + p1-peer-cache-recycle.patch (peer cache + lease shell recycling only)',
    'G': 'F + candidate.patch (full Issue #65 TX accounting optimization; src/budget.rs and src/buf.rs identical to worktree)',
    'G2': 'same source as G, independently built in target-G2',
}
(r / 'versions.json').write_text(json.dumps(versions, indent=2) + '\n')

roots = {
    'B': exp / 'BV',
    'D': exp / 'DV',
    'F': exp / 'FV',
    'P1': exp / 'P1',
    'G': exp / 'G',
    'G2': exp / 'G2',
}
inputs = {}
with tarfile.open(r / 'inputs.tar.gz', 'w:gz') as archive:
    for v, p in roots.items():
        inputs[v] = {}
        for sub in [
            'Cargo.toml',
            'Cargo.lock',
            'src',
            'tests',
            'examples',
            'bench/src',
            'bench/Cargo.toml',
            'bench/README.md',
        ]:
            base = p / sub
            if not base.exists():
                continue
            archive.add(base, arcname=f'{v}/{sub}')
            for f in ([base] if base.is_file() else sorted(base.rglob('*'))):
                if f.is_file():
                    inputs[v][str(f.relative_to(p))] = hashlib.sha256(
                        f.read_bytes()
                    ).hexdigest()
(r / 'inputs-sha256.json').write_text(json.dumps(inputs, indent=2))

target_map = {
    'B': exp / 'target-BV/release/examples/pareto_probe',
    'D': exp / 'target-DV/release/examples/pareto_probe',
    'F': exp / 'target-FV/release/examples/pareto_probe',
    'P1': exp / 'target-P1/release/examples/pareto_probe',
    'G': exp / 'target-G/release/examples/pareto_probe',
    'G2': exp / 'target-G2/release/examples/pareto_probe',
}
binaries = {
    str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in target_map.values()
}
(r / 'binary-manifest.json').write_text(json.dumps(binaries, indent=2) + '\n')
(r / 'binary-sha256.txt').write_text(
    '\n'.join(f'{sha}  {path}' for path, sha in binaries.items()) + '\n'
)

verify_dis = {}
for v, fname in [
    ('B', 'verify-BV.txt'),
    ('D', 'verify-DV.txt'),
    ('F', 'verify-FV.txt'),
    ('P1', 'verify-P1.txt'),
    ('G', 'verify-G.txt'),
    ('G2', 'verify-G2.txt'),
]:
    src = exp / fname
    dst = r / fname
    dst.write_bytes(src.read_bytes())
    verify_dis[v] = hashlib.sha256(dst.read_bytes()).hexdigest()
(r / 'fullscan-layout.json').write_text(
    json.dumps(
        {
            'section': '.text.zf_probe_verify',
            'address_range': '0x1d000..0x1d180',
            'disassembly_sha256': verify_dis,
            'D_F_P1_G_G2_identical': len(
                {verify_dis[k] for k in ['D', 'F', 'P1', 'G', 'G2']}
            )
            == 1,
        },
        indent=2,
    )
    + '\n'
)

files = [
    p
    for p in r.iterdir()
    if p.is_file()
    and p.name
    not in [
        'evidence-sha256.json',
        'validation.txt',
        'SHA256SUMS',
        'raw-evidence.tar.gz',
    ]
    and p.suffix
    in ['.json', '.jsonl', '.log', '.txt', '.py', '.sh', '.patch', '.gz', '.md', '.png', '.svg', '.rs']
]
(r / 'evidence-sha256.json').write_text(
    json.dumps(
        {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},
        indent=2,
    )
)
print('Collected', len(files), 'evidence files')
