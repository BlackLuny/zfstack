#!/usr/bin/env python3
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

r = Path(__file__).resolve().parent
s = json.loads((r / 'summary.json').read_text())
fig, axs = plt.subplots(1, 2, figsize=(13, 4.8), layout='constrained')
for ax, size in zip(axs, [64, 1400]):
    for v, label, color, shift in [
        ('F', 'main ebcd6dd (after #56/#64)', '#d15f24', -0.13),
        ('G', 'Issue #65 optimized', '#2377ae', 0.13),
    ]:
        vals = [
            s['micro']['cases'][f'{mode}_{size}']['comparisons'][f'{v}/B']
            for mode in ['tx-alloc', 'tx-alloc-pooled', 'tx-alloc-migrate']
        ]
        y = [x['median'] for x in vals]
        lo = [y[i] - x['ci95'][0] for i, x in enumerate(vals)]
        hi = [x['ci95'][1] - y[i] for i, x in enumerate(vals)]
        ax.errorbar(
            [x + shift for x in range(3)],
            y,
            yerr=[lo, hi],
            fmt='o',
            capsize=5,
            label=label,
            color=color,
        )
    ax.set_xticks(
        range(3),
        ['Uncached (cache=0)', 'Cached, same peer', 'Cached, alternating peers'],
    )
    ax.tick_params(axis='x', rotation=12)
    ax.set_title(f'{size}-byte push / verify / consume')
    ax.set_ylabel('CPU cost relative to #20 (%)')
    ax.axhline(0, color='black', lw=0.8)
    ax.grid(axis='y', alpha=0.25)
    ax.legend()
fig.suptitle('Issue #65 TX accounting: 12 randomized paired blocks; 95% bootstrap intervals')
fig.savefig(r / 'tx-accounting.png', dpi=160)
fig.savefig(r / 'tx-accounting.svg')

lines = [
    '# Paired work-loop CPU comparisons',
    '',
    'Positive means more CPU. Each cell is median paired percent change [95% bootstrap interval].',
    '',
    '| Case | main (#56/#64) / #20 | optimized / main | optimized / #20 | A/A G2 / G |',
    '|---|---:|---:|---:|---:|',
]
for c, e in sorted(s['micro']['cases'].items()):
    cells = []
    for k in ['F/B', 'G/F', 'G/B', 'G2/G']:
        x = e['comparisons'][k]
        cells.append(f"{x['median']:+.2f}% [{x['ci95'][0]:+.2f}, {x['ci95'][1]:+.2f}]")
    lines.append('| ' + c + ' | ' + ' | '.join(cells) + ' |')
(r / 'micro-table.md').write_text('\n'.join(lines) + '\n')
