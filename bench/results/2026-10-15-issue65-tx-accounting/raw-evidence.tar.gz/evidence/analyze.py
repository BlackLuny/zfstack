#!/usr/bin/env python3
from pathlib import Path
import json
import statistics as S
import random
import collections

r = Path(__file__).resolve().parent


def paired(a, b):
    vals = [(y / x - 1) * 100 for x, y in zip(a, b)]
    rng = random.Random(22)
    boot = sorted(S.median(rng.choices(vals, k=len(vals))) for _ in range(5000))
    return {
        'n': len(vals),
        'median': S.median(vals),
        'ci95': [boot[125], boot[4875]],
        'values': vals,
    }


def analyze_suite(name, variants):
    meta = json.loads((r / f'{name}-meta.json').read_text())
    assert 'finished' in meta
    rows = [json.loads(l) for l in (r / f'{name}.jsonl').read_text().splitlines()]
    g = collections.defaultdict(dict)
    seen = set()
    for row in rows:
        key = (row['case'], row['rep'], row['variant'])
        assert key not in seen, key
        seen.add(key)
        assert row['warmup'] == (row['rep'] < 0)
        m = row['measurement']
        assert (
            row['exit_code'] == 0
            and m['ok']
            and m['checksum_u64'] == m['expected_checksum_u64']
            and m['final_reserved_bytes'] == 0
        ), key
        assert m.get('verification_method') == 'portable_full_scan_v1', key
        assert row['binary_sha256'] == meta['binary_sha256'][row['variant']]
        g[(row['case'], row['rep'])][row['variant']] = m
    for key, v in g.items():
        assert set(v) == set(variants), (key, v.keys())
        for f in [
            'operations',
            'effective_bytes',
            'allocation_requested_bytes',
            'checksum_u64',
            'expected_checksum_u64',
            'connections_checked',
            'verification_method',
        ]:
            assert len({m[f] for m in v.values()}) == 1, (key, f)
        if key[0].startswith('tx-alloc'):
            for f in ['warmup_reserved_bytes', 'retained_reserved_bytes_before_drop']:
                assert len({m[f] for k, m in v.items() if k != 'B'}) == 1, (key, f)
    assert len(rows) == len(meta['cases']) * (meta['pairs'] + 1) * len(variants)
    assert seen == {
        (c['name'], rep, v)
        for c in meta['cases']
        for rep in range(-1, meta['pairs'])
        for v in variants
    }
    out = {}
    for case in sorted({key[0] for key in g}):
        groups = [v for (c, rep), v in sorted(g.items()) if c == case and rep >= 0]
        assert len(groups) == meta['pairs']
        entry = {'n': len(groups), 'ns_per_op': {}, 'comparisons': {}, 'ledger': {}}
        for v in variants:
            entry['ns_per_op'][v] = S.median(
                p[v]['work_cpu_ns_per_operation'] for p in groups
            )
            entry['ledger'][v] = {
                f: S.median(p[v][f] for p in groups)
                for f in ['warmup_reserved_bytes', 'retained_reserved_bytes_before_drop']
                if groups[0][v][f] is not None
            }
        comparisons = (
            [('B', 'F'), ('F', 'G'), ('B', 'G'), ('G', 'G2')]
            if 'B' in variants
            else [('F', 'P1'), ('P1', 'G'), ('F', 'G')]
        )
        for a, b in comparisons:
            entry['comparisons'][f'{b}/{a}'] = paired(
                [p[a]['work_cpu_ns'] for p in groups],
                [p[b]['work_cpu_ns'] for p in groups],
            )
        out[case] = entry
    return {'rows': len(rows), 'cases': out}


out = {
    'micro': analyze_suite('micro', ['B', 'F', 'G', 'G2']),
    'ablation': analyze_suite('ablation', ['F', 'P1', 'G']),
    'boundary': analyze_suite('boundary', ['B', 'F', 'G', 'G2']),
}
if (r / 'pilot-pre-fmt-micro.jsonl').exists():
    out['pilot_pre_fmt'] = {
        'micro': analyze_suite('pilot-pre-fmt-micro', ['B', 'F', 'G', 'G2']),
        'ablation': analyze_suite('pilot-pre-fmt-ablation', ['F', 'P1', 'G']),
        'boundary': analyze_suite('pilot-pre-fmt-boundary', ['B', 'F', 'G', 'G2']),
    }
(r / 'summary.json').write_text(json.dumps(out, indent=2))

print('=== MICRO (27 cases x 12 blocks) ===')
for c, e in sorted(out['micro']['cases'].items()):
    ns = ' '.join(f'{v}={e["ns_per_op"][v]:.2f}ns' for v in ['B', 'F', 'G', 'G2'])
    cmps = ' | '.join(
        f'{k}: {x["median"]:+.2f}% [{x["ci95"][0]:+.2f},{x["ci95"][1]:+.2f}]'
        for k, x in e['comparisons'].items()
    )
    print(f'{c:22s} | {ns} | {cmps}')

print('\n=== ABLATION (6 cases x 12 blocks) ===')
for c, e in sorted(out['ablation']['cases'].items()):
    ns = ' '.join(f'{v}={e["ns_per_op"][v]:.2f}ns' for v in ['F', 'P1', 'G'])
    cmps = ' | '.join(
        f'{k}: {x["median"]:+.2f}% [{x["ci95"][0]:+.2f},{x["ci95"][1]:+.2f}]'
        for k, x in e['comparisons'].items()
    )
    print(f'{c:22s} | {ns} | {cmps}')

print('\n=== BOUNDARY (4 cases x 12 blocks) ===')
for c, e in sorted(out['boundary']['cases'].items()):
    ns = ' '.join(f'{v}={e["ns_per_op"][v]:.2f}ns' for v in ['B', 'F', 'G', 'G2'])
    cmps = ' | '.join(
        f'{k}: {x["median"]:+.2f}% [{x["ci95"][0]:+.2f},{x["ci95"][1]:+.2f}]'
        for k, x in e['comparisons'].items()
    )
    print(f'{c:22s} | {ns} | {cmps}')

print(
    f'\nValidated micro: {out["micro"]["rows"]}, ablation: {out["ablation"]["rows"]}, boundary: {out["boundary"]["rows"]}'
)
