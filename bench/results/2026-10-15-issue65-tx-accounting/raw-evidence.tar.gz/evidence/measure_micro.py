#!/usr/bin/env python3
import json
import subprocess
import random
import time
import hashlib
import sys
from pathlib import Path

r = Path('/tmp/issue65-exp/results')

def run_suite(out_prefix, variants, cases, bins, versions):
    (r / f'{out_prefix}-cases.json').write_text(json.dumps(cases, indent=2))
    hashes = {v: hashlib.sha256(p.read_bytes()).hexdigest() for v, p in bins.items()}
    meta = {
        'versions': versions,
        'pairs': 12,
        'warmup_blocks': 1,
        'affinity': '3',
        'binary_sha256': hashes,
        'cases': cases,
        'order': 'deterministic shuffled complete blocks seed=122+case*100+block',
        'started': time.time(),
    }
    (r / f'{out_prefix}-meta.json').write_text(json.dumps(meta, indent=2))
    with (r / f'{out_prefix}.jsonl').open('w', buffering=1) as out:
        for ci, case in enumerate(cases):
            for rep in range(-1, 12):
                order = variants.copy()
                random.Random(122 + ci * 100 + rep).shuffle(order)
                for pos, v in enumerate(order):
                    cmd = ['taskset', '-c', '3', str(bins[v]), *case['args']]
                    before = Path('/proc/stat').read_text().splitlines()[:9]
                    start = time.time()
                    p = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
                    row = {
                        'case': case['name'],
                        'rep': rep,
                        'warmup': rep < 0,
                        'variant': v,
                        'position': pos,
                        'command': cmd,
                        'binary_sha256': hashes[v],
                        'exit_code': p.returncode,
                        'started': start,
                        'elapsed': time.time() - start,
                        'stdout': p.stdout,
                        'stderr': p.stderr,
                        'proc_stat_before': before,
                        'loadavg': Path('/proc/loadavg').read_text(),
                    }
                    row['measurement'] = json.loads(p.stdout)
                    out.write(json.dumps(row) + '\n')
                    m = row['measurement']
                    if (
                        p.returncode
                        or not m
                        or not m['ok']
                        or m['checksum_u64'] != m['expected_checksum_u64']
                        or m['final_reserved_bytes'] != 0
                    ):
                        raise RuntimeError(f'Invalid {case["name"]} {v} {rep}: {p.stderr}')
            print(f'{out_prefix}: {ci+1}/{len(cases)} {case["name"]} done', flush=True)
    meta['finished'] = time.time()
    (r / f'{out_prefix}-meta.json').write_text(json.dumps(meta, indent=2))


mode_arg = sys.argv[1] if len(sys.argv) > 1 else 'micro'

if mode_arg in ('ablation', 'ablation_only', 'boundary'):
    ablation_cases = []
    for mode in ['tx-alloc', 'tx-alloc-pooled', 'tx-alloc-migrate']:
        for size in [64, 1400]:
            n = min(2000000, max(20000, 134217728 // size))
            ablation_cases.append({
                'name': f'{mode}_{size}',
                'args': [mode, '--iterations', str(n), '--payload', str(size)],
            })
    run_suite(
        'ablation',
        ['F', 'P1', 'G'],
        ablation_cases,
        {
            'F': Path('/tmp/issue65-exp/target-FV/release/examples/pareto_probe'),
            'P1': Path('/tmp/issue65-exp/target-P1/release/examples/pareto_probe'),
            'G': Path('/tmp/issue65-exp/target-G/release/examples/pareto_probe'),
        },
        {
            'F': 'ebcd6dd961ecaf4063c5cf0d58e11653fed70c2c (main after #56/#64)',
            'P1': 'Peer cache + lease shell recycling only (without fused index+block migration/park)',
            'G': 'Full Issue #65 TX accounting optimization',
        },
    )
    if mode_arg == 'ablation_only':
        sys.exit(0)
    boundary_cases = []
    for mode in ['tx-alloc-pooled', 'tx-alloc-migrate']:
        for size in [65535, 65537]:
            boundary_cases.append({
                'name': f'{mode}_{size}',
                'args': [mode, '--iterations', '20000', '--payload', str(size)],
            })
    run_suite(
        'boundary',
        ['B', 'F', 'G', 'G2'],
        boundary_cases,
        {
            'B': Path('/tmp/issue65-exp/target-BV/release/examples/pareto_probe'),
            'F': Path('/tmp/issue65-exp/target-FV/release/examples/pareto_probe'),
            'G': Path('/tmp/issue65-exp/target-G/release/examples/pareto_probe'),
            'G2': Path('/tmp/issue65-exp/target-G2/release/examples/pareto_probe'),
        },
        {
            'B': '8b3f418f15f473baf5dce043c981ab753f0a5a11 (#20)',
            'F': 'ebcd6dd961ecaf4063c5cf0d58e11653fed70c2c (main after #56/#64)',
            'G': 'Issue #65 TX accounting optimization candidate',
            'G2': 'Same source as G, independently built in target-G2',
        },
    )
else:
    cases = []
    for mode in ['tx-alloc', 'tx-alloc-pooled', 'tx-alloc-migrate']:
        for size in [1, 64, 512, 1400, 4096, 65536]:
            n = min(2000000, max(20000, 134217728 // size))
            cases.append({
                'name': f'{mode}_{size}',
                'args': [mode, '--iterations', str(n), '--payload', str(size)],
            })
    for name, args in [
        ('budget', ['budget', '--iterations', '3000000', '--flows', '8', '--payload', '2112']),
        ('budget_handle', ['budget-handle', '--iterations', '3000000', '--flows', '8', '--payload', '2112']),
        ('rx64', ['rx-chunk', '--iterations', '1000000', '--flows', '8', '--payload', '64']),
        ('heap_pop', ['heap-pop', '--iterations', '10000', '--flows', '4096']),
        ('down8', ['pump-down', '--iterations', '2', '--flows', '8', '--payload', '4194304']),
        ('up8', ['pump-up', '--iterations', '2', '--flows', '8', '--payload', '4194304']),
        ('short64', ['pump-bidi', '--iterations', '20', '--flows', '64', '--payload', '4096', '--no-pacing']),
        ('short256', ['pump-bidi', '--iterations', '5', '--flows', '256', '--payload', '4096', '--no-pacing']),
        ('up256', ['pump-up', '--iterations', '1', '--flows', '256', '--payload', '262144']),
    ]:
        cases.append({'name': name, 'args': args})
    run_suite(
        'micro',
        ['B', 'F', 'G', 'G2'],
        cases,
        {
            'B': Path('/tmp/issue65-exp/target-BV/release/examples/pareto_probe'),
            'F': Path('/tmp/issue65-exp/target-FV/release/examples/pareto_probe'),
            'G': Path('/tmp/issue65-exp/target-G/release/examples/pareto_probe'),
            'G2': Path('/tmp/issue65-exp/target-G2/release/examples/pareto_probe'),
        },
        {
            'B': '8b3f418f15f473baf5dce043c981ab753f0a5a11 (#20)',
            'F': 'ebcd6dd961ecaf4063c5cf0d58e11653fed70c2c (main after #56/#64)',
            'G': 'Issue #65 TX accounting optimization candidate',
            'G2': 'Same source as G, independently built in target-G2',
        },
    )
    (r / 'cases.json').write_text(json.dumps(cases, indent=2))
