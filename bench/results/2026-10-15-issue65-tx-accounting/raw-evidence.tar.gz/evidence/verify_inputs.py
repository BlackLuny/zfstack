#!/usr/bin/env python3
from pathlib import Path
import json
import hashlib
import tarfile
import subprocess

r = Path(__file__).resolve().parent
repo = Path('/workspace')
j = lambda name: json.loads((r / name).read_text())

checked = 0
for name, sha in j('evidence-sha256.json').items():
    assert hashlib.sha256((r / name).read_bytes()).hexdigest() == sha, name
    checked += 1

inputs = j('inputs-sha256.json')
count = 0
with tarfile.open(r / 'inputs.tar.gz', 'r:gz') as t:
    for v, files in inputs.items():
        for rel, sha in files.items():
            data = t.extractfile(f'{v}/{rel}').read()
            assert hashlib.sha256(data).hexdigest() == sha, (v, rel)
            if v == 'F' and rel.startswith('src/'):
                original = subprocess.run(
                    ['git', 'show', f'3459562746e689fc5ec78c5b1764b0bba3465363:{rel}'],
                    cwd=repo,
                    capture_output=True,
                    check=True,
                ).stdout
                assert data == original, (v, rel, 'not 3459562')
            if v in ['G', 'G2'] and rel in [
                'src/budget.rs',
                'src/buf.rs',
                'src/budget/tests/qa.rs',
            ]:
                assert data == (repo / rel).read_bytes(), (v, rel, 'not worktree')
            count += 1
    assert t.extractfile('P1/src/budget.rs').read() == (r / 'budget-p1.rs').read_bytes()
    assert t.extractfile('P1/src/buf.rs').read() == (r / 'buf-p1.rs').read_bytes()

assert inputs['G'] == inputs['G2'], 'independent sources differ'
for rel, sha in inputs['F'].items():
    if rel in [
        'Cargo.toml',
        'Cargo.lock',
        'bench/Cargo.toml',
        'examples/pareto_probe.rs',
    ] or rel.startswith('bench/src/'):
        for v in ['B', 'D', 'P1', 'G', 'G2']:
            assert inputs[v][rel] == sha, (v, rel, 'nonuniform harness/lock/probe')
    if rel.startswith('src/') and rel not in ['src/budget.rs', 'src/buf.rs']:
        for v in ['P1', 'G', 'G2']:
            assert inputs[v][rel] == sha, (v, rel, 'modified non-TX src file')

bins = j('binary-manifest.json')
target_dir_for = {
    'B': 'target-BV',
    'D': 'target-DV',
    'F': 'target-FV',
    'P1': 'target-P1',
    'G': 'target-G',
    'G2': 'target-G2',
}
for name in ['micro', 'ablation', 'boundary']:
    meta = j(f'{name}-meta.json')
    for v, sha in meta['binary_sha256'].items():
        path = f'/tmp/issue65-exp/{target_dir_for[v]}/release/examples/pareto_probe'
        assert bins[path] == sha, (name, v)

layout = j('fullscan-layout.json')
assert layout['D_F_P1_G_G2_identical'], layout

env = j('environment-after.json')
assert not env['test_processes']['stdout'].strip(), env['test_processes']
assert '1.94.1' in env['default_rustc']['stdout'], env['default_rustc']
assert '1.92.0' in env['rustc_192']['stdout'], env['rustc_192']
assert (
    subprocess.run(
        ['git', 'diff', 'ebcd6dd961ecaf4063c5cf0d58e11653fed70c2c', '--', 'src/budget.rs', 'src/buf.rs'],
        cwd=repo,
        capture_output=True,
        check=True,
    ).stdout
    == (r / 'candidate.patch').read_bytes()
)
assert 'Finished' in (r / 'clippy-linux.log').read_text()
assert 'Finished' in (r / 'no-default-1.92.log').read_text()

msg = (
    f'Validated {checked} evidence hashes, {count} archived input files; '
    f'main/source/patch and independent builds match; uniform lock/probe/harness; '
    f'all measured binary hashes and verifier layouts match; Linux lint/build/tests completed.'
)
(r / 'validation.txt').write_text(msg + '\n')
print(msg)
