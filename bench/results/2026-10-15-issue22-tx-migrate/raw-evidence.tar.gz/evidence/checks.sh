#!/usr/bin/env bash
set -euo pipefail
r=/root/zftxmigrate22-20261015
python3 -c 'import json; assert "finished" in json.load(open("/root/zftxmigrate22-20261015/fullscan-followup-meta.json"))'
mkdir -p "$r/python-suite"
tar xzf "$r/zf22-pareto-tests.tar.gz" -C "$r/python-suite"
(cd "$r/python-suite" && PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s bench/pareto -p 'test_*.py') > "$r/python-tests.log" 2>&1
export PATH=/root/.cargo/bin:$PATH
export RUSTUP_HOME=/root/zfverify22-20261015/rustup
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$r/target-checks"
cd "$r/FV"
cargo +1.92.0 test -p zfstack --release --features tokio,test-peer > "$r/linux-tests.log" 2>&1
cargo +1.92.0 test -p zfstack --release --features tokio,test-peer --example pareto_probe > "$r/linux-probe-tests.log" 2>&1
cargo +1.92.0 test -p zfstack --release --features tokio,test-peer issue37_splice_256_streams_keep_progressing_with_delayed_acks -- --ignored --nocapture > "$r/linux-256-stress.log" 2>&1
cargo +1.92.0 build -p zfstack --no-default-features > "$r/linux-no-default.log" 2>&1
printf 'CHECKS_DONE\n'
