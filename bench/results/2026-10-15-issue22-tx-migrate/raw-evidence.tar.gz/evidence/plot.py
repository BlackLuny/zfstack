from pathlib import Path
import json,csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path(__file__).parent;s=json.loads((r/'summary.json').read_text())
series=[('fullscan-crossover','FP/DP','libc bcmp, 24 pairs','#d97706'),('fullscan-crossover','FV/DV','full scan, 24 pairs','#2563eb'),('fullscan-followup','FV/DV','full scan, independent 12 pairs','#15803d')]
fig,axes=plt.subplots(1,2,figsize=(12,3.6),layout='constrained')
for ax,case,title,limits in zip(axes,['tx-alloc-migrate_65536','tx-alloc-pooled_64'],['64 KiB, alternating peers','64 B, cached, same peer'],[(-1.2,5.6),(-20,1)]):
 for i,(tag,pair,label,color) in enumerate(series):
  x=s[tag][case]['pairs'][pair];v=x['median_pct'];a,b=x['ci95'];ax.errorbar(v,i,xerr=[[v-a],[b-v]],fmt='o',capsize=4,color=color,markersize=7)
  ax.text(.98,i+.23,f'{v:+.2f}% [{a:+.2f}, {b:+.2f}]',ha='right',va='center',transform=ax.get_yaxis_transform(),fontsize=9)
 ax.axvline(0,color='#64748b',lw=1);ax.set_xlim(*limits);ax.set_ylim(2.5,-.55);ax.set_yticks(range(3),[v[2] for v in series]);ax.set_title(title,fontweight='bold');ax.set_xlabel('F / main CPU change (%) — lower is better');ax.grid(axis='x',alpha=.2);ax.spines[['top','right']].set_visible(False)
fig.suptitle('Verifier-dependent CPU difference; production library unchanged',fontsize=13)
fig.savefig(r/'tx-verifier.png',dpi=180);fig.savefig(r/'tx-verifier.pdf');plt.close(fig)
with (r/'cpu-table.csv').open('w',newline='') as out:
 w=csv.writer(out);w.writerow(['dataset','case','comparison','pairs','median_change_pct','ci95_lower_pct','ci95_upper_pct'])
 for tag in ['fullscan-crossover','fullscan-followup']:
  for case,results in sorted(s[tag].items()):
   for pair,v in results['pairs'].items():w.writerow([tag,case,pair,v['n'],v['median_pct'],*v['ci95']])
