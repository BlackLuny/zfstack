from pathlib import Path
import subprocess,itertools,random,json,time,hashlib
r=Path('/root/zftxmigrate22-20261015');vs=['DP','FP','JP'];orders=list(itertools.permutations(vs));random.Random(1622).shuffle(orders)
meta={'started':time.time(),'event':'cpu-clock:u','frequency':997,'iterations':200000,'payload':65536,'orders':orders,'binaries':{v:hashlib.sha256((r/f'target-{v}/release/examples/pareto_probe').read_bytes()).hexdigest() for v in vs}}
(r/'profile-pairs-meta.json').write_text(json.dumps(meta,indent=2))
with (r/'profile-pairs.jsonl').open('x',buffering=1) as out:
 for rep,order in enumerate(orders):
  for v in order:
   tag=f'profile-{rep}-{v}';data=r/(tag+'.data');cmd=['perf','record','-e','cpu-clock:u','-F','997','-o',str(data),'--','taskset','-c','3',str(r/f'target-{v}/release/examples/pareto_probe'),'tx-alloc-migrate','--payload','65536','--iterations','200000'];p=subprocess.run(cmd,capture_output=True,text=True,timeout=60);m=json.loads(p.stdout);assert p.returncode==0 and m['ok'] and m['checksum_u64']==m['expected_checksum_u64'] and m['final_reserved_bytes']==0
   report=subprocess.run(['perf','report','-i',str(data),'--stdio','--percent-limit','0.1','--sort','symbol'],capture_output=True,text=True,check=True).stdout
   (r/(tag+'.txt')).write_text(report);(r/(tag+'.log')).write_text(p.stderr);out.write(json.dumps({'rep':rep,'variant':v,'measurement':m,'command':cmd,'stderr':p.stderr,'report':report})+'\n');print(rep,v,'done',flush=True)
meta['finished']=time.time();(r/'profile-pairs-meta.json').write_text(json.dumps(meta,indent=2))
