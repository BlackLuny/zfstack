import subprocess,json,hashlib,struct,re
from pathlib import Path
r=Path('/root/zftxmigrate22-20261015')
paths={'D':Path('/root/zfverify22-20261015/target-D/release/examples/pareto_probe'),'F':Path('/root/zfopt22-20261015/target-F/release/examples/pareto_probe')}
paths.update({v:r/f'target-{v}/release/examples/pareto_probe' for v in ['DO','FO','DA','FA','FA2','BA','DP','FP','FP2','BP']})
def at_vaddr(data,addr,n):
 off=struct.unpack_from('<Q',data,32)[0];size,num=struct.unpack_from('<HH',data,54)
 for i in range(num):
  typ,flags,o,va,pa,fs,ms,al=struct.unpack_from('<IIQQQQQQ',data,off+i*size)
  if typ==1 and va<=addr and addr+n<=va+fs:return data[o+addr-va:o+addr-va+n]
 raise ValueError(hex(addr))
rows={}
for v,p in paths.items():
 data=p.read_bytes();dis=subprocess.check_output(['objdump','-Cd',str(p)],text=True)
 if v in ['D','F']:start={'D':0x28b00,'F':0x28bf5}[v];n=81;fn=None
 else:
  fn=int(re.search(r'^([0-9a-f]+) <pareto_probe::verify>:',dis,re.M).group(1),16)
  # Locate the branch back to the unrolled loop. Loop instruction count does not rely on guessed cache size.
  m=re.search(r'^\s*([0-9a-f]+):\s+75 [0-9a-f]{2}\s+jne\s+([0-9a-f]+) <pareto_probe::verify\+0x120>',dis,re.M)
  assert m,(v,hex(fn));start=int(m[2],16);n=int(m[1],16)+2-start
 loop=at_vaddr(data,start,n)
 rows[v]={'binary_sha256':hashlib.sha256(data).hexdigest(),'verify_start':hex(fn) if fn else None,'loop_start':hex(start),'loop_len':n,'loop_start_mod16':start%16,'loop_start_mod64':start%64,'loop_cachelines64':(start%64+n+63)//64,'loop_sha256':hashlib.sha256(loop).hexdigest(),'loop_hex':loop.hex()}
 (r/f'{v}-verify-disassembly.txt').write_text(dis[dis.find('<pareto_probe::verify>:')-17:dis.find('<pareto_probe::verify>:')+12500] if fn else '')
assert rows['DP']['loop_sha256']==rows['FP']['loop_sha256']==rows['FP2']['loop_sha256']==rows['BP']['loop_sha256']
assert all(int(rows[v]['verify_start'],16)%4096==0 for v in ['DP','FP','FP2','BP'])
assert rows['DA']['loop_sha256']==rows['FA']['loop_sha256']==rows['FA2']['loop_sha256']==rows['BA']['loop_sha256']
assert all(int(rows[v]['verify_start'],16)%64==0 for v in ['DA','FA','FA2','BA','DP','FP','FP2','BP'])
(r/'code-layout.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({v:{k:row[k] for k in ['verify_start','loop_start','loop_len','loop_start_mod64','loop_cachelines64','loop_sha256']} for v,row in rows.items()},indent=2))
