from pathlib import Path
import tarfile,sys
r=Path('/root/zftxmigrate22-20261015')
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as archive:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ['.json','.jsonl','.log','.txt','.py','.sh','.rs','.gdb','.gz'] and p.name not in ['network.py','page-followup-config.json','export_evidence.py'] and not p.name.endswith('-full-disassembly.txt'):
   archive.add(p,arcname=p.name)
