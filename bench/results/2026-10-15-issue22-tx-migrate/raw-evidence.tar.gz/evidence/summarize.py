import json,sys,random,statistics as st
from pathlib import Path
root=Path(__file__).parent
out={}
for tag in sys.argv[1:]:
 rows=[json.loads(s) for s in (root/(tag+'.jsonl')).read_text().splitlines()]
 by={}
 for r in rows:
  if not r['warmup']:by.setdefault(r['case'],{}).setdefault(r['variant'],{})[r['rep']]=r['measurement']['work_cpu_ns_per_operation']
 comparisons=[('F','D'),('P1','D'),('F','P1'),('F2','F'),('FO','DO'),('FA','DA'),('FA2','FA'),('FA','BA'),('FP','DP'),('FP2','FP'),('FP','BP'),('G','D'),('G','F'),('G2','G'),('GP','DP'),('GP','FP'),('GP2','GP'),('FC','DC'),('HC','DC'),('HC','FC'),('HC2','HC'),('HP','DP'),('HP','FP'),('JP','DP'),('JP','FP'),('JP2','JP'),('FV','DV'),('FV2','FV')]
 out[tag]={}
 for case,vs in by.items():
  s={'median_ns':{v:st.median(rs.values()) for v,rs in vs.items()},'pairs':{}}
  for cand,base in comparisons:
   if cand not in vs or base not in vs:continue
   reps=sorted(vs[cand].keys() & vs[base].keys());changes=[100*(vs[cand][i]/vs[base][i]-1) for i in reps]
   rng=random.Random(422);boot=sorted(st.median(rng.choices(changes,k=len(changes))) for _ in range(10000))
   s['pairs'][cand+'/'+base]={'n':len(changes),'median_pct':st.median(changes),'ci95':[boot[249],boot[9749]],'values_pct':changes}
  out[tag][case]=s
(root/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
for tag,cases in out.items():
 print(tag)
 for c,s in sorted(cases.items()):print(c,{p:[round(v['median_pct'],3),[round(x,3) for x in v['ci95']]] for p,v in s['pairs'].items()})
