set pagination off
set confirm off
set disable-randomization off
set $hits=0
break _ZN12pareto_probe6verify17h2f5e217ffb7e1e81E
commands
silent
set $hits=$hits+1
printf "LAYOUT hit=%d data=%p expected=%p bytes=%lu data_mod4096=%lu expected_mod4096=%lu distance=%ld checksum_mod4096=%lu\n", $hits, $rsi, $rcx, $rdx, ((unsigned long)$rsi & 4095), ((unsigned long)$rcx & 4095), ((long)$rsi-(long)$rcx), ((unsigned long)$r9 & 4095)
if $hits==2
disable 1
end
continue
end
run
