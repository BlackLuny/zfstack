from pathlib import Path
import json,hashlib
r=Path(__file__).parent
manifest=json.loads((r/'evidence-sha256.json').read_text())
verified=0;remote_only=[]
for name,expected in manifest.items():
 p=r/name
 if not p.is_file():remote_only.append(name);continue
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,name
 verified+=1
print('Verified',verified,'downloaded remote evidence files; remote-only:',remote_only)
