from pathlib import Path
import json,random,time,hashlib,subprocess,itertools,sys
r=Path('/root/zftxmigrate22-20261015');cfg=json.loads(Path(sys.argv[1]).read_text());tag=cfg['tag'];vs=list(cfg['variants']);pairs=cfg['pairs'];seed=cfg['seed'];cases=cfg['cases']
bins={v:Path(p) for v,p in cfg['variants'].items()};hashes={v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in bins.items()}
meta={**cfg,'binary_sha256':hashes,'affinity':'3','started':time.time(),'order':'interleaved cases, complete permutation cycles per case; one warmup block'}
(r/(tag+'-meta.json')).write_text(json.dumps(meta,indent=2));orders={}
for ci,c in enumerate(cases):
 permutations=list(itertools.permutations(vs));random.Random(seed+ci).shuffle(permutations)
 orders[c['name']]=(permutations*((pairs+len(permutations)-1)//len(permutations)))[:pairs]
with (r/(tag+'.jsonl')).open('x',buffering=1) as out:
 for rep in range(-1,pairs):
  case_order=cases.copy();random.Random(seed+1000+rep).shuffle(case_order)
  for c in case_order:
   order=orders[c['name']][rep] if rep>=0 else vs
   for pos,v in enumerate(order):
    cmd=['taskset','-c','3',str(bins[v]),*c['args']];start=time.time();p=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
    try:m=json.loads(p.stdout)
    except json.JSONDecodeError:m=None
    row={'case':c['name'],'rep':rep,'warmup':rep<0,'variant':v,'position':pos,'command':cmd,'binary_sha256':hashes[v],'started':start,'elapsed':time.time()-start,'exit_code':p.returncode,'measurement':m,'stderr':p.stderr,'loadavg':Path('/proc/loadavg').read_text()}
    out.write(json.dumps(row)+'\n')
    assert p.returncode==0 and m and m['ok'] and m['checksum_u64']==m['expected_checksum_u64'] and m['final_reserved_bytes']==0,(c,v,p.stderr)
  print(rep,'done',flush=True)
meta['finished']=time.time();(r/(tag+'-meta.json')).write_text(json.dumps(meta,indent=2))
