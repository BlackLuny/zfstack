import json,hashlib,collections,sys
from pathlib import Path
root=Path(__file__).parent
report={}
for tag in sys.argv[1:]:
 cfg=json.loads((root/f'{tag}-meta.json').read_text());assert 'finished' in cfg
 rows=[json.loads(s) for s in (root/f'{tag}.jsonl').read_text().splitlines()]
 assert len(rows)==(cfg['pairs']+1)*len(cfg['variants'])*len(cfg['cases'])
 groups=collections.defaultdict(dict)
 for row in rows:
  m=row['measurement'];assert row['exit_code']==0 and m['ok']
  assert m['checksum_u64']==m['expected_checksum_u64']
  assert m['final_reserved_bytes']==0 and m['all_budget_leases_released']
  assert m['operations']==m['iterations'] and m['effective_bytes']==m['payload_bytes']*m['iterations']
  assert row['binary_sha256']==cfg['binary_sha256'][row['variant']]
  if m['case']=='tx-alloc-migrate':assert m['peers']==2
  group=groups[(row['case'],row['rep'])];assert row['variant'] not in group;group[row['variant']]=m
 for group in groups.values():
  assert set(group)==set(cfg['variants'])
  for key in ['case','iterations','payload_bytes','operations','effective_bytes','checksum_u64','expected_checksum_u64']:
   assert len({m[key] for m in group.values()})==1,(tag,key)
  for a,b in [('F','D'),('F2','F'),('FO','DO'),('FA','DA'),('FA2','FA'),('FP','DP'),('FP2','FP'),('HC','DC'),('HC2','HC'),('HP','DP'),('JP','DP'),('JP2','JP'),('FV','DV'),('FV2','FV')]:
   if a in group and b in group:
    for key in ['verification_method','warmup_reserved_bytes','retained_reserved_bytes_before_drop']:
     assert group[a].get(key)==group[b].get(key),(tag,a,b,key)
 report[tag]={'runs':len(rows),'formal':sum(not x['warmup'] for x in rows),'groups':len(groups),'all_work_checks_and_comparable_ledgers_ok':True}
(root/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
