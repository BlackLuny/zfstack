from pathlib import Path
import subprocess,re,hashlib,json,struct
r=Path('/root/zftxmigrate22-20261015');out={}
for v in ['DV','FV','FV2']:
 p=r/f'target-{v}/release/examples/pareto_probe';dis=subprocess.check_output(['objdump','-Cd',str(p)],text=True);m=re.search(r'^([0-9a-f]+) <pareto_probe::verify>:\n(.*?)(?=\n[0-9a-f]+ <)',dis,re.M|re.S);start=int(m[1],16);fn=m[0];assert 'bcmp@' not in fn and 'memcmp@' not in fn and start%4096==0
 (r/f'{v}-verify-disassembly.txt').write_text(fn)
 instructions={}
 loops=[]
 for line in fn.splitlines()[1:]:
  match=re.match(r'\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s*(.*)',line)
  if not match:continue
  addr=int(match[1],16);b=bytes.fromhex(match[2]);instructions[addr]=b
  branch=re.search(r'\bj\w+\s+([0-9a-f]+) <pareto_probe::verify\+0x',match[3])
  if branch and start<=int(branch[1],16)<addr:
   a=int(branch[1],16);end=addr+len(b);code=b''.join(instructions[k] for k in sorted(instructions) if a<=k<end);loops.append({'offset':hex(a-start),'start':hex(a),'mod64':a%64,'length':end-a,'sha256':hashlib.sha256(code).hexdigest()})
 out[v]={'binary_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'verify_start':hex(start),'loops':loops,'no_bcmp_memcmp_calls':True,'source_sha256':hashlib.sha256((r/v/'examples/pareto_probe.rs').read_bytes()).hexdigest()}
assert out['DV']['loops']==out['FV']['loops']==out['FV2']['loops']
assert len({x['source_sha256'] for x in out.values()})==1
(r/'fullscan-layout.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
