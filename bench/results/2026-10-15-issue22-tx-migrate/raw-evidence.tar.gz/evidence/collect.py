from pathlib import Path
import subprocess,json,hashlib,time,tarfile
r=Path('/root/zftxmigrate22-20261015');old=Path('/root/zfverify22-20261015');prior=Path('/root/zfopt22-20261015')
variants=['DO','FO','DA','FA','FA2','BA','DP','FP','FP2','BP','DPH','FPH','DBD','FBD','G','G2','GP','GP2','DC','FC','HC','HC2','HP','JP','JP2','HPH','JPH','DV','FV','FV2']
def hashes(base):return {str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(base.rglob('*')) if p.is_file()}
proof={'DV_matches_main_src':hashes(r/'DV/src')==hashes(old/'D/src'),'FV_matches_previous_F_src':hashes(r/'FV/src')==hashes(prior/'F/src'),'FV2_matches_FV_src':hashes(r/'FV2/src')==hashes(r/'FV/src')}
assert all(proof.values());(r/'source-equivalence.json').write_text(json.dumps(proof,indent=2)+'\n')
inputs={};bins={}
with tarfile.open(r/'inputs.tar.gz','w:gz') as archive:
 for v in variants:
  base=r/v;inputs[v]={}
  for sub in ['Cargo.toml','Cargo.lock','src','tests','examples','bench/Cargo.toml','bench/src','bench/README.md']:
   p=base/sub
   if not p.exists():continue
   archive.add(p,arcname=v+'/'+sub)
   for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
    if f.is_file():inputs[v][str(f.relative_to(base))]=hashlib.sha256(f.read_bytes()).hexdigest()
  b=r/f'target-{v}/release/examples/pareto_probe';bins[v]={'path':str(b),'sha256':hashlib.sha256(b.read_bytes()).hexdigest()}
(r/'inputs-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n');(r/'binary-manifest.json').write_text(json.dumps(bins,indent=2)+'\n')
for tag in ['baseline','crossover','aligned','page','phases','breakdown','storage-pilot','cache','cache-page','J-pilot','layout-phases','fullscan-crossover','fullscan-followup']:
 meta=json.loads((r/f'{tag}-meta.json').read_text());assert 'finished' in meta
 for v,path in meta['variants'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==meta['binary_sha256'][v],(tag,v)
commands={'uname':['uname','-a'],'cpu':['lscpu'],'namespaces':['ip','netns','list'],'links':['ip','-br','link'],'test_processes':['ps','-C','zfbench','-C','pareto_probe','-o','pid=,comm='],'default_rustc':['/root/.cargo/bin/rustc','-V'],'rustc_1_92':['env','RUSTUP_HOME=/root/zfverify22-20261015/rustup','/root/.cargo/bin/rustc','+1.92.0','-vV'],'libc':['ldd','--version']}
env={'captured_at':time.time(),'loadavg':Path('/proc/loadavg').read_text(),'meminfo':Path('/proc/meminfo').read_text(),'governors':{str(p):p.read_text().strip() for p in Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_governor')}}
for k,cmd in commands.items():
 p=subprocess.run(cmd,capture_output=True,text=True);env[k]={'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(r/'environment-after.json').write_text(json.dumps(env,indent=2)+'\n')
files=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.json','.jsonl','.log','.txt','.py','.sh','.rs','.gdb','.gz'] and p.name not in ['evidence-sha256.json','collect.log']]
(r/'evidence-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},indent=2)+'\n')
print('Collected',len(files),'files. Source equivalence:',proof,'test processes:',repr(env['test_processes']['stdout']))
