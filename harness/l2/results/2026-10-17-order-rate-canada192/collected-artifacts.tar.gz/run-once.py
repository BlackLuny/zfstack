"""One authorized sequence with unconditional service restoration; never restart this file."""
import json,os,signal,subprocess,time
from pathlib import Path
T=Path(__file__).resolve().parent
SHA='97e78aa30d705ce8d0ab2d77ddfb4027270d0be2'
TIMER='zfstack-pr75-order-rate-v2-restore-20261017.timer'
record={'started_unix_ns':time.time_ns(),'tested_sha':SHA,'measurement_launched':False}
# Exclusive start marker is not erased even if a prerequisite fails.
with (T/'launch.json').open('x') as stream:stream.write(json.dumps(record,indent=2)+'\n')
def stop_signal(number,frame):raise KeyboardInterrupt('termination requested')
signal.signal(signal.SIGTERM,stop_signal)
child=None
try:
 assert not list(Path('/var/lock/zfstack-qa').glob('*')),'occupied or quarantined QA lease'
 assert subprocess.check_output(['git','-C',str(T/'source'),'rev-parse','HEAD'],text=True).strip()==SHA
 assert subprocess.check_output(['git','-C',str(T/'source'),'status','--porcelain','--untracked-files=all'],text=True).strip()==''
 subprocess.run(['python3',str(T/'preflight-stop.py')],check=True)
 quiet=json.loads((T/'preflight/quiet-cpu-sample.json').read_text())
 samples=quiet['top_cpu'];total=quiet['total_cpu_percent']
 assert all(row['cpu_percent']<=10 for row in samples) and total<=25,('competing CPU load',samples,total)
 cmd=['python3',str(T/'source/harness/l2/results/2026-10-17-order-rate/order_rate.py'),
      '--expected-sha',SHA,'--output',str(T/'order-rate'),'--domain','zfstack-qa-baremetal-192.99.148.123-24946',
      '--run-id','order-rate-v2-20261017']
 record.update(command=cmd,measurement_launched=True,measurement_started_unix_ns=time.time_ns())
 (T/'launch-state.json').write_text(json.dumps(record,indent=2)+'\n')
 with (T/'driver.log').open('xb') as stream:
  child=subprocess.Popen(cmd,cwd=T/'source',stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  record['driver_pid']=child.pid
  (T/'launch-state.json').write_text(json.dumps(record,indent=2)+'\n')
  record['returncode']=child.wait()
 record['measurement_finished_unix_ns']=time.time_ns()
except BaseException as error:
 record['error']=repr(error)
finally:
 if child is not None and child.poll() is None:
  child.terminate()
  try:child.wait(timeout=30)
  except subprocess.TimeoutExpired:
   # Do not launch competing services while measurement ownership remains unknown.
   record['driver_still_running']=True
 if not record.get('driver_still_running') and (T/'service-control.json').exists():
  record['restore_returncode']=subprocess.run(['python3',str(T/'services.py'),'restore']).returncode
  if record['restore_returncode']==0:
   record['backup_timer_stop_returncode']=subprocess.run(['systemctl','stop',TIMER]).returncode
 elif record.get('driver_still_running'):
  record['restoration_requires_operator']=True
 record['finished_unix_ns']=time.time_ns()
 (T/'launch-result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
