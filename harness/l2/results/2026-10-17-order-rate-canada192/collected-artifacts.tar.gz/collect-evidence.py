"""Collect only this diagnostic's evidence, after verified service restoration."""
import hashlib,json,subprocess,tarfile,time
from pathlib import Path
T=Path(__file__).resolve().parent
finished=json.loads((T/'launch-result.json').read_text())
assert finished.get('restore_returncode')==0,finished
states=json.loads((T/'service-control.json').read_text())
current={}
for unit in states['original']:
 text=subprocess.check_output(['systemctl','show',unit,'-p','ActiveState','-p','SubState','-p','UnitFileState'],text=True)
 current[unit]=dict(line.split('=',1) for line in text.splitlines() if '=' in line)
 assert current[unit]['ActiveState']==states['original'][unit]['ActiveState']
 assert current[unit]['UnitFileState']==states['original'][unit]['UnitFileState']
timer=subprocess.run(['systemctl','is-active','zfstack-pr75-order-rate-v2-restore-20261017.timer'],capture_output=True,text=True)
post={'verified_unix_ns':time.time_ns(),'services':current,'backup_timer':timer.stdout.strip(),
      'lease_files':[p.name for p in Path('/var/lock/zfstack-qa').iterdir()],
      'driver_returncode':finished.get('returncode'),'driver_still_running':finished.get('driver_still_running',False)}
post['source_sha']=subprocess.check_output(['git','-C',str(T/'source'),'rev-parse','HEAD'],text=True).strip()
post['source_status']=subprocess.check_output(['git','-C',str(T/'source'),'status','--porcelain','--untracked-files=all'],text=True).strip()
assert post['source_sha']=='97e78aa30d705ce8d0ab2d77ddfb4027270d0be2' and not post['source_status']
assert post['backup_timer']=='inactive'
(T/'post-restoration-check.json').write_text(json.dumps(post,indent=2)+'\n')
subprocess.run(['python3',str(T/'snapshot.py'),str(T/'preflight/host-final.json')],check=True)
selected=[]
for name in ('order-rate','preflight'):
 for p in sorted((T/name).rglob('*')):
  if p.is_file() and not p.is_symlink():selected.append(p)
for name in ('authorization.json','source-transfer.json','transfer-verification.json','services.py','service-control.json',
             'preflight-stop.py','snapshot.py','run-once.py','launch.json','launch-state.json','launch-result.json',
             'driver.log','orchestrator.log','post-restoration-check.json','collect-evidence.py','remote-recomputed.json'):
 p=T/name
 if p.is_file() and not p.is_symlink():selected.append(p)
index=[{'path':str(p.relative_to(T)),'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected]
with (T/'collected-artifacts.tar.gz').open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as archive:
 for p in selected:archive.add(p,arcname=str(p.relative_to(T)),recursive=False)
archive=T/'collected-artifacts.tar.gz'
manifest={'files':index,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(T/'collected-artifacts.index.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(index),'archive_bytes':manifest['archive_bytes'],'archive_sha256':manifest['archive_sha256'],'restoration':post}),flush=True)
