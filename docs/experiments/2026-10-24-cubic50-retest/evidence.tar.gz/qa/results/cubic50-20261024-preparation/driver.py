import json,sys,time
from pathlib import Path
sys.path.insert(0,'bench/capacity')
import cubic50_retest as rig
from run import save
try:
 pre=json.loads((rig.PREP/'preflight-summary.json').read_text())
 assert pre['valid']==pre['planned']==2 and pre['identity_audit']['valid']
 out=rig.ROOT/'qa/results/cubic50-20261024-confirmation'
 rig.run(out)
 result=rig.analyze(out)
 save(rig.PREP/'confirmation-summary.json',result)
 save(rig.PREP/'done.json',dict(end_unix=time.time(),planned=result['planned'],valid=result['valid'],identity_valid=result['identity_audit']['valid']))
except Exception as error:
 save(rig.PREP/'failure.json',dict(error=str(error),type=type(error).__name__,end_unix=time.time()))
 raise
