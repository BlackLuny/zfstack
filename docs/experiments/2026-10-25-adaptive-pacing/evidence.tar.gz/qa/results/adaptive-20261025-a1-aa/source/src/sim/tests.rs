//! End-to-end scenarios on the deterministic simulator. Every step checks the
//! invariants of §14.4 (scoreboard accounting, window edges, queue uniqueness).

use super::*;
use crate::{CcAlgo, CloseReason, StackConfig};

fn secs(s: u64) -> Duration {
    Duration::from_secs(s)
}

fn sim(seed: u64, down: LinkParams, up: LinkParams) -> Sim {
    Sim::new(seed, StackConfig::default(), StackConfig::default(), down, up)
}

fn download(sim: &mut Sim, bytes: u64, limit: Duration) -> (ConnId, AppConn) {
    sim.a.accept_template = AppConn { to_send: bytes, fin_after_send: true, ..Default::default() };
    let id = sim.connect(40000, AppConn::default());
    let end = sim.now + limit;
    while sim.now < end {
        let t = sim.now + Duration::from_millis(100);
        sim.run_until(t);
        let c = &sim.b.conns[&id];
        if c.eof {
            break;
        }
    }
    (id, sim.b.conns[&id].clone())
}

fn assert_download_ok(c: &AppConn, bytes: u64) {
    assert!(!c.corrupt, "byte stream corrupted");
    assert_eq!(c.received, bytes, "received {} of {}", c.received, bytes);
    assert!(c.eof, "no EOF");
}

#[test]
fn clean_download() {
    let mut s = sim(1, LinkParams::default(), LinkParams::default());
    let start = s.now;
    let (_, c) = download(&mut s, 20 << 20, secs(20));
    assert_download_ok(&c, 20 << 20);
    let took = s.now - start;
    // 20 MiB at 100 Mbit/s ≈ 1.68 s + slow start; allow some slack.
    assert!(took < Duration::from_millis(2600), "took {took:?}");
    assert_eq!(s.ab.stats.random_drops, 0);
    let st = &s.a.shard.stats();
    assert_eq!(st.rx_dropped_parse, 0);
}

#[test]
fn iface_pacing_single_peer_preserves_packet_and_time_trace() {
    for cc in [CcAlgo::Cubic, CcAlgo::Bbr] {
        for rtt in [1, 500] {
            let scenario = |enabled| {
                let link = LinkParams { delay: Duration::from_micros(rtt * 500), queue_bytes: 16 << 20, ..Default::default() };
                let cfg = StackConfig { cc, ..Default::default() };
                let mut s = Sim::new(9424, cfg.clone(), cfg, link.clone(), link);
                if enabled {
                    s.a.shard.set_iface_egress_rate(s.a.iface, 12_500_000);
                }
                s.enable_trace();
                s.a.accept_template = AppConn { to_send: 2 << 20, fin_after_send: true, ..Default::default() };
                let ids: Vec<_> = (0..2).map(|n| s.connect(40100 + n, AppConn::default())).collect();
                s.run_until(s.now + secs(12));
                for id in ids {
                    assert_download_ok(&s.b.conns[&id], 2 << 20);
                }
                assert_eq!(s.a.shard.stats().egress_paced_bytes, 0);
                (s.trace_digest(), s.steps)
            };
            assert_eq!(scenario(false), scenario(true), "single-peer path changed: {cc:?}, RTT={rtt}");
        }
    }
}

#[test]
fn adaptive_pacing_bbr_single_peer_preserves_packet_time_and_step_trace() {
    for rtt in [1, 500] {
        let scenario = |enabled| {
            let link = LinkParams { delay: Duration::from_micros(rtt * 500), queue_bytes: 16 << 20, ..Default::default() };
            let cfg = StackConfig { cc: CcAlgo::Bbr, ..Default::default() };
            let mut s = Sim::new(94250, cfg.clone(), cfg, link.clone(), link);
            s.a.shard.set_iface_adaptive_egress(s.a.iface, enabled);
            s.enable_trace();
            s.a.accept_template = AppConn { to_send: 2 << 20, fin_after_send: true, ..Default::default() };
            let ids: Vec<_> = (0..2).map(|n| s.connect(40100 + n, AppConn::default())).collect();
            s.run_until(s.now + secs(12));
            for id in ids {
                assert_download_ok(&s.b.conns[&id], 2 << 20);
            }
            assert_eq!(s.a.shard.stats().egress_paced_bytes, 0);
            assert_eq!(s.a.shard.stats().adaptive_egress_updates, 0);
            (s.trace_digest(), s.steps)
        };
        assert_eq!(scenario(false), scenario(true), "RTT={rtt}");
    }
}

#[test]
fn adaptive_pacing_learns_and_peers_progress_across_capacity_changes() {
    let link = LinkParams { rate_bps: 10_000_000, delay: Duration::from_millis(5), queue_bytes: 250_000, ..Default::default() };
    let cfg = StackConfig { cc: CcAlgo::Bbr, ..Default::default() };
    let mut s = Sim::new(94251, cfg.clone(), cfg, link.clone(), link);
    s.a.shard.set_iface_adaptive_egress(s.a.iface, true);
    s.a.accept_template = AppConn { to_send: 64 << 20, ..Default::default() };
    let ids: Vec<_> = (1..=3).map(|p| s.connect_as(PeerId(p), 40200 + p as u16, AppConn::default())).collect();
    for rate in [10_000_000, 50_000_000, 5_000_000] {
        let before: Vec<_> = ids.iter().map(|id| s.b.conns[id].received).collect();
        // Only the link changes. No capacity is supplied to the shard/controller.
        s.ab.p.rate_bps = rate;
        s.run_until(s.now + secs(4));
        for (id, count) in ids.iter().zip(before) {
            assert!(s.b.conns[id].received > count, "peer stalled at rate={rate}");
            assert!(!s.b.conns[id].corrupt);
        }
    }
    assert!(s.a.shard.stats().adaptive_egress_updates > 0);
    assert!(s.a.shard.stats().adaptive_egress_probes > 0);
    assert!(s.a.shard.stats().egress_paced_bytes > 0);
    let before: Vec<_> = ids.iter().map(|id| s.b.conns[id].received).collect();
    s.a.shard.set_iface_adaptive_egress(s.a.iface, false);
    s.run_until(s.now + secs(1));
    for (id, count) in ids.iter().zip(before) {
        assert!(s.b.conns[id].received > count);
    }
}

#[test]
fn adaptive_pacing_exits_after_a_late_interactive_peer_leaves() {
    let link = LinkParams { rate_bps: 20_000_000, delay: Duration::from_millis(5), queue_bytes: 250_000, ..Default::default() };
    let cfg = StackConfig { cc: CcAlgo::Bbr, ..Default::default() };
    let mut s = Sim::new(94252, cfg.clone(), cfg, link.clone(), link);
    s.a.shard.set_iface_adaptive_egress(s.a.iface, true);
    s.a.accept_template = AppConn { to_send: 64 << 20, ..Default::default() };
    let bulk: Vec<_> = (0..8).map(|n| s.connect(40300 + n, AppConn::default())).collect();
    s.run_until(s.now + secs(1));
    s.a.accept_template = AppConn { to_send: 1024, fin_after_send: true, ..Default::default() };
    let light = s.connect_as(PeerId(2), 40400, AppConn::default());
    s.run_until(s.now + secs(3));
    assert_download_ok(&s.b.conns[&light], 1024);
    assert!(s.a.shard.stats().adaptive_egress_updates > 0);
    let paced = s.a.shard.stats().egress_paced_bytes;
    let updates = s.a.shard.stats().adaptive_egress_updates;
    let before: Vec<_> = bulk.iter().map(|id| s.b.conns[id].received).collect();
    s.run_until(s.now + secs(1));
    assert_eq!(s.a.shard.stats().egress_paced_bytes, paced);
    assert_eq!(s.a.shard.stats().adaptive_egress_updates, updates);
    for (id, count) in bulk.iter().zip(before) {
        assert!(s.b.conns[id].received > count);
    }
}

#[test]
fn iface_pacing_late_peer_progresses_and_disabling_releases_the_ready_queue() {
    let link = LinkParams { rate_bps: 20_000_000, delay: Duration::from_millis(5), queue_bytes: 250_000, ..Default::default() };
    let mut s = sim(9425, link.clone(), link);
    s.a.shard.set_iface_egress_rate(s.a.iface, 2_500_000);
    s.a.accept_template = AppConn { to_send: 64 << 20, ..Default::default() };
    let bulk: Vec<_> = (0..16).map(|n| s.connect(40200 + n, AppConn::default())).collect();
    s.run_until(s.now + secs(1));
    s.a.accept_template = AppConn { to_send: 1024, fin_after_send: true, ..Default::default() };
    let light = s.connect_as(PeerId(2), 40300, AppConn::default());
    s.run_until(s.now + Duration::from_millis(500));
    assert_download_ok(&s.b.conns[&light], 1024);
    assert!(s.a.shard.stats().egress_paced_bytes > 0);
    assert!(s.a.shard.stats().egress_pacing_pauses > 0);
    let before: Vec<_> = bulk.iter().map(|id| s.b.conns[id].received).collect();
    s.a.shard.set_iface_egress_rate(s.a.iface, 0);
    s.run_until(s.now + secs(1));
    for (id, before) in bulk.into_iter().zip(before) {
        assert!(s.b.conns[&id].received > before, "bulk connection did not resume after disabling");
        assert!(!s.b.conns[&id].corrupt);
    }
}

#[test]
fn iface_pacing_and_sink_full_resume_without_an_ingress_wakeup() {
    let link = LinkParams { rate_bps: 20_000_000, delay: Duration::from_millis(5), queue_bytes: 250_000, ..Default::default() };
    let mut s = sim(9426, link.clone(), link);
    s.a.shard.set_iface_egress_rate(s.a.iface, 2_500_000);
    s.a.egress_rate = Some(20_000_000);
    s.a.accept_template = AppConn { to_send: 256 << 10, fin_after_send: true, ..Default::default() };
    let ids: Vec<_> = (1..=3).map(|peer| s.connect_as(PeerId(peer), 40400 + peer as u16, AppConn::default())).collect();
    s.run_until(s.now + secs(4));
    for id in ids {
        assert_download_ok(&s.b.conns[&id], 256 << 10);
    }
    assert!(s.a.shard.stats().sink_full > 0);
}

#[test]
fn issue37_idle_connections_leave_room_for_another_peer() {
    let mut s = sim(3701, LinkParams::default(), LinkParams::default());
    let port = 8 << 20;
    s.a.shard.set_budget_limits(port, port, 4096);
    s.a.shard.reserve_stream_state(1024);
    for n in 0..1500u16 {
        s.connect_as(PeerId(1), 40000 + n, AppConn::default());
        if n % 50 == 49 {
            s.run_until(s.now + Duration::from_millis(100));
        }
    }
    assert_eq!(s.a.accepted.len(), 1500, "idle connections must not exhaust admission with RX credit");
    let idle_bytes = s.a.shard.budget().physical_used();
    s.a.accept_template = AppConn { to_send: 256 << 10, fin_after_send: true, ..Default::default() };
    let downloads: Vec<_> = (0..4).map(|n| s.connect_as(PeerId(2), 42000 + n, AppConn::default())).collect();
    s.run_until(s.now + secs(5));
    for id in downloads {
        assert_download_ok(&s.b.conns[&id], 256 << 10);
    }
    eprintln!("issue37 idle: admitted=1500 idle_bytes={idle_bytes} limit={port}");
    assert!(s.a.shard.budget().physical_used() <= port);
    let global = s.a.shard.budget().global().clone();
    drop(s);
    assert_eq!(global.reserved(), 0);
}

#[test]
fn rx_progress_small_requests_cross_a_saturated_port_without_wire_retransmission() {
    for enabled in [false, true] {
        let mut s = sim(850, LinkParams::default(), LinkParams::default());
        let port = 1 << 20;
        s.a.shard.set_budget_limits(port, port, 16);
        let client = s.connect_as(PeerId(1), 40050, AppConn::default());
        s.run_until(s.now + Duration::from_millis(100));
        let server = s.a.accepted[0];
        if !enabled {
            s.a.shard.disable_rx_progress(server);
        }
        let memory = s.a.shard.memory_handle(PeerId(2));
        let ceiling = port - s.a.shard.budget().global().headroom(port, crate::budget::Tier::Block);
        let blocker = memory.try_allocate_kind(ceiling - s.a.shard.budget().physical_used(), crate::budget::AllocationKind::TxBlock).unwrap();
        let before = s.a.shard.budget().physical_used();
        for n in 0..16 {
            let data: Vec<_> = (n * 256..(n + 1) * 256).map(pattern_byte).collect();
            assert_eq!(s.b.shard.write(client, &data), WriteResult::Written(data.len()));
            s.run_until(s.now + Duration::from_millis(80));
            if !enabled {
                assert_eq!(s.a.conns[&server].received, 0);
                assert!(s.a.shard.info(server).unwrap().stats.dropped_no_mem > 0);
                assert_eq!(s.b.shard.info(client).unwrap().tx_queued, 256);
                break;
            }
            assert_eq!(s.a.conns[&server].received, (n + 1) * 256);
            assert!(!s.a.conns[&server].corrupt);
            assert_eq!(s.b.shard.info(client).unwrap().tx_queued, 0, "ACK must advance before the first RTO");
            assert_eq!(s.b.shard.info(client).unwrap().stats.bytes_retrans, 0);
            assert_eq!(s.a.shard.info(server).unwrap().stats.dropped_no_mem, 0);
            assert_eq!(s.a.shard.info(server).unwrap().stats.rx_progress_packets, n + 1);
            assert_eq!(s.a.shard.budget().physical_used(), before);
            assert!(s.a.shard.budget().physical_used() <= port);
        }
        assert!(s.a.shard.budget().stats().failures().rx_chunk > 0, "the ordinary Bulk path must really refuse input");
        drop(blocker);
        if !enabled {
            s.run_until(s.now + secs(1));
            assert_eq!(s.a.conns[&server].received, 256);
            assert!(s.b.shard.info(client).unwrap().stats.bytes_retrans >= 256);
        }
        let a = s.a.shard.budget().global().clone();
        let b = s.b.shard.budget().global().clone();
        drop(s);
        assert_eq!((a.reserved(), b.reserved()), (0, 0));
    }
}

#[test]
fn send_record_quota_retries_after_physical_memory_release() {
    let mut s = sim(840, LinkParams::default(), LinkParams::default());
    let port_limit = 128 << 10;
    s.a.shard.set_budget_limits(port_limit, port_limit, 8);
    let client = s.connect(40042, AppConn::default());
    s.run_until(s.now + Duration::from_millis(100));
    let server = s.a.accepted[0];
    let payload: Vec<u8> = (0..(32u64 << 10)).map(pattern_byte).collect();
    assert_eq!(s.a.shard.write(server, &payload), WriteResult::Written(payload.len()));

    let used = s.a.shard.budget().physical_used();
    let blocker = s.a.shard.memory_handle(PeerId(1)).try_allocate(port_limit - used - 512).unwrap();
    s.step();
    assert!(s.a.shard.budget_wait_epoch().is_some());
    assert!(s.a.shard.budget().stats().failures().send_record > 0);
    assert_eq!(s.b.conns[&client].received, 0);

    // Repeated app wakeups with unchanged capacity cannot keep retrying the
    // same failed record allocation. They used to burn an entire driver core.
    let failures = s.a.shard.budget().reserve_failures();
    for _ in 0..20 {
        let _ = s.a.shard.write(server, &[]);
        s.step();
    }
    assert_eq!(s.a.shard.budget().reserve_failures(), failures);
    // Releases by an unrelated peer advance the global epoch but cannot
    // satisfy this peer/port's next record allocation.
    for _ in 0..20 {
        let unrelated = s.a.shard.memory_handle(PeerId(2)).try_allocate(1).unwrap();
        drop(unrelated);
        s.step();
    }
    assert_eq!(s.a.shard.budget().reserve_failures(), failures);

    drop(blocker);
    s.step();
    s.run_until(s.now + secs(3));
    assert_eq!(s.b.conns[&client].received, payload.len() as u64);
    assert!(s.a.shard.budget_wait_epoch().is_none());
    let global = s.a.shard.budget().global().clone();
    drop(s);
    assert_eq!(global.reserved(), 0);
}

/// Exercise real data/ACK/retransmission packets after descriptor admission
/// fails at a tight receiver quota; direct process_data retry tests cannot
/// prove that the sender retains and retransmits the unacknowledged bytes.
#[test]
fn rx_descriptor_quota_drop_recovers_on_wire_retransmission() {
    let mut s = sim(843, LinkParams::default(), LinkParams::default());
    let port_limit = 128 << 10;
    s.b.shard.set_budget_limits(port_limit, port_limit, 8);
    let client = s.connect(40045, AppConn { read_paused_until: Instant::ZERO + secs(30), ..Default::default() });
    s.run_until(s.now + Duration::from_millis(100));
    let server = s.a.accepted[0];
    let payload: Vec<_> = (0..576).map(pattern_byte).collect();
    let mut charges = Vec::new();
    for part in payload[..512].chunks(64) {
        let before = s.b.shard.budget().physical_used();
        assert_eq!(s.a.shard.write(server, part), WriteResult::Written(part.len()));
        s.run_until(s.now + Duration::from_millis(100));
        charges.push(s.b.shard.budget().physical_used() - before);
    }
    assert_eq!(s.b.shard.info(client).unwrap().rx_queued, 512);
    assert_eq!(s.b.conns[&client].received, 0, "slow reader must retain all eight owners");
    let owner_charge = charges[1];
    assert!(owner_charge >= 64);
    assert_eq!(&charges[1..4], &[owner_charge; 3]);
    assert_eq!(&charges[5..], &[owner_charge; 3]);
    // Ordinary backing beyond eight slots is outside the RX credit promise.
    // Its replacement misses by one byte while old backing stays charged.
    let replacement_charge = (16 * std::mem::size_of::<Bytes>() * 2) as u64;
    let room = owner_charge + replacement_charge - 1;
    let blocker = s.b.shard.memory_handle(PeerId(1)).try_allocate(port_limit - s.b.shard.budget().physical_used() - room).unwrap();
    let retrans_before = s.a.shard.info(server).unwrap().stats.bytes_retrans;
    assert_eq!(s.a.shard.write(server, &payload[512..]), WriteResult::Written(64));
    let failure_deadline = s.now + secs(1);
    while s.now < failure_deadline && s.b.shard.budget().stats().failures().rx_chunk == 0 {
        s.run_until(s.now + Duration::from_millis(1));
    }
    assert_eq!(s.b.shard.budget().stats().failures().rx_chunk, 1);
    assert_eq!(s.b.shard.budget().stats().failures().ooo, 0);
    assert_eq!(s.b.shard.info(client).unwrap().rx_queued, 512);
    // Deliver the duplicate ACK: the receiver did not acknowledge the byte
    // range whose backing it could not reserve.
    s.run_until(s.now + Duration::from_millis(30));
    assert_eq!(s.a.shard.info(server).unwrap().tx_queued, 64);
    drop(blocker);
    let recovery_deadline = s.now + secs(3);
    while s.now < recovery_deadline && s.b.shard.info(client).unwrap().rx_queued < payload.len() {
        s.run_until(s.now + Duration::from_millis(1));
    }
    assert_eq!(s.b.shard.info(client).unwrap().rx_queued, payload.len());
    assert!(s.a.shard.info(server).unwrap().stats.bytes_retrans >= retrans_before + 64, "recovery must use a wire retransmission");
    s.b.conns.get_mut(&client).unwrap().read_paused_until = s.now;
    s.a.shard.shutdown_write(server);
    s.run_until(s.now + secs(1));
    assert_download_ok(&s.b.conns[&client], payload.len() as u64);
    let a_global = s.a.shard.budget().global().clone();
    let b_global = s.b.shard.budget().global().clone();
    drop(s);
    assert_eq!((a_global.reserved(), b_global.reserved()), (0, 0));
}

/// #664: a sender whose send records are full and cannot grow must still
/// retransmit lost records in place; their ACKs free the slots new data needs.
#[test]
fn full_send_records_retransmit_in_place_when_growth_is_impossible() {
    let down = LinkParams::default();
    // Let one write buffer the whole payload before the port is filled.
    let server_cfg = StackConfig { min_prefetch: 4 << 20, prefetch_max: 4 << 20, ..Default::default() };
    let mut s = Sim::new(842, server_cfg, StackConfig::default(), down, LinkParams::default());
    let port_limit = 8 << 20;
    s.a.shard.set_budget_limits(port_limit, port_limit, 8);
    let client = s.connect(40044, AppConn::default());
    s.run_until(s.now + Duration::from_millis(100));
    let server = s.a.accepted[0];
    let payload: Vec<u8> = (0..(2u64 << 20)).map(pattern_byte).collect();
    let WriteResult::Written(total) = s.a.shard.write(server, &payload) else { panic!("write refused") };
    assert_eq!(total, payload.len());
    s.run_until(s.now + Duration::from_millis(30));
    assert!(s.b.conns[&client].received < total as u64, "transfer finished before the port was filled");

    // Keep the port at the TX-block tier limit: only the record headroom is
    // left, too small to grow a full deque, and whatever an ACK releases is
    // taken again before the next round.
    let memory = s.a.shard.memory_handle(PeerId(1));
    let mut blockers = Vec::new();
    // When the full deque first blocks new data, lose the ACKs of the whole
    // window: the RTO then marks every record lost while none is spare.
    let failures = s.a.shard.budget().stats().failures().send_record;
    let mut outage_end = None;
    // Unblocked, the transfer ends within about half a second.
    let end = s.now + secs(5);
    while s.now < end && s.b.conns[&client].received < total as u64 {
        if outage_end.is_none() && s.a.shard.budget().stats().failures().send_record > failures {
            outage_end = Some(s.now + Duration::from_millis(60));
        }
        s.ba.p.loss = if outage_end.is_some_and(|t| s.now < t) { 1.0 } else { 0.0 };
        // Blockers stand for buffered bytes that cannot drain (TX-block tier):
        // they leave only the progress headroom above them.
        let block_limit = port_limit - s.a.shard.budget().global().headroom(port_limit, crate::budget::Tier::Block);
        let room = block_limit.saturating_sub(s.a.shard.budget().physical_used());
        if room > 0 {
            blockers.push(memory.try_allocate_kind(room, crate::budget::AllocationKind::TxBlock).unwrap());
        }
        s.run_until(s.now + Duration::from_millis(1));
    }
    let c = &s.b.conns[&client];
    assert!(!c.corrupt);
    assert_eq!(c.received, total as u64, "sender stalled with full records");
    assert!(s.a.shard.budget().stats().failures().send_record > 0, "records never needed to grow");
    assert!(outage_end.is_some() && s.ba.stats.random_drops > 0, "the deque never filled");
    drop(blockers);
    let global = s.a.shard.budget().global().clone();
    drop(s);
    assert_eq!(global.reserved(), 0);
}

#[test]
fn blocked_send_record_does_not_survive_iface_removal() {
    let mut s = sim(841, LinkParams::default(), LinkParams::default());
    let port_limit = 128 << 10;
    s.a.shard.set_budget_limits(port_limit, port_limit, 8);
    s.connect(40043, AppConn::default());
    s.run_until(s.now + Duration::from_millis(100));
    let server = s.a.accepted[0];
    assert_eq!(s.a.shard.write(server, &vec![1; 32 << 10]), WriteResult::Written(32 << 10));
    let used = s.a.shard.budget().physical_used();
    let blocker = s.a.shard.memory_handle(PeerId(1)).try_allocate(port_limit - used - 512).unwrap();
    s.step();
    assert!(s.a.shard.budget_wait_epoch().is_some());

    s.a.shard.remove_iface(s.a.iface);
    assert!(s.a.shard.budget_wait_epoch().is_none());
    assert_eq!(s.a.shard.conn_count(), 0);
    drop(blocker);
    let global = s.a.shard.budget().global().clone();
    drop(s);
    assert_eq!(global.reserved(), 0);
}

#[test]
fn borrowed_server_ingress_survives_packet_recycling_and_reordering() {
    let link = LinkParams { reorder: 0.02, reorder_delay: Duration::from_millis(3), ..Default::default() };
    let mut s = sim(837, link.clone(), link);
    s.borrowed_server_ingress = true;
    s.a.accept_template = AppConn { to_send: 2 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(40000, AppConn { to_send: 1 << 20, fin_after_send: true, ..Default::default() });
    s.run_until(s.now + secs(30));
    let server = &s.a.conns[&id];
    let client = &s.b.conns[&id];
    assert!(!server.corrupt && !client.corrupt, "borrowed RX corrupted after source packets were released");
    assert_eq!(server.received, 1 << 20);
    assert_eq!(client.received, 2 << 20);
    assert!(server.eof && client.eof);
}

#[test]
fn adapter_transfer_does_not_consume_tcp_receive_credit() {
    let mut s = sim(838, LinkParams::default(), LinkParams::default());
    s.a.accept_template.read_paused_until = s.now + secs(10);
    s.connect(40001, AppConn { to_send: 256 << 10, ..Default::default() });
    s.run_until(s.now + secs(1));
    let server_id = s.a.accepted[0];
    let charged = s.a.shard.budget().used;
    let chunk = s.a.shard.read_chunk_for_adapter(s.now, server_id, 64 << 10).unwrap();
    assert!(!chunk.is_empty());
    assert_eq!(s.a.shard.budget().used, charged, "core-to-adapter transfer released receive credit");
    let consumed = chunk.len() / 2;
    s.a.shard.consume_adapter(s.now, server_id, consumed);
    assert_eq!(s.a.shard.budget().used, charged - consumed as u64);
}

#[test]
fn download_with_random_loss() {
    for (seed, loss) in [(2, 0.001), (3, 0.01), (4, 0.03), (5, 0.05)] {
        let down = LinkParams { loss, ..Default::default() };
        let mut s = sim(seed, down, LinkParams { loss: loss / 2.0, ..Default::default() });
        let (_, c) = download(&mut s, 8 << 20, secs(120));
        assert_download_ok(&c, 8 << 20);
    }
}

#[test]
fn download_with_burst_loss_reorder_dup() {
    for seed in 10..16 {
        let down =
            LinkParams { loss: 0.01, burst_continue: 0.5, reorder: 0.02, reorder_delay: Duration::from_millis(3), duplicate: 0.01, ..Default::default() };
        let up = LinkParams { loss: 0.005, reorder: 0.01, duplicate: 0.01, ..Default::default() };
        let mut s = sim(seed, down, up);
        let (_, c) = download(&mut s, 4 << 20, secs(120));
        assert_download_ok(&c, 4 << 20);
    }
}

#[test]
fn shallow_queue_long_rtt() {
    // 200 Mbit/s, 80 ms RTT, queue = 0.25 BDP: loss comes only from the bottleneck.
    let bdp = 200_000_000 / 8 * 80 / 1000;
    let p = LinkParams { rate_bps: 200_000_000, delay: Duration::from_millis(40), queue_bytes: bdp / 4, ..Default::default() };
    let mut s = sim(21, p.clone(), p);
    let start = s.now;
    let (_, c) = download(&mut s, 64 << 20, secs(60));
    assert_download_ok(&c, 64 << 20);
    let took = (s.now - start).as_secs_f64();
    let mbps = (64u64 << 20) as f64 * 8.0 / took / 1e6;
    assert!(mbps > 100.0, "goodput {mbps:.1} Mbit/s");
}

#[test]
fn upload() {
    let mut s = sim(31, LinkParams { loss: 0.01, ..Default::default() }, LinkParams { loss: 0.01, ..Default::default() });
    s.a.accept_template = AppConn::default();
    let id = s.connect(40001, AppConn { to_send: 6 << 20, fin_after_send: true, ..Default::default() });
    s.run_until(s.now + secs(60));
    let srv = s.a.accepted[0];
    let c = &s.a.conns[&srv];
    assert!(!c.corrupt);
    assert_eq!(c.received, 6 << 20);
    assert!(c.eof);
    assert!(s.b.conns[&id].fin_sent);
}

#[test]
fn bidirectional() {
    let mut s = sim(32, LinkParams { loss: 0.005, ..Default::default() }, LinkParams { loss: 0.005, ..Default::default() });
    s.a.accept_template = AppConn { to_send: 3 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(40002, AppConn { to_send: 3 << 20, fin_after_send: true, ..Default::default() });
    s.run_until(s.now + secs(60));
    let srv = s.a.accepted[0];
    assert_download_ok(&s.b.conns[&id], 3 << 20);
    let a = &s.a.conns[&srv];
    assert!(!a.corrupt && a.eof && a.received == 3 << 20);
    // Both sides closed; after TIME_WAIT everything is released.
    s.run_until(s.now + secs(70));
    assert_eq!(s.a.shard.conn_count(), 0, "server connections left");
    assert_eq!(s.b.shard.conn_count(), 0, "client connections left");
    assert_eq!(s.a.shard.budget().used, 0);
}

#[test]
fn zero_window_and_persist() {
    let mut cfg_b = StackConfig::default();
    cfg_b.max_rcv_buf = 128 * 1024;
    cfg_b.init_rcv_wnd = 32 * 1024;
    let mut s = Sim::new(41, StackConfig::default(), cfg_b, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 2 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(40003, AppConn::default());
    // Pause the reader for 5 s right away: the window closes, the sender persists.
    s.b.conns.get_mut(&id).unwrap().read_paused_until = s.now + secs(5);
    s.run_until(s.now + secs(4));
    let srv = s.a.accepted[0];
    let info = s.a.shard.info(srv).unwrap();
    assert_eq!(info.snd_wnd, 0, "window should be closed");
    assert_eq!(info.pipe, 0);
    assert!(info.stats.zero_window_probes > 0, "persist probes expected");
    s.run_until(s.now + secs(30));
    assert_download_ok(&s.b.conns[&id], 2 << 20);
}

#[test]
fn egress_full_does_not_count_as_sent() {
    let mut s = sim(51, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 4 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(40004, AppConn::default());
    s.run_until(s.now + Duration::from_millis(300));
    // Block the sink for 2 s.
    s.a.egress_budget = Some(0);
    let srv = s.a.accepted[0];
    let before = s.a.shard.info(srv).unwrap();
    let runs_before = s.a.shard.stats().runs;
    s.run_until(s.now + secs(2));
    let during = s.a.shard.info(srv).unwrap();
    assert_eq!(before.stats.bytes_sent, during.stats.bytes_sent, "nothing may count as sent while Full");
    // No busy loop: the shard is not re-run for a blocked sink.
    let runs = s.a.shard.stats().runs - runs_before;
    assert!(runs < 2000, "busy loop: {runs} runs");
    s.a.egress_budget = None;
    s.a.shard.egress_released(s.a.iface);
    s.run_until(s.now + secs(20));
    if s.b.conns[&id].received != 4 << 20 {
        eprintln!("after release: {:?}", s.a.shard.info(srv));
    }
    assert_download_ok(&s.b.conns[&id], 4 << 20);
}

#[test]
fn syn_cookies() {
    let mut cfg_a = StackConfig::default();
    cfg_a.syn_backlog = 0;
    let mut s = Sim::new(61, cfg_a, StackConfig::default(), LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 1 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(40005, AppConn::default());
    s.run_until(s.now + secs(10));
    assert!(s.a.shard.stats().syn_cookies_ok >= 1);
    assert_download_ok(&s.b.conns[&id], 1 << 20);
    let srv = s.a.accepted[0];
    let _ = srv;
}

#[test]
fn mtu_decrease_resegments() {
    let mut s = sim(71, LinkParams { loss: 0.01, ..Default::default() }, LinkParams::default());
    s.a.accept_template = AppConn { to_send: 8 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(40006, AppConn::default());
    s.run_until(s.now + Duration::from_millis(400));
    s.a.shard.set_iface_mtu(s.a.iface, 1280);
    let srv = s.a.accepted[0];
    s.run_until(s.now + secs(40));
    assert_download_ok(&s.b.conns[&id], 8 << 20);
    let _ = srv;
}

#[test]
fn close_with_unread_data_sends_rst() {
    let mut s = sim(81, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn::default();
    // Client sends 100 KiB; server never reads, then closes -> RST.
    let id = s.connect(40007, AppConn { to_send: 100 * 1024, ..Default::default() });
    s.a.accept_template.read_paused_until = Instant::MAX;
    s.run_until(s.now + Duration::from_millis(10));
    // Accept happened with the old template; pause reading explicitly.
    for c in s.a.conns.values_mut() {
        c.read_paused_until = Instant::MAX;
    }
    s.run_until(s.now + Duration::from_millis(500));
    let srv = s.a.accepted[0];
    let now = s.now;
    s.a.shard.close(now, srv);
    s.a.conns.remove(&srv);
    s.run_until(s.now + Duration::from_millis(500));
    assert_eq!(s.b.conns[&id].closed, Some(CloseReason::Reset));
    assert_eq!(s.a.shard.conn_count(), 0);
}

#[test]
fn many_connections_and_full_release() {
    let mut s = sim(91, LinkParams { loss: 0.005, ..Default::default() }, LinkParams { loss: 0.005, ..Default::default() });
    s.a.accept_template = AppConn { to_send: 50_000, fin_after_send: true, ..Default::default() };
    let mut ids = Vec::new();
    for i in 0..200u16 {
        ids.push(s.connect(20000 + i, AppConn { to_send: 10_000, fin_after_send: true, ..Default::default() }));
    }
    s.run_until(s.now + secs(30));
    for id in &ids {
        let c = &s.b.conns[id];
        if c.received != 50_000 {
            eprintln!("stuck client {:?}: {:?} info={:?}", id, c, s.b.shard.info(*id));
            let srv = s.a.accepted.iter().find(|x| s.a.shard.info(**x).is_some_and(|i| i.remote == s.b.shard.info(*id).map(|j| j.local).unwrap_or(i.remote)));
            eprintln!("server: {:?}", srv.and_then(|x| s.a.shard.info(*x)));
        }
        assert_download_ok(c, 50_000);
    }
    for id in &s.a.accepted {
        let c = &s.a.conns[id];
        assert!(!c.corrupt && c.received == 10_000 && c.eof);
    }
    s.run_until(s.now + secs(70));
    assert_eq!(s.a.shard.conn_count(), 0);
    assert_eq!(s.b.shard.conn_count(), 0);
    assert_eq!(s.a.shard.budget().used, 0, "budget must return to 0");
    assert_eq!(s.a.shard.budget().global().connection_counts(), (0, 0));
    assert_eq!(s.b.shard.budget().global().connection_counts(), (0, 0));
    assert_eq!(s.a.shard.budget().global().time_wait_bytes_reserved(), 0);
    assert_eq!(s.b.shard.budget().global().time_wait_bytes_reserved(), 0);
    let (t, p, _) = s.a.shard.container_sizes();
    assert_eq!((t, p), (0, 0));
    let a_budget = s.a.shard.budget().global().clone();
    let b_budget = s.b.shard.budget().global().clone();
    drop(s);
    assert_eq!(a_budget.reserved(), 0, "server backing leases survived shard teardown");
    assert_eq!(b_budget.reserved(), 0, "client backing leases survived shard teardown");
}

#[test]
fn time_wait_compacts_and_preserves_expiry() {
    let mut s = sim(912, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 4096, fin_after_send: true, ..Default::default() };
    let id = s.connect(49000, AppConn { to_send: 4096, fin_after_send: true, ..Default::default() });
    s.run_until(s.now + secs(5));
    assert_download_ok(&s.b.conns[&id], 4096);
    let (_, a_tw) = s.a.shard.half_open_and_time_wait();
    let (_, b_tw) = s.b.shard.half_open_and_time_wait();
    assert!(a_tw + b_tw > 0, "no TIME_WAIT state after both FINs");
    let (a_active, a_reserved) = s.a.shard.budget().global().connection_counts();
    let (b_active, b_reserved) = s.b.shard.budget().global().connection_counts();
    assert!(a_reserved + b_reserved >= a_tw as u64 + b_tw as u64);
    assert!(a_active + b_active < a_reserved + b_reserved, "TIME_WAIT retained full active permit");
    s.run_until(s.now + secs(70));
    assert_eq!(s.a.shard.budget().global().connection_counts(), (0, 0));
    assert_eq!(s.b.shard.budget().global().connection_counts(), (0, 0));
}

#[test]
fn per_peer_fairness() {
    // G-fair (§8.2, §15): the bottleneck is the local egress (sink rate-limited).
    // Peer 1 opens 1 download, peer 2 opens 16; per-peer DRR should split ~50/50.
    let p = LinkParams { rate_bps: 0, delay: Duration::from_millis(5), ..Default::default() };
    let mut s = sim(101, p.clone(), p);
    s.a.egress_rate = Some(100_000_000);
    s.a.accept_template = AppConn { to_send: u64::MAX, ..Default::default() };
    let one = s.connect_as(PeerId(1), 30000, AppConn::default());
    let mut many = Vec::new();
    for i in 0..16 {
        many.push(s.connect_as(PeerId(2), 31000 + i, AppConn::default()));
    }
    s.check_invariants = false;
    s.run_until(s.now + secs(2));
    let r0: Vec<u64> = std::iter::once(one).chain(many.iter().copied()).map(|i| s.b.conns[&i].received).collect();
    s.run_until(s.now + secs(4));
    let r1: Vec<u64> = std::iter::once(one).chain(many.iter().copied()).map(|i| s.b.conns[&i].received).collect();
    let single = (r1[0] - r0[0]) as f64;
    let group: f64 = r1[1..].iter().zip(&r0[1..]).map(|(a, b)| (a - b) as f64).sum();
    let ratio = single / group;
    let total_mbps = (single + group) * 8.0 / 4.0 / 1e6;
    eprintln!("fairness: single={single} group={group} ratio={ratio:.2} total={total_mbps:.1} Mbit/s");
    assert!((0.7..=1.3).contains(&ratio), "G-fair ratio {ratio:.2}");
    assert!(total_mbps > 85.0, "egress underused: {total_mbps:.1}");
}

#[test]
fn execution_gap_pacing_keeps_rate() {
    // Shard only gets CPU every 5 ms: pacing credit must still allow full rate (§7.2).
    let p = LinkParams { rate_bps: 200_000_000, delay: Duration::from_millis(20), queue_bytes: 2_000_000, ..Default::default() };
    let mut s = sim(111, p.clone(), p);
    s.gap_a = Duration::from_millis(5);
    let start = s.now;
    let (_, c) = download(&mut s, 64 << 20, secs(60));
    assert_download_ok(&c, 64 << 20);
    let mbps = (64u64 << 20) as f64 * 8.0 / (s.now - start).as_secs_f64() / 1e6;
    eprintln!("gap 5ms goodput {mbps:.1} Mbit/s credit {:?}", s.a.shard.pacing_credit());
    assert!(mbps > 120.0, "goodput {mbps:.1}");
}

#[test]
fn deterministic_replay() {
    let run = || {
        let mut s = sim(123, LinkParams { loss: 0.02, reorder: 0.02, ..Default::default() }, LinkParams::default());
        s.enable_trace();
        let (_, c) = download(&mut s, 2 << 20, secs(60));
        (c.received, s.steps, s.ab.stats.random_drops, s.now, s.trace_digest())
    };
    assert_eq!(run(), run());
}

#[test]
fn same_seed_replays_identical_packets() {
    // zfstack#13: ISN, timestamp offsets and app/waiter ordering are all seeded,
    // so every packet (contents and send time) replays, across many connections
    // with loss, reordering and duplication on both directions.
    let run = |seed: u64| {
        let p = LinkParams { rate_bps: 50_000_000, loss: 0.01, reorder: 0.02, duplicate: 0.01, ..Default::default() };
        let mut s = sim(seed, p.clone(), p);
        s.enable_trace();
        s.a.accept_template = AppConn { to_send: 256 << 10, fin_after_send: true, ..Default::default() };
        for i in 0..8 {
            s.connect_as(PeerId(1 + i % 2), 46000 + i as u16, AppConn { to_send: 64 << 10, fin_after_send: true, ..Default::default() });
        }
        s.run_until(s.now + secs(10));
        assert!(s.b.conns.values().all(|c| c.eof && c.received == 256 << 10 && !c.corrupt));
        (s.trace_digest().unwrap(), s.steps, s.now)
    };
    assert_eq!(run(7), run(7));
    assert_ne!(run(7).0, run(8).0, "the seed must reach the packets");
}

#[test]
fn desynced_ends_do_not_ack_storm() {
    // Forged segments can leave the ends disagreeing on the sequence space (a
    // forged FIN / data / TSval / ACK). Replies to what we drop must then be
    // rate-limited, or the ends ACK each other at link rate until the user
    // timeout. 5023: probe-shaped ACKs vs. an out-of-window reply; 5109: ACK
    // beyond SND.MAX; 5110: PAWS vs. ACK beyond SND.MAX; the rest stormed before
    // either limit.
    for seed in [5005, 5023, 5028, 5044, 5109, 5110, 5122, 5145] {
        let (_, _, steps) = fuzz_run(seed, seed + 900, false);
        // A storm runs millions of steps (tens of thousands per virtual second).
        assert!(steps < 50_000, "seed {seed}: {steps} sim steps, ACK storm");
    }
}

#[test]
fn fuzz_replays_identically() {
    // Mutated and garbage ingress replays too (zfstack#13).
    assert_eq!(fuzz_run(5100, 6000, false), fuzz_run(5100, 6000, false));
}

#[test]
fn bbr_and_brutal_complete() {
    for cc in [CcAlgo::Bbr, CcAlgo::Brutal(8_000_000)] {
        let mut cfg = StackConfig::default();
        cfg.cc = cc;
        let mut s = Sim::new(131, cfg, StackConfig::default(), LinkParams { loss: 0.01, ..Default::default() }, LinkParams::default());
        let (_, c) = download(&mut s, 8 << 20, secs(60));
        assert_download_ok(&c, 8 << 20);
    }
}

fn goodput_run(cc: CcAlgo, rate: u64, rtt_ms: u64, queue_bdp: f64, loss: f64, bytes: u64, gap: Duration) -> (f64, crate::ConnInfo) {
    let bdp = (rate / 8) as f64 * rtt_ms as f64 / 1000.0;
    let p = LinkParams { rate_bps: rate, delay: Duration::from_millis(rtt_ms / 2), queue_bytes: (bdp * queue_bdp) as usize, loss, ..Default::default() };
    let mut cfg = StackConfig::default();
    cfg.cc = cc;
    let mut s = Sim::new(777, cfg, StackConfig::default(), p.clone(), LinkParams { loss: 0.0, ..p });
    s.gap_a = gap;
    s.check_invariants = false;
    let start = s.now;
    let (_, c) = download(&mut s, bytes, secs(120));
    assert_download_ok(&c, bytes);
    let srv = s.a.accepted[0];
    let info = s.a.shard.info(srv).unwrap_or_else(|| panic!("no info"));
    let mbps = bytes as f64 * 8.0 / (s.now - start).as_secs_f64() / 1e6;
    (mbps, info)
}

#[test]
fn bbr_shallow_queue_long_rtt() {
    let (mbps, info) = goodput_run(CcAlgo::Bbr, 200_000_000, 80, 0.25, 0.0, 240 << 20, Duration::ZERO);
    let rtx = info.stats.bytes_retrans as f64 / info.stats.bytes_sent as f64;
    eprintln!("bbr 80ms/0.25BDP: {mbps:.1} Mbit/s, retrans {:.2}%", rtx * 100.0);
    assert!(mbps > 150.0, "goodput {mbps:.1}");
    assert!(rtx < 0.05, "retransmission ratio {rtx}");
}

#[test]
fn bbr_random_loss_keeps_rate() {
    // BBR must not collapse under 1% random loss (unlike loss-based CC).
    let (mbps, _) = goodput_run(CcAlgo::Bbr, 100_000_000, 40, 2.0, 0.01, 48 << 20, Duration::ZERO);
    eprintln!("bbr 1% loss: {mbps:.1} Mbit/s");
    assert!(mbps > 50.0, "goodput {mbps:.1}");
}

#[test]
#[ignore]
fn bbr_trace() {
    let rate = 200_000_000u64;
    let bdp = (rate / 8) as f64 * 0.08;
    let p = LinkParams { rate_bps: rate, delay: Duration::from_millis(40), queue_bytes: (bdp * 0.25) as usize, ..Default::default() };
    let mut cfg = StackConfig::default();
    cfg.cc = CcAlgo::Bbr;
    let mut s = Sim::new(777, cfg, StackConfig::default(), p.clone(), p);
    s.check_invariants = false;
    s.a.accept_template = AppConn { to_send: u64::MAX, ..Default::default() };
    let id = s.connect(40000, AppConn::default());
    let mut last = 0;
    for i in 0..100 {
        s.run_until(s.now + Duration::from_millis(100));
        let got = s.b.conns[&id].received;
        let Some(&srv) = s.a.accepted.first() else { continue };
        let info = s.a.shard.info(srv).unwrap();
        eprintln!(
            "{:>4}ms {:>6.1}Mbps drops={} rtx={} rto={} tlp={} fr={} {}",
            i * 100,
            (got - last) as f64 * 8.0 / 0.1 / 1e6,
            s.ab.stats.queue_drops,
            info.stats.bytes_retrans,
            info.stats.rto_count,
            info.stats.tlp_count,
            info.stats.fast_recoveries,
            info.cc_debug
        );
        last = got;
    }
}

#[test]
#[ignore]
fn bbr_probe_steady_state() {
    for (q, bytes) in [(0.25, 240u64 << 20), (2.0, 240 << 20)] {
        let (mbps, info) = goodput_run(CcAlgo::Bbr, 200_000_000, 80, q, 0.0, bytes, Duration::ZERO);
        eprintln!(
            "q={q}: {mbps:.1} Mbit/s cwnd={} pacing={:?} srtt={:?} minrtt={:?} rtx={}",
            info.cwnd, info.pacing_rate, info.srtt, info.min_rtt, info.stats.bytes_retrans
        );
    }
    for (q, bytes) in [(0.25, 240u64 << 20), (2.0, 240 << 20)] {
        let (mbps, info) = goodput_run(CcAlgo::Cubic, 200_000_000, 80, q, 0.0, bytes, Duration::ZERO);
        eprintln!("cubic q={q}: {mbps:.1} Mbit/s cwnd={} rtx={}", info.cwnd, info.stats.bytes_retrans);
    }
}

#[test]
fn fuzz_mutated_and_random_packets() {
    fuzz_run(4242, 99, true);
}

#[test]
fn fuzz_without_rst() {
    for seed in 0..6 {
        fuzz_run(5000 + seed, 700 + seed, false);
    }
}

fn fuzz_run(sim_seed: u64, fuzz_seed: u64, allow_rst: bool) -> (u64, u64, u64) {
    // Capture real segments of a transfer, then replay mutated copies and random
    // garbage into a live server while the transfer continues. No panics, invariants
    // hold, and the transfer still completes.
    let mut s = sim(sim_seed, LinkParams::default(), LinkParams::default());
    s.enable_trace();
    s.a.accept_template = AppConn { to_send: 4 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(45000, AppConn::default());
    let mut rng = Rng::new(fuzz_seed);
    let mut corpus: Vec<Vec<u8>> = Vec::new();
    for round in 0..200 {
        s.run_until(s.now + Duration::from_millis(5));
        // Snapshot some in-flight client->server packets.
        for (_, (_, p)) in s.ba.inflight.iter().take(4) {
            if corpus.len() < 256 {
                corpus.push(p.to_vec());
            }
        }
        for _ in 0..20 {
            let mut pkt = if !corpus.is_empty() && rng.chance(0.8) {
                corpus[rng.below(corpus.len() as u64) as usize].clone()
            } else {
                let n = rng.below(120) as usize;
                (0..n).map(|_| rng.next_u64() as u8).collect()
            };
            // Mutate: flip bytes, truncate, or extend.
            match rng.below(4) {
                0 if !pkt.is_empty() => {
                    for _ in 0..1 + rng.below(4) {
                        let i = rng.below(pkt.len() as u64) as usize;
                        pkt[i] ^= 1 << rng.below(8);
                    }
                }
                1 => pkt.truncate(rng.below(pkt.len() as u64 + 1) as usize),
                2 => pkt.extend((0..rng.below(64)).map(|_| rng.next_u64() as u8)),
                _ => {}
            }
            if !allow_rst && pkt.len() >= 34 && pkt[0] >> 4 == 4 {
                let ihl = ((pkt[0] & 0xf) as usize) * 4;
                if pkt.len() > ihl + 13 {
                    pkt[ihl + 13] &= !crate::wire::RST;
                }
            }
            if rng.chance(0.5) || !allow_rst {
                fix_checksums(&mut pkt);
            }
            let now = s.now;
            s.a.shard.ingress(now, s.a.iface, PeerId(1), Bytes::from(pkt));
        }
        s.a.shard.check_invariants();
        let _ = round;
    }
    s.run_until(s.now + secs(30));
    let srv = s.a.accepted[0];
    if !s.b.conns[&id].eof {
        // A forged-but-plausible ACK or timestamp (valid checksum, in window) can
        // desynchronize the ends. With timestamps this is detected within a few RTOs
        // and reset (CloseReason::Desync); without them only the user timeout ends
        // it. Either way the connection must be torn down and release everything,
        // never hang forever. (Only the holder of the connection's packets can do
        // this; WG authenticates peers.)
        s.run_until(s.now + secs(150));
    }
    let c = &s.b.conns[&id];
    eprintln!(
        "fuzz end (seed {sim_seed}/{fuzz_seed}): client received={} eof={} closed={:?} corrupt={}; server app={:?}",
        c.received,
        c.eof,
        c.closed,
        c.corrupt,
        s.a.conns.get(&srv).map(|x| (x.closed, x.eof))
    );
    assert!(!c.corrupt, "stream corrupted");
    if c.eof {
        assert_download_ok(c, 4 << 20);
    } else {
        assert!(c.closed.is_some(), "connection hung without being torn down");
        s.run_until(s.now + secs(70));
        assert_eq!(s.a.shard.conn_count(), 0, "server connection not released");
        assert_eq!(s.a.shard.budget().used, 0, "budget not released");
    }
    let (ab, ba) = s.trace_digest().unwrap();
    (ab, ba, s.steps)
}

/// Recompute IPv4 header and TCP checksums so mutated packets reach the state machine.
fn fix_checksums(pkt: &mut [u8]) {
    use crate::wire::{checksum_fold, pseudo_sum, sum_bytes};
    if pkt.len() < 40 || pkt[0] >> 4 != 4 {
        return;
    }
    let ihl = ((pkt[0] & 0xf) as usize) * 4;
    let total = u16::from_be_bytes([pkt[2], pkt[3]]) as usize;
    if ihl < 20 || total > pkt.len() || total < ihl + 20 {
        return;
    }
    pkt[10] = 0;
    pkt[11] = 0;
    let c = checksum_fold(sum_bytes(0, &pkt[..ihl]));
    pkt[10..12].copy_from_slice(&c.to_be_bytes());
    let src = std::net::Ipv4Addr::new(pkt[12], pkt[13], pkt[14], pkt[15]);
    let dst = std::net::Ipv4Addr::new(pkt[16], pkt[17], pkt[18], pkt[19]);
    let seg = &mut pkt[ihl..total];
    seg[16] = 0;
    seg[17] = 0;
    let c = checksum_fold(sum_bytes(pseudo_sum(src.into(), dst.into(), seg.len() as u32), seg));
    seg[16..18].copy_from_slice(&c.to_be_bytes());
}

#[test]
fn synack_timeouts_release_half_open_slots() {
    // SYN-ACKs are all lost: half-open connections time out and must stop counting
    // towards the SYN backlog (otherwise the shard stays on SYN cookies forever).
    let mut cfg_a = StackConfig::default();
    cfg_a.syn_backlog = 8;
    let mut s = Sim::new(201, cfg_a, StackConfig::default(), LinkParams { loss: 1.0, ..Default::default() }, LinkParams::default());
    for i in 0..5 {
        s.connect(46000 + i, AppConn::default());
    }
    s.run_until(s.now + Duration::from_millis(100));
    assert_eq!(s.a.shard.half_open_and_time_wait().0, 5);
    // Client SYN retransmissions keep re-triggering SYN-ACKs; allow them to finish.
    s.run_until(s.now + secs(60));
    assert_eq!(s.a.shard.half_open_and_time_wait().0, 0, "half-open counter leaked");
    assert_eq!(s.a.shard.conn_count(), 0);
}

#[test]
fn unread_data_survives_orderly_close() {
    // The server replies and closes without reading the request; the close completes
    // (TIME_WAIT, then its expiry) and the unread request bytes must still be readable.
    let mut s = sim(202, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 10, fin_after_send: true, read_paused_until: Instant::MAX, ..Default::default() };
    let id = s.connect(46100, AppConn { to_send: 40_000, fin_after_send: true, ..Default::default() });
    s.run_until(s.now + secs(3));
    let srv = s.a.accepted[0];
    let info = s.a.shard.info(srv).unwrap();
    assert!(matches!(info.state, crate::State::TimeWait | crate::State::Closed), "state {:?}", info.state);
    assert_eq!(info.rx_queued, 40_000);
    s.run_until(s.now + secs(70));
    let info = s.a.shard.info(srv).unwrap();
    assert_eq!(info.state, crate::State::Closed);
    assert_eq!(info.rx_queued, 40_000, "unread data dropped at close");
    s.a.conns.get_mut(&srv).unwrap().read_paused_until = Instant::ZERO;
    s.run_until(s.now + Duration::from_millis(10));
    let c = &s.a.conns[&srv];
    assert!(!c.corrupt);
    assert_eq!(c.received, 40_000);
    assert!(c.eof);
    assert!(s.b.conns[&id].eof);
    assert_eq!(s.a.shard.conn_count(), 0, "released after the app read and closed");
}

#[test]
fn small_cwnd_cubic_is_not_paced() {
    // A window-based CC below `pacing_min_cwnd_segs` is ACK-clocked, not paced (each paced
    // segment would cost a wakeup); a rate-based CC is paced regardless of its window.
    // 1 Mbit/s × 80 ms keeps the window far below 32 segments even with slow-start overshoot.
    let (_, info) = goodput_run(CcAlgo::Cubic, 1_000_000, 80, 1.0, 0.0, 256 << 10, Duration::ZERO);
    assert_eq!(info.stats.limited_pacing_ns, 0, "small-window CUBIC was paced");
    let (_, info) = goodput_run(CcAlgo::Bbr, 1_000_000, 80, 1.0, 0.0, 256 << 10, Duration::ZERO);
    assert!(info.stats.limited_pacing_ns > 0, "BBR must stay paced");
}

/// TCP header offset of an IPv4 packet.
fn tcp_off(pkt: &[u8]) -> usize {
    ((pkt[0] & 0xf) as usize) * 4
}

/// Offset of the TSval field of the timestamp option, if present.
fn ts_opt_off(pkt: &[u8]) -> Option<usize> {
    let t = tcp_off(pkt);
    let end = t + ((pkt[t + 12] >> 4) as usize) * 4;
    let mut i = t + 20;
    while i < end {
        match pkt[i] {
            0 => return None,
            1 => i += 1,
            8 => return Some(i + 2),
            _ => i += pkt[i + 1].max(2) as usize,
        }
    }
    None
}

/// Start a download, then inject one forged client->server segment built by `forge`
/// from the newest real one. Returns (server close reason, time from injection to close).
fn forged_segment_run(forge: impl FnOnce(&mut Sim, &mut Vec<u8>)) -> (Option<CloseReason>, Duration) {
    let mut s = sim(900, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 64 << 20, fin_after_send: true, ..Default::default() };
    let id = s.connect(46000, AppConn::default());
    s.run_until(s.now + Duration::from_millis(300));
    let mut pkt = s.ba.inflight.values().last().expect("no client segment in flight").1.to_vec();
    assert!(ts_opt_off(&pkt).is_some(), "timestamps not negotiated");
    forge(&mut s, &mut pkt);
    fix_checksums(&mut pkt);
    let t0 = s.now;
    s.a.shard.ingress(t0, s.a.iface, PeerId(1), Bytes::from(pkt));
    let srv = s.a.accepted[0];
    while s.now < t0 + secs(30) && s.a.conns.get(&srv).and_then(|c| c.closed).is_none() {
        s.run_until(s.now + Duration::from_millis(10));
    }
    let reason = s.a.conns.get(&srv).and_then(|c| c.closed);
    let took = s.now - t0;
    assert!(!s.b.conns[&id].corrupt);
    s.run_until(s.now + secs(70));
    assert_eq!(s.a.shard.conn_count(), 0, "server connection not released");
    assert_eq!(s.a.shard.budget().used, 0, "budget not released");
    (reason, took)
}

#[test]
fn forged_ack_desync_is_reset_quickly() {
    // Ack everything in flight to the client, then lose it: the sender has released
    // data the receiver never got. Previously only the 120 s user timeout ended this.
    let (reason, took) = forged_segment_run(|s, pkt| {
        let mut end = 0u32;
        let mut base = None;
        for (_, p) in s.ab.inflight.values() {
            let t = tcp_off(p);
            let seq = u32::from_be_bytes(p[t + 4..t + 8].try_into().unwrap());
            let len = (u16::from_be_bytes([p[2], p[3]]) as usize - t - ((p[t + 12] >> 4) as usize) * 4) as u32;
            let e = seq.wrapping_add(len);
            let b = *base.get_or_insert(seq);
            if e.wrapping_sub(b) > end.wrapping_sub(b) {
                end = e;
            }
        }
        assert!(base.is_some(), "no server data in flight");
        s.ab.inflight.clear();
        let t = tcp_off(pkt);
        pkt[t + 8..t + 12].copy_from_slice(&end.to_be_bytes());
    });
    assert_eq!(reason, Some(CloseReason::Desync));
    assert!(took < secs(10), "took {took:?}");
}

#[test]
fn forged_timestamp_desync_is_reset_quickly() {
    // A TSval far ahead moves TS.Recent, after which PAWS drops every real segment.
    let (reason, took) = forged_segment_run(|_, pkt| {
        let o = ts_opt_off(pkt).unwrap();
        let v = u32::from_be_bytes(pkt[o..o + 4].try_into().unwrap()).wrapping_add(1 << 30);
        pkt[o..o + 4].copy_from_slice(&v.to_be_bytes());
    });
    assert_eq!(reason, Some(CloseReason::Desync));
    assert!(took < secs(10), "took {took:?}");
}

#[test]
fn reordered_and_duplicated_acks_are_not_desync() {
    // Stale ACKs (heavy reordering, long delays, duplicates) must never look like desync.
    let mut rtos = 0;
    // Burst loss forces RTOs (the stall epochs evidence is counted against).
    for seed in 20..28 {
        let burst = if seed >= 24 { 0.7 } else { 0.0 };
        let down =
            LinkParams { loss: 0.02, burst_continue: burst, reorder: 0.05, reorder_delay: Duration::from_millis(30), duplicate: 0.05, ..Default::default() };
        let up = LinkParams { loss: 0.01, reorder: 0.3, reorder_delay: Duration::from_millis(1500), duplicate: 0.2, ..Default::default() };
        let mut s = sim(seed, down, up);
        let (_, c) = download(&mut s, 4 << 20, secs(120));
        assert_download_ok(&c, 4 << 20);
        // Let delayed duplicates arrive while the connection winds down.
        s.run_until(s.now + secs(5));
        let srv = s.a.accepted[0];
        assert_ne!(s.a.conns.get(&srv).and_then(|c| c.closed), Some(CloseReason::Desync));
        rtos += s.a.shard.info(srv).map_or(0, |i| i.stats.rto_count);
    }
    assert!(rtos > 50, "scenario too gentle: {rtos} RTOs");
}

/// Request/response shape: the server's reply is a single segment. When that
/// segment is lost, the tail-loss probe must repair it well before the 200 ms
/// RTO once the peer's delayed-ACK time (40 ms here) has been measured.
#[test]
fn lost_lone_segment_is_probed_before_rto() {
    let link = LinkParams { delay: Duration::from_millis(10), ..Default::default() };
    let mut s = sim(31, link.clone(), link);
    let id = s.connect(47000, AppConn::default());
    s.run_until(s.now + Duration::from_millis(200));
    let srv = s.a.accepted[0];
    let reply = |s: &mut Sim| {
        s.a.conns.get_mut(&srv).unwrap().to_send += 500;
    };
    // A few exchanges so the server learns RTT and the peer's ACK delay.
    for _ in 0..6 {
        reply(&mut s);
        s.run_until(s.now + Duration::from_millis(300));
    }
    let got = s.b.conns[&id].received;
    assert_eq!(got, 3000);
    // Next reply: drop it on the wire.
    reply(&mut s);
    let t0 = s.now;
    while s.ab.inflight.is_empty() {
        s.run_until(s.now + Duration::from_micros(100));
    }
    let k = *s.ab.inflight.keys().last().unwrap();
    s.ab.inflight.remove(&k);
    while s.b.conns[&id].received == got && s.now < t0 + secs(2) {
        s.run_until(s.now + Duration::from_millis(1));
    }
    let took = s.now - t0;
    assert_eq!(s.b.conns[&id].received, got + 500);
    let st = s.a.shard.info(srv).unwrap();
    println!("lone segment repaired after {took:?} ({st:?})");
    assert!(took < Duration::from_millis(150), "lone segment took {took:?} to repair (RTO-bound)");
}

#[test]
fn send_share_port_pressure_must_not_stop_a_reading_receiver() {
    // Unrelated held TX/cache memory exceeds the local pressure threshold,
    // but leaves enough physical room for this receiver to keep draining.
    // Exercise both a pressured port and a pressured peer on a roomy port.
    for port_limit in [819_200, 1_638_400] {
        let mut s = sim(67401, LinkParams::default(), LinkParams::default());
        s.b.shard.set_budget_limits(port_limit, 819_200, 128);
        let _held = s.b.shard.memory_handle(PeerId(1)).try_allocate(550_000).unwrap();
        let (_, c) = download(&mut s, 1 << 20, secs(10));
        assert_download_ok(&c, 1 << 20);
    }
}

#[test]
fn send_share_growth_emits_writable_without_own_ack() {
    assert_share_growth_writable(false);
    assert_share_growth_writable(true);
}

fn assert_share_growth_writable(read_before_run: bool) {
    let mut cfg = StackConfig::default();
    cfg.min_prefetch = 1 << 20;
    cfg.prefetch_max = 1 << 20;
    let mut s = Sim::new(67402, cfg, StackConfig::default(), LinkParams::default(), LinkParams::default());
    s.a.shard.set_budget_limits(819_200, 819_200, 128);
    s.connect(41001, AppConn::default());
    s.connect(41002, AppConn::default());
    s.run_until(s.now + Duration::from_millis(100));
    let x = s.a.accepted[0];
    let y = s.a.accepted[1];
    assert_eq!(s.a.shard.write(x, &vec![1; 16 << 10]), WriteResult::Written(16 << 10));
    assert_eq!(s.a.shard.write(y, &vec![1; 16 << 10]), WriteResult::Written(16 << 10));
    let room = s.a.shard.send_space(x);
    assert_eq!(s.a.shard.write(x, &vec![1; room]), WriteResult::Written(room));
    assert_eq!(s.a.shard.write(x, &[1]), WriteResult::QuotaBlocked);
    while s.a.shard.poll_event().is_some() {}
    assert!(s.a.shard.budget_wait_epoch().is_some(), "share writer must arm the driver release wake");
    let mut sink = |_: IfaceId, _: &crate::OutPacket<'_>| crate::SendResult::Full;
    // An unrelated allocation release must not emit a false Writable.
    drop(s.a.shard.memory_handle(PeerId(2)).try_allocate(1).unwrap());
    s.a.shard.run(s.now, &mut sink);
    assert!(!std::iter::from_fn(|| s.a.shard.poll_event()).any(|ev| matches!(ev, Event::Writable(id) if id == x)));
    assert!(s.a.shard.budget_wait_epoch().is_some());
    s.a.shard.abort(y);
    assert!(s.a.shard.send_space(x) >= 64 << 10);
    // Visiting x before run must not silently drop the now-satisfied waiter.
    if read_before_run {
        let _ = s.a.shard.read(s.now, x, &mut [0u8; 1]);
    }
    s.a.shard.run(s.now, &mut sink);
    let mut writable = false;
    while let Some(ev) = s.a.shard.poll_event() {
        if matches!(ev, Event::Writable(id) if id == x) {
            writable = true;
        }
    }
    assert!(writable, "share grew, but no Writable event was emitted");
    assert!(s.a.shard.budget_wait_epoch().is_none());
    s.a.shard.run(s.now, &mut sink);
    assert!(!std::iter::from_fn(|| s.a.shard.poll_event()).any(|ev| matches!(ev, Event::Writable(id) if id == x)), "no duplicate Writable");
    // Re-arm, then destroy the waiting connection: no stale release wake
    // may survive for a future occupant of this slot.
    let room = s.a.shard.send_space(x);
    assert_eq!(s.a.shard.write(x, &vec![1; room]), WriteResult::Written(room));
    assert_eq!(s.a.shard.write(x, &[1]), WriteResult::QuotaBlocked);
    assert!(s.a.shard.budget_wait_epoch().is_some());
    s.a.shard.abort(x);
    assert!(s.a.shard.budget_wait_epoch().is_none());
}

#[test]
fn lost_window_update_is_recovered_by_persist() {
    // zfstack#15: the receiver reopens its window with one pure ACK; when that
    // ACK is lost, the sender's persist probe must fetch the window again.
    for cc in [CcAlgo::Cubic, CcAlgo::Bbr] {
        let p = LinkParams { rate_bps: 50_000_000, delay: Duration::from_millis(40), queue_bytes: 128 << 10, ..Default::default() };
        let mut cfg = StackConfig::default();
        cfg.cc = cc;
        let mut s = Sim::new(10021, cfg, StackConfig::default(), p.clone(), p);
        let start = s.now;
        s.a.accept_template = AppConn { to_send: 512 << 10, fin_after_send: true, ..Default::default() };
        let id = s.connect(40000, AppConn { to_send: 512 << 10, fin_after_send: true, read_paused_until: start + secs(2), ..Default::default() });
        s.run_until(start + Duration::from_millis(1900));
        let server = s.a.accepted[0];
        assert_eq!(s.a.shard.info(server).unwrap().snd_wnd, 0);
        s.run_until(start + secs(2));
        // Drop only the pure ACK which announces the reopened receive window.
        let before = s.ba.inflight.len();
        s.ba.inflight.retain(|_, (_, packet)| {
            let ip = crate::wire::parse_ip(packet).unwrap();
            let tcp = crate::wire::parse_tcp(packet, &ip).unwrap();
            !(tcp.window > 0 && tcp.flags == crate::wire::ACK && ip.l4_len == tcp.data_off)
        });
        assert_eq!(before - s.ba.inflight.len(), 1, "{cc:?}");
        s.run_until(start + secs(15));
        assert_download_ok(&s.b.conns[&id], 512 << 10);
        assert_download_ok(&s.a.conns[&server], 512 << 10);
    }
}

#[test]
fn keepalive_probe_is_answered_with_open_window() {
    // A keepalive probe (seq = SND.UNA - 1, no data) must be ACKed while the
    // receive window is open, or a peer that probes (e.g. a kernel client with
    // SO_KEEPALIVE) resets an idle but healthy connection.
    let mut quiet = StackConfig::default();
    quiet.keepalive_idle = Duration::from_secs(3600);
    let mut prober = StackConfig::default();
    prober.keepalive_idle = Duration::from_secs(5);
    prober.keepalive_interval = Duration::from_secs(5);
    prober.keepalive_probes = 2;
    let mut s = Sim::new(42, quiet, prober, LinkParams::default(), LinkParams::default());
    let id = s.connect(40001, AppConn::default());
    s.run_until(s.now + secs(60));
    let client = &s.b.conns[&id];
    assert_eq!(client.closed, None, "idle connection was reset by unanswered keepalives");
    let server = s.a.accepted[0];
    assert_eq!(s.a.conns[&server].closed, None);
    assert!(s.b.shard.info(id).is_some());
}

#[test]
fn unseeded_shards_keep_random_isn() {
    // Seeding is simulator-only: production shards still draw secret keys.
    let first_syn = || {
        let mut sh = Shard::with_budget(StackConfig::default(), crate::budget::GlobalBudget::new(1 << 30));
        let iface = sh.add_iface(Default::default());
        let now = Instant::from_millis(1000);
        sh.connect(now, iface, PeerId(1), addr("10.0.0.2:40000"), addr("10.0.0.1:80"));
        let mut syn = Vec::new();
        sh.run(now, &mut |_: IfaceId, pkt: &OutPacket<'_>| {
            syn.push(pkt.to_vec());
            SendResult::Accepted
        });
        syn.remove(0)
    };
    let syns: Vec<Vec<u8>> = (0..4).map(|_| first_syn()).collect();
    assert!(syns.iter().any(|p| p != &syns[0]), "unseeded shards produced identical SYNs");
}

/// Soak shape of zfstack#15: lossy, reordering long-RTT link, a server that only
/// runs every 5 ms, several bidirectional flows and one reader that pauses 2 s.
/// `ZFSTACK_SOAK_SEEDS=a..b` widens the seed range (default: the reported seeds).
#[test]
#[ignore]
fn soak_paused_reader_lossy_multiflow() {
    let seeds: Vec<u64> = match std::env::var("ZFSTACK_SOAK_SEEDS") {
        Ok(r) => {
            let (a, b) = r.split_once("..").expect("a..b");
            (a.parse().unwrap()..b.parse().unwrap()).collect()
        }
        Err(_) => vec![10021, 10033, 10047],
    };
    let mut failed = Vec::new();
    for &seed in &seeds {
        for cc in [CcAlgo::Cubic, CcAlgo::Bbr] {
            let t = std::time::Instant::now();
            let p = LinkParams {
                rate_bps: 50_000_000,
                delay: Duration::from_millis(40),
                queue_bytes: 256 << 10,
                loss: 0.01,
                reorder: 0.01,
                duplicate: 0.01,
                ..Default::default()
            };
            let mut cfg = StackConfig::default();
            cfg.cc = cc;
            let mut s = Sim::new(seed, cfg, StackConfig::default(), p.clone(), p);
            s.gap_a = Duration::from_millis(5);
            s.check_invariants = false;
            let start = s.now;
            let n = 4u64;
            s.a.accept_template = AppConn { to_send: 512 << 10, fin_after_send: true, ..Default::default() };
            let ids: Vec<ConnId> = (0..n)
                .map(|i| {
                    let paused = if i == seed % n { start + secs(2) } else { start };
                    s.connect(47000 + i as u16, AppConn { to_send: 512 << 10, fin_after_send: true, read_paused_until: paused, ..Default::default() })
                })
                .collect();
            s.run_until(start + secs(60));
            let ok = ids.iter().all(|id| {
                let c = &s.b.conns[id];
                !c.corrupt && c.eof && c.received == 512 << 10 && c.closed != Some(CloseReason::Reset)
            }) && s.a.conns.values().all(|c| !c.corrupt && c.eof && c.received == 512 << 10);
            eprintln!("soak seed={seed} cc={cc:?} ok={ok} wall={:?}", t.elapsed());
            if !ok {
                failed.push((seed, cc));
            }
        }
    }
    assert!(failed.is_empty(), "failed: {failed:?}");
}

#[test]
fn zero_window_data_probe_is_answered() {
    // Some stacks probe a zero window with one byte of new data at RCV.NXT. The
    // byte is dropped, but the probe must still be ACKed (with the current
    // window), or a lost window update is never repaired for those peers.
    let mut cfg_b = StackConfig::default();
    cfg_b.max_rcv_buf = 64 * 1024;
    cfg_b.init_rcv_wnd = 32 * 1024;
    let mut s = Sim::new(43, StackConfig::default(), cfg_b, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 1 << 20, ..Default::default() };
    let id = s.connect(40004, AppConn::default());
    s.b.conns.get_mut(&id).unwrap().read_paused_until = s.now + secs(60);
    s.run_until(s.now + secs(2));
    let srv = s.a.accepted[0];
    assert_eq!(s.a.shard.info(srv).unwrap().snd_wnd, 0, "window should be closed");
    // The server's own persist probe is a pure ACK at SND.UNA - 1; turn it into
    // a one-byte data probe at SND.UNA.
    let probe = loop {
        let found = s.ab.inflight.values().map(|(_, p)| p).find(|p| {
            let ip = crate::wire::parse_ip(p).unwrap();
            ip.l4_len == crate::wire::parse_tcp(p, &ip).unwrap().data_off
        });
        if let Some(p) = found {
            break p.to_vec();
        }
        s.run_until(s.now + Duration::from_millis(10));
    };
    let t = tcp_off(&probe);
    let mut pkt = probe.clone();
    let seq = u32::from_be_bytes(pkt[t + 4..t + 8].try_into().unwrap()).wrapping_add(1);
    pkt[t + 4..t + 8].copy_from_slice(&seq.to_be_bytes());
    pkt.push(0);
    let total = pkt.len() as u16;
    pkt[2..4].copy_from_slice(&total.to_be_bytes());
    fix_checksums(&mut pkt);
    s.ab.inflight.clear();
    let now = s.now;
    s.b.shard.ingress(now, s.b.iface, PeerId(1), Bytes::from(pkt));
    let mut acks = Vec::new();
    s.b.shard.run(now, &mut |_: IfaceId, p: &OutPacket<'_>| {
        let p = p.to_vec();
        let ip = crate::wire::parse_ip(&p).unwrap();
        let tcp = crate::wire::parse_tcp(&p, &ip).unwrap();
        acks.push((tcp.ack.0, tcp.window));
        SendResult::Accepted
    });
    assert_eq!(acks, vec![(seq, 0)], "data probe into a zero window was not ACKed");
}

#[test]
fn tx_capacity_eight_flows_survive_loss_reorder_fin_and_release() {
    for cap in [4097, 65537, 256 * 1024] {
        let cfg = StackConfig { max_snd_buf: cap, ..StackConfig::client() };
        let p = LinkParams { loss: 0.01, reorder: 0.02, duplicate: 0.01, ..Default::default() };
        let mut s = Sim::new(929, cfg.clone(), cfg, p.clone(), p);
        s.a.accept_template = AppConn { to_send: 256 * 1024 + 17, fin_after_send: true, ..Default::default() };
        for i in 0..8 {
            s.connect_as(
                PeerId(1 + i % 2),
                46000 + i as u16,
                AppConn { to_send: 64 * 1024 + 9, fin_after_send: true, read_paused_until: s.now + Duration::from_millis(500), ..Default::default() },
            );
        }
        for _ in 0..3000 {
            s.run_until(s.now + Duration::from_millis(10));
            for side in [&s.a, &s.b] {
                for id in side.conns.keys() {
                    if let Some(info) = side.shard.info(*id) {
                        assert!(info.tx_queued as u64 <= cap);
                    }
                }
            }
            if s.b.conns.values().all(|c| c.eof) && s.a.conns.values().all(|c| c.eof) {
                break;
            }
        }
        assert_eq!(s.a.conns.len(), 8);
        for c in s.b.conns.values() {
            assert_download_ok(c, 256 * 1024 + 17);
        }
        for c in s.a.conns.values() {
            assert_download_ok(c, 64 * 1024 + 9);
        }
        assert!(s.ab.stats.random_drops > 0 && s.ba.stats.random_drops > 0);
        s.run_until(s.now + secs(70));
        assert_eq!((s.a.shard.conn_count(), s.b.shard.conn_count()), (0, 0));
        assert_eq!((s.a.shard.budget().used, s.b.shard.budget().used), (0, 0));
        let a = s.a.shard.budget().global().clone();
        let b = s.b.shard.budget().global().clone();
        drop(s);
        assert_eq!((a.reserved(), b.reserved()), (0, 0));
    }
}

#[test]
fn tx_capacity_abort_with_outstanding_data_sends_reset_and_releases() {
    let cfg = StackConfig { max_snd_buf: 4097, ..StackConfig::client() };
    let mut s = Sim::new(930, cfg.clone(), cfg, LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { to_send: 1 << 20, ..Default::default() };
    let cid = s.connect(46000, AppConn { read_paused_until: Instant::MAX, ..Default::default() });
    s.run_until(s.now + Duration::from_millis(100));
    let sid = s.a.accepted[0];
    assert!(s.a.shard.info(sid).unwrap().tx_queued > 0);
    s.a.shard.abort(sid);
    s.a.conns.remove(&sid);
    s.run_until(s.now + secs(1));
    assert_eq!(s.b.conns[&cid].closed, Some(CloseReason::Reset));
    assert_eq!(s.a.shard.budget().used, 0);
    let a = s.a.shard.budget().global().clone();
    let b = s.b.shard.budget().global().clone();
    drop(s);
    assert_eq!((a.reserved(), b.reserved()), (0, 0));
}

#[test]
fn tx_capacity_zero_still_receives_data_and_exchanges_fin() {
    let cfg = StackConfig { max_snd_buf: 0, ..StackConfig::client() };
    let mut s = Sim::new(931, cfg, StackConfig::client(), LinkParams::default(), LinkParams::default());
    s.a.accept_template = AppConn { fin_after_send: true, ..Default::default() };
    let id = s.connect(46000, AppConn { to_send: 128 * 1024 + 1, fin_after_send: true, ..Default::default() });
    s.run_until(s.now + secs(10));
    assert_download_ok(&s.b.conns[&id], 0);
    assert_download_ok(&s.a.conns[&s.a.accepted[0]], 128 * 1024 + 1);
}

#[test]
fn stale_share_wait_epoch_does_not_self_wake_after_unrelated_release() {
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::Arc;
    use std::task::{Wake, Waker};
    struct Count(AtomicUsize);
    impl Wake for Count {
        fn wake(self: Arc<Self>) {
            self.wake_by_ref();
        }
        fn wake_by_ref(self: &Arc<Self>) {
            self.0.fetch_add(1, Ordering::SeqCst);
        }
    }
    let mut cfg = StackConfig::default();
    cfg.min_prefetch = 1 << 20;
    cfg.prefetch_max = 1 << 20;
    let mut s = Sim::new(67402, cfg, StackConfig::default(), LinkParams::default(), LinkParams::default());
    s.a.shard.set_budget_limits(819_200, 819_200, 128);
    s.connect(41001, AppConn::default());
    s.connect(41002, AppConn::default());
    s.run_until(s.now + Duration::from_millis(100));
    let x = s.a.accepted[0];
    let y = s.a.accepted[1];
    assert_eq!(s.a.shard.write(x, &vec![1; 16 << 10]), WriteResult::Written(16 << 10));
    assert_eq!(s.a.shard.write(y, &vec![1; 16 << 10]), WriteResult::Written(16 << 10));
    let room = s.a.shard.send_space(x);
    assert_eq!(s.a.shard.write(x, &vec![1; room]), WriteResult::Written(room));
    assert_eq!(s.a.shard.write(x, &[1]), WriteResult::QuotaBlocked);
    while s.a.shard.poll_event().is_some() {}
    let mut sink = |_: IfaceId, _: &crate::OutPacket<'_>| crate::SendResult::Full;
    let global = s.a.shard.budget().global().clone();
    let id = global.new_waiter_id();
    let count = Arc::new(Count(AtomicUsize::new(0)));
    let waker = Waker::from(count.clone());
    // One unrelated release, then a bare driver loop: run, re-register. `run`
    // must refresh the handed-out epoch so no registration wakes at once.
    drop(s.a.shard.memory_handle(PeerId(2)).try_allocate(1).unwrap());
    let mut wakes = Vec::new();
    for _ in 0..5 {
        s.a.shard.run(s.now, &mut sink);
        while s.a.shard.poll_event().is_some() {}
        let before = count.0.load(Ordering::SeqCst);
        let epoch = s.a.shard.budget_wait_epoch().expect("still share-blocked");
        global.register_waiter(id, epoch, &waker);
        wakes.push(count.0.load(Ordering::SeqCst) - before);
    }
    global.remove_waiter(id);
    assert!(wakes.iter().all(|&w| w == 0), "bare driver keeps self-waking: {wakes:?}");
    // Share growth from a sender exit must still wake x.
    s.a.shard.abort(y);
    s.a.shard.run(s.now, &mut sink);
    assert!(std::iter::from_fn(|| s.a.shard.poll_event()).any(|ev| matches!(ev, Event::Writable(i) if i == x)));
}
