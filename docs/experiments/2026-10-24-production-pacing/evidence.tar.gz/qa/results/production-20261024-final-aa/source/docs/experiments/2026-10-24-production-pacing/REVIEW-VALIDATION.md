# Review follow-up, declared after V3 WAN and before these attempts

All 96 V3 native-splice WAN attempts were valid. All 12 loaded cells improved
mean/P99 latency, candidate bulk-flow inactivity was zero, and 79,200 planned
light requests completed. However the two-pair single-flow estimates were
-4.57% for BBR/500 ms and -3.62% for CUBIC/100 ms; every single-flow pacing
counter was zero. The latter CUBIC cell included one 94.24-Mbps control and
three 86.87–87.41-Mbps observations. Neither bypass nor a noisy-looking pair
alone establishes a physical throughput guard. Retain these original results.

Code review also identified a separate extreme-capacity boundary: when one
MTU costs more than the one-second contention hold, competing input after the
hold expires can currently reset a still-future paused deadline. After the
fixed V3 sequence and its external-upload guard finish, correct this reset
condition and add a regression. Also bypass the pacer call itself while it is
inactive and a single peer is ready, retaining the original packet/time path
and avoiding unnecessary inactive-state writes. Do not change the selected
99% rate, batch, catch-up credit, hold duration, queueing or memory policy.
Add a native two-peer real-splice bidirectional/half-close/teardown regression.

Run all required suites before building/freeze a new V4 binary. Keep V3 and its
exact source snapshots: its matrix/confirmation are measurements of V3, not
silently relabelled V4 measurements. Then execute these fixed, serial guards:

1. **48 longer single-flow WAN attempts:** CUBIC/100 ms and BBR/500 ms,
   each 12 balanced adjacent off/on pairs; same FIFO and V4 binary in both
   arms. Warmup max(8 s, 40 RTT), **40-s** measured windows. Retain V3's
   original two-pair estimates separately. Report paired bootstrap intervals;
   require useful-throughput lower bound >= -3% to qualify these cells.
2. **24 cross-binary single-download peak attempts:** the frozen old final
   binary against configured V4, 12 balanced pairs, same actual local
   TUN/Tokio/splice path and settings as the original 60-attempt peak cohort.
   Require useful-throughput lower bound >= -3%. Other V3 peak cases remain
   V3 measurements, with no claimed additional repetition.
3. **48 independent loaded splice confirmation attempts:** CUBIC/BBR,
   20 ms/200 downloads, 12 balanced pairs each with the original 8-s warmup/20-s
   window. Keep them distinct from V3's independent 12-pair estimates;
   use V4's own whole-pair intervals for final-code CPU/latency claims. Validate
   request/budget/teardown and finite per-flow progress; report every CPU scope.

If a guard remains inconclusive or fails, do not discard the early samples,
substitute a larger FIFO, or claim that all requirements are established.
No further rate-factor search or optional stopping is planned. These are
targeted review/physical guards, not a second exhaustive RTT experiment.
