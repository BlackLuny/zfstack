#!/usr/bin/env python3
"""Collect immutable production-pacing evidence and audit executed identities."""
import argparse
import json
from pathlib import Path

import production_pacing as native
import production_peaks as peaks
import production_mixed as mixed
from run import ROOT, save, sha

COHORTS = [
    ("v1-screen",native.analyze),
    ("v2-tokio-smoke",native.analyze),("v2-tokio-pilot",native.analyze),
    ("v3-splice-smoke",native.analyze),("v3-splice-pilot",native.analyze),
    ("final-wan",native.analyze),("final-confirm",native.analyze),
    ("final-guard",native.analyze),("final-aa",native.analyze),
    ("final-cross-peak",peaks.analyze),
    ("mixed-smoke",mixed.analyze),("final-mixed",mixed.analyze),
]


def audit(out, result):
    plan=json.loads((out/'plan.json').read_text())
    errors=[]
    cross=isinstance(plan['binary_sha256'],dict)
    if len(result['rows'])!=len(plan['rows']):errors.append('planned attempts are missing')
    if not (out/'complete.json').exists():errors.append('cohort did not complete')
    if not cross:
        for name,digest in plan['sources'].items():
            f=out/'source'/name
            if not f.exists() or sha(f)!=digest:errors.append('frozen source mismatch: '+name)
    planned={r['index']:r for r in plan['rows']}
    for row in result['rows']:
        p=out/row['name'];start=json.loads((p/'start.json').read_text());end=json.loads((p/'end.json').read_text())
        expected=planned[row['index']]
        if start['row']!=expected:errors.append(row['name']+': row differs from plan')
        digest=plan['binary_sha256'][row['arm']] if cross else plan['binary_sha256']
        if start['binary_sha256']!=digest or not end['binary_unchanged']:errors.append(row['name']+': binary changed')
        argv=start['argv']
        binary=next((s.removeprefix('/work/') for s in argv if s.startswith('/work/target/release/')),None)
        if not binary or sha(ROOT/binary)!=digest:errors.append(row['name']+': retained binary differs')
        if not cross:
            raw=json.loads((p/'stdout.json').read_text());cfg=raw['config']
            requested=argv[argv.index('--iface-egress-rate')+1]
            if int(requested)!=expected['egress_rate'] or cfg['iface_egress_rate']!=expected['egress_rate']:
                errors.append(row['name']+': configured rate differs')
            for direction in ('up','down'):
                link=raw['link'][direction]
                if link['queue_discipline']!='fifo-service' or link['params']['queue_limit_bytes']!=expected.get('queue_bytes',250000):
                    errors.append(row['name']+': physical FIFO differs')
                if link['params']['rate_bps']!=expected.get('rate_mbps',100)*1_000_000:
                    errors.append(row['name']+': physical capacity differs')
            if bool('--tokio-stack' in argv)!=expected.get('tokio_stack',False) or bool('--splice' in argv)!=expected.get('splice',False):
                errors.append(row['name']+': runtime/relay invocation differs')
            if expected.get('tokio_stack'):
                stats=raw['stack_thread']['stack_stats']
                if stats['impl']!='zfstack-tokio' or stats.get('production_splice',False)!=expected.get('splice',False):
                    errors.append(row['name']+': runtime/relay result differs')
            if expected['lights']==0 and row.get('egress_paced_bytes',0):
                errors.append(row['name']+': single-peer bypass intervened')
    return dict(cohort=out.name,identity_valid=not errors,errors=errors,planned=len(plan['rows']),audited=len(result['rows']))


def collect(destination):
    destination.mkdir(parents=True,exist_ok=True)
    cohorts=[];audits=[]
    for name,analyze in COHORTS:
        out=ROOT/'qa/results'/('production-20261024-'+name)
        result=analyze(out)
        record=audit(out,result);audits.append(record)
        save(destination/(name+'-summary.json'),result)
        cohorts.append(dict(name=name,planned=result['planned'],completed=result['completed'],valid=result['valid'],
            planned_requests=sum(r.get('planned_requests',0) for r in result['rows']),
            missing_requests=sum(r.get('missing_requests',0) for r in result['rows']),
            throttled_events=sum(r.get('nr_throttled',0) for r in result['rows']),
            identity_valid=record['identity_valid'],
            invalid=[dict(name=r['name'],errors=r['errors']) for r in result['rows'] if not r['valid']]))
    save(destination/'audit.json',audits)
    save(destination/'cohorts.json',dict(cohorts=cohorts,counts={k:sum(c[k] for c in cohorts) for k in ['planned','completed','valid','planned_requests','missing_requests','throttled_events']}))
    return dict(identity_valid=all(a['identity_valid'] for a in audits),cohorts=len(cohorts))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('destination',type=Path);a=p.parse_args()
    print(json.dumps(collect(a.destination.resolve()),indent=2))
