//! TCP bidirectional relay pipeline

use zfw_runtime::connect::connect_to_remote_with_preference;
use super::types::{ConnectionGuard, RealyTcpError};
use zfw_common::collector_factory::Handle;
use zfw_common::conn_limitter::Guard;
use zfw_common::conn_stats::{ConnStatsManager, ConnTrafficCounters, ConnectionType};
#[cfg(not(target_os = "linux"))]
use zfw_common::custom_bidi_copy;
use zfw_common::env_var::{env_direct_down_buffer_size, env_direct_up_buffer_size};
use crate::preludes::{NetworkConfig, debug, error};
use tokio_util;
use zfw_api::protocol_types::TcpStreamType;
use shared_crate::server_provider::ServerSelector;
use zfw_policy::traffic_routing::{
    select_static_server_from_selector_strategies, MatchedSelectorResult, TrafficRoutingContext,
};
use zfw_common::zero_copy_wrapper::ZeroCopyWrapper;
use anyhow::Result;
use private_tun::print_size;
use pt_core::proxy_protocol::{handle_proxy_protocol, ProxyProtocolConfig};
use private_tun::rate_limitter_io::SpeedRateLimitterPair;
use private_tun::traffic_filter::TrafficFilter;
use shared_crate::conn_protect::ConnProtect;
use shared_crate::rule_matcher::Protocol;
use smallvec::smallvec;
use socket2::TcpKeepalive;
use std::net::{IpAddr, Ipv4Addr, SocketAddr};
use std::sync::Arc;
use tokio::io::AsyncWriteExt;
use tokio::select;
use tokio_util::sync::CancellationToken;
use uuid::Uuid;

pub(crate) async fn start_tcp_relay<T: super::tcp_relay_stream::TcpRelayStream>(
    mut client_stream: T,
    port: u16,
    port_key: shared_crate::app_message::PortKey,
    server_selector: ServerSelector,
    net_config: Arc<NetworkConfig>,
    collector: Handle,
    cancel: CancellationToken,
    incoming_addr: SocketAddr,
    guard: Option<Guard>,
    conn_guard: ConnectionGuard,
    conn_protect: Arc<ConnProtect>,
    conn_stats_manager: Arc<ConnStatsManager>,
    speed_rate_limitter: Option<Arc<SpeedRateLimitterPair>>,
    proxy_protocol_config: Option<Arc<ProxyProtocolConfig>>,
    allow_private_ip: bool,
    preferred_server: Option<std::sync::Arc<shared_crate::server_provider::ServerInfo>>,
    traffic_counters: Option<ConnTrafficCounters>,
    mut outbound_ready: zfw_port_backend::OutboundReady,
) -> Result<(), RealyTcpError> {
    let conn = select! {
        biased;
        r = connect_to_remote_with_preference(
            &server_selector,
            net_config.socks_backend().map(|x| x.as_ref()),
            Some(&net_config),
            Some(&conn_protect),
            allow_private_ip,
            preferred_server,
        ) => {
            r
        }
        _ = cancel.cancelled() => {
            log::debug!("TCP#{} <- {:?}: canceled on connect", port, &incoming_addr);
            outbound_ready.send(Err(anyhow::anyhow!("connect canceled")));
            let _ = client_stream.shutdown().await;
            return Err(RealyTcpError::ConnectCanceled);
        }
    };
    let (mut stream, target_addr) = match conn {
        Ok(v) => {
            // D-S1a-1 Direct: `connect_to_remote_with_preference` returns only
            // after `connect_with` (socket created in netns, connect outside) succeeds.
            // hy2 TCPResponse is emitted by the stream adapter on first write/read.
            outbound_ready.send(Ok(()));
            v
        }
        Err(e) => {
            log::error!(
                "TCP#{} <- {:?}: connect remote failed: {:?}",
                port,
                &incoming_addr,
                e
            );
            outbound_ready.send(Err(anyhow::anyhow!("direct connect: {e}")));
            let _ = client_stream.shutdown().await;
            return Err(e);
        }
    };
    // Bound unsent TCP data so slow targets propagate backpressure promptly (#758).
    private_tun::tune_tcp_relay_socket(&stream);
    let _ = stream.set_nodelay(true);
    let session_id = Uuid::new_v4();
    log::debug!(
        "TCP#{} <- {:?} <-> {:?} <-> {:?}: session_id: {}",
        port,
        &incoming_addr,
        stream
            .local_addr()
            .unwrap_or(SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0)),
        stream
            .peer_addr()
            .unwrap_or(SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0)),
        session_id
    );
    {
        let socket_ref = socket2::SockRef::from(&stream);
        #[cfg(target_os = "linux")]
        let _ = socket_ref.set_tcp_user_timeout(Some(std::time::Duration::from_secs(30)));
        let _ = socket_ref.set_tcp_keepalive(
            &TcpKeepalive::new()
                .with_time(std::time::Duration::from_secs(300))
                .with_interval(std::time::Duration::from_secs(2))
                .with_retries(1),
        );
    }
    // Create per-connection cancel token as child of port-level cancel
    let conn_cancel = cancel.child_token();
    let conn_stats_handle = conn_stats_manager.add_stats_for_key(
        port_key,
        port,
        incoming_addr,
        target_addr,
        None,
        ConnectionType::Tcp,
        Some(session_id.clone()),
        None,
        None,
        None,
        stream.local_addr().ok(),
        None, // real_target_addr：仅 TOT 入站代理填值
        Some(conn_cancel.clone()),
        traffic_counters,
        None,
    );

    if let Some(proxy_protocol_config) = proxy_protocol_config.as_ref() {
        select! {
            biased;
            r = handle_proxy_protocol(
                &mut client_stream,
                &incoming_addr,
                &mut stream,
                proxy_protocol_config,
            ) => {
                r?;
            }
            _ = cancel.cancelled() => {
                log::debug!(
                    "TCP#{} <- {:?}: canceled during proxy protocol",
                    port,
                    &incoming_addr
                );
                let _ = client_stream.shutdown().await;
                return Err(RealyTcpError::ConnectCanceled);
            }
            _ = tokio::time::sleep(proxy_protocol_config.timeout) => {
                log::debug!(
                    "TCP#{} <- {:?}: proxy protocol timeout",
                    port,
                    &incoming_addr
                );
                let _ = client_stream.shutdown().await;
                return Err(RealyTcpError::GetTargetInfoFailed(anyhow::anyhow!(
                    "PROXY protocol timeout"
                )));
            }
        }
    }

    let mut local = ZeroCopyWrapper::new(client_stream, Some(collector.collector.clone()));
    // 一个方向读到 EOF 后观察该侧 socket 故障（S4 §8.2）；Linux 路径在 tcp_splice 内部取。
    #[cfg(not(target_os = "linux"))]
    // SAFETY: local 与 stream 被本连接的拷贝任务独占到结束，观察器随拷贝结束。
    // 非 Linux 路径把 stream 移进限速包装，只能按编号观察（Linux 路径在 tcp_splice 内复用裸 TCP 注册）。
    let faults = custom_bidi_copy::HalfCloseFaults {
        a: super::tcp_relay_stream::TcpRelayStream::fault_fd(&local.stream).map(|fd| {
            custom_bidi_copy::HalfCloseFault::Fd(unsafe { private_tun::socket_fault::FaultFd::from_raw(fd) })
        }),
        b: Some(custom_bidi_copy::HalfCloseFault::Fd(unsafe { private_tun::socket_fault::FaultFd::of(&stream) })),
    };
    #[cfg(not(target_os = "linux"))]
    use private_tun::rate_limitter_io::AsyncWriteRateLimitExt;
    if let Some(speed_rate_limitter) = speed_rate_limitter {
        #[cfg(not(target_os = "linux"))]
        let limiter1 = speed_rate_limitter.get_up();
        #[cfg(not(target_os = "linux"))]
        let limiter2 = speed_rate_limitter.get_down();
        #[cfg(not(target_os = "linux"))]
        let mut remote = stream.ratelimit_write(limiter1);
        #[cfg(not(target_os = "linux"))]
        let mut local = local.ratelimit_write(limiter2);

        let task = async move {
            let _collector = collector;
            let _conn_stats_handle = conn_stats_handle;
            let _guard = guard;
            let _conn_guard = conn_guard;
            #[cfg(target_os = "linux")]
            let relay_task = super::tcp_splice::copy_direct_limited(
                &mut local, &mut stream, &_collector.collector,
                env_direct_up_buffer_size(), env_direct_down_buffer_size(), &speed_rate_limitter,
            );
            #[cfg(not(target_os = "linux"))]
            let relay_task = custom_bidi_copy::copy_bidirectional_watched(
                &mut local,
                &mut remote,
                env_direct_up_buffer_size(),
                env_direct_down_buffer_size(),
                faults,
            );
            select! {
                biased;
                r = relay_task => {
                    if let Err(e) = r {
                        match e.kind() {
                            // Peer went away (client finished and closed, #649) — normal teardown, not a relay fault.
                            std::io::ErrorKind::TimedOut | std::io::ErrorKind::ConnectionReset | std::io::ErrorKind::ConnectionRefused
                            | std::io::ErrorKind::BrokenPipe | std::io::ErrorKind::ConnectionAborted => {
                                log::debug!("session_id: {} TCP#{} <- {:?}: {:?}", session_id, port, &incoming_addr, e);
                            }
                            e => {
                                error!("session_id: {} TCP#{} <- {:?}: {:?}", session_id, port, &incoming_addr, e);
                            }
                        }
                    } else {
                        log::debug!("session_id: {} TCP#{} <- {:?}: success", session_id, port, &incoming_addr);
                    }
                }
                _ = conn_cancel.cancelled() => {
                    debug!("session_id: {} TCP#{} <- {:?}: canceled", session_id, port, &incoming_addr);
                }

            };
            // let _ = local.shutdown().await;
            // let _ = remote.shutdown().await;
        };
        tokio::spawn(print_size(
            task,
            "start_tcp_relay_task_relay_task_speed_rate_limitter",
        ));
    } else {
        let conn_cancel = conn_cancel;
        let task = async move {
            let _collector = collector;
            let _conn_stats_handle = conn_stats_handle;
            let _guard = guard;
            let _conn_guard = conn_guard;
            #[cfg(target_os = "linux")]
            let relay_task = super::tcp_splice::copy_direct(
                &mut local,
                &mut stream,
                &_collector.collector,
                env_direct_up_buffer_size(),
                env_direct_down_buffer_size(),
            );
            #[cfg(not(target_os = "linux"))]
            let relay_task = custom_bidi_copy::copy_bidirectional_watched(
                &mut local,
                &mut stream,
                env_direct_up_buffer_size(),
                env_direct_down_buffer_size(),
                faults,
            );
            log::debug!(
                "session_id: {} TCP#{} <- {:?}: start relay task",
                session_id,
                port,
                &incoming_addr
            );
            select! {
                biased;
                r =  relay_task => {
                    if let Err(e) = r {
                        match e.kind() {
                            // Peer went away (client finished and closed, #649) — normal teardown, not a relay fault.
                            std::io::ErrorKind::TimedOut | std::io::ErrorKind::ConnectionReset | std::io::ErrorKind::ConnectionRefused
                            | std::io::ErrorKind::BrokenPipe | std::io::ErrorKind::ConnectionAborted => {
                                log::debug!("session_id: {} TCP#{} <- {:?}: {:?}", session_id, port, &incoming_addr, e);
                            }
                            e => {
                                error!("session_id: {} TCP#{} <- {:?}: {:?}", session_id, port, &incoming_addr, e);
                            }
                        }
                    } else {
                        log::debug!("session_id: {} TCP#{} <- {:?}: success", session_id, port, &incoming_addr);
                    }
                }
                _ = conn_cancel.cancelled() => {
                    debug!("session_id: {} TCP#{} <- {:?}: canceled", session_id, port, &incoming_addr);
                }

            };
            // let _ = local.shutdown().await;
            // let _ = stream.shutdown().await;
        };
        tokio::spawn(print_size(
            task,
            "start_tcp_relay_task_relay_task_no_speed_rate_limitter",
        ));
    }
    Ok(())
}

pub(crate) fn direct_or_socks5_relay(
    client_stream: TcpStreamType,
    port: u16,
    port_key: shared_crate::app_message::PortKey,
    server_selector: ServerSelector,
    net_config: Arc<NetworkConfig>,
    collector_factory: Option<Arc<zfw_common::collector_factory::CollectorFactory>>,
    cancel: CancellationToken,
    incoming_addr: SocketAddr,
    guard: Option<Guard>,
    conn_guard: ConnectionGuard,
    conn_protect: Arc<ConnProtect>,
    conn_stats_manager: Arc<ConnStatsManager>,
    speed_rate_limitter: Option<Arc<SpeedRateLimitterPair>>,
    proxy_protocol_config: Option<Arc<ProxyProtocolConfig>>,
    allow_private_ip: bool,
    traffic_routing_ctx: Option<Arc<TrafficRoutingContext>>,
    mut outbound_ready: zfw_port_backend::OutboundReady,
) -> Result<()> {
    // Take the sender at the function entry so every early return (reject,
    // unwrap panic unwind, ?) sends exactly once via Drop. Spawned
    // `start_tcp_relay` takes ownership with `take()` (tx **and** dial-ok flag).
    // Perform traffic routing check for direct relay (only check source IP/port and protocol)
    // Returns the matched selector for server filtering (if any)
    let matched_selector: Option<shared_crate::app_message::OutboundSelector> = if let Some(
        ref routing_ctx,
    ) =
        traffic_routing_ctx
    {
        let (match_result, _) = routing_ctx.match_source_only(incoming_addr, Protocol::Tcp);
        match match_result {
            MatchedSelectorResult::Reject => {
                log::info!(
                    "TCP#{} connection from {:?} rejected by traffic routing (source-based rule)",
                    port,
                    incoming_addr,
                );
                outbound_ready.send(Err(anyhow::anyhow!(
                    "rejected by traffic routing (source-based rule)"
                )));
                return Ok(());
            }
            MatchedSelectorResult::Selector(selector) => {
                log::debug!(
                        "TCP#{} connection from {:?} matched selector with {} strategies (source-based rule)",
                        port,
                        incoming_addr,
                        selector.selector_chain.len()
                    );
                Some(selector)
            }
            MatchedSelectorResult::NoMatch => None,
        }
    } else {
        None
    };

    // Apply selector-based server filtering if we have a matched selector
    let filtered_server_selector =
        if let (Some(selector), Some(routing_ctx)) = (&matched_selector, &traffic_routing_ctx) {
            // Only applies to static server selectors
            if !server_selector.is_dyn_target() {
                let found_server = select_static_server_from_selector_strategies(
                    routing_ctx,
                    selector,
                    &server_selector,
                    |strategy_idx| {
                        log::debug!(
                            "TCP#{} strategy[{}] resolved to empty, trying next",
                            port,
                            strategy_idx
                        );
                    },
                    |strategy_idx| {
                        log::debug!(
                            "TCP#{} strategy[{}] endpoints have no available servers, trying next",
                            port,
                            strategy_idx
                        );
                    },
                )
                .map(|(server, strategy_idx)| {
                    log::info!(
                        "TCP#{} strategy[{}] selected server: {}",
                        port,
                        strategy_idx,
                        server.name
                    );
                    server
                });

                if found_server.is_none() {
                    log::warn!(
                        "TCP#{} all {} strategies failed, falling back to default selection",
                        port,
                        selector.selector_chain.len()
                    );
                }

                found_server
            } else {
                None
            }
        } else {
            None
        };

    let traffic_counters = ConnTrafficCounters::new();
    // 共享配额（#370）不在这里 tap：collector 报出的端口行已由
    // `stat_absorb::absorb_local_stat` 单点计入，再 tap 一次就是同一批字节 2×。
    let collector = collector_factory.unwrap().create_collector_group(
        Some(incoming_addr),
        smallvec![None],
        port,
        Some(traffic_counters.clone()),
        None,
        false,
    );
    // dynamic target don't use filters
    let filters = if server_selector.is_dyn_target() {
        None
    } else {
        net_config.filter_instances()
    };
    if let Some(filters) = filters {
        match client_stream {
            TcpStreamType::TcpStream(stream) => {
                let mut filtered_stream = TrafficFilter::new(stream);
                for filter in filters.iter() {
                    filtered_stream.add_filter(Arc::clone(filter));
                }
                tokio::spawn(print_size(
                    start_tcp_relay(
                        filtered_stream,
                        port,
                        port_key,
                        server_selector,
                        net_config,
                        collector,
                        cancel,
                        incoming_addr,
                        guard,
                        conn_guard,
                        conn_protect,
                        conn_stats_manager,
                        speed_rate_limitter,
                        proxy_protocol_config,
                        allow_private_ip,
                        filtered_server_selector,
                        Some(traffic_counters),
                        outbound_ready.take(),
                    ),
                    "start_tcp_relay_task_TcpStream",
                ));
            }
            TcpStreamType::AnyStream { stream, .. } => {
                let mut filtered_stream = TrafficFilter::new(stream);
                for filter in filters.iter() {
                    filtered_stream.add_filter(Arc::clone(filter));
                }
                tokio::spawn(print_size(
                    start_tcp_relay(
                        filtered_stream,
                        port,
                        port_key,
                        server_selector,
                        net_config,
                        collector,
                        cancel,
                        incoming_addr,
                        guard,
                        conn_guard,
                        conn_protect,
                        conn_stats_manager,
                        speed_rate_limitter,
                        proxy_protocol_config,
                        allow_private_ip,
                        filtered_server_selector,
                        Some(traffic_counters),
                        outbound_ready.take(),
                    ),
                    "start_tcp_relay_task_AnyStream",
                ));
            }
        };
    } else {
        match client_stream {
            TcpStreamType::TcpStream(stream) => {
                tokio::spawn(print_size(
                    start_tcp_relay(
                        stream,
                        port,
                        port_key,
                        server_selector,
                        net_config,
                        collector,
                        cancel,
                        incoming_addr,
                        guard,
                        conn_guard,
                        conn_protect,
                        conn_stats_manager,
                        speed_rate_limitter,
                        proxy_protocol_config,
                        allow_private_ip,
                        filtered_server_selector,
                        Some(traffic_counters),
                        outbound_ready.take(),
                    ),
                    "start_tcp_relay_task_TcpStream_nofilters",
                ));
            }
            TcpStreamType::AnyStream { stream, .. } => {
                tokio::spawn(print_size(
                    start_tcp_relay(
                        stream,
                        port,
                        port_key,
                        server_selector,
                        net_config,
                        collector,
                        cancel,
                        incoming_addr,
                        guard,
                        conn_guard,
                        conn_protect,
                        conn_stats_manager,
                        speed_rate_limitter,
                        proxy_protocol_config,
                        allow_private_ip,
                        filtered_server_selector,
                        Some(traffic_counters),
                        outbound_ready.take(),
                    ),
                    "start_tcp_relay_task_AnyStream_nofilters",
                ));
            }
        };
    };
    Ok(())
}

#[cfg(test)]
mod relay_tests {
    use super::*;
    use zfw_api::test_util::create_default_network_config;
    use zfw_common::test_util::create_test_collector_factory;
    use zfw_selection::test_util::ensure_global_process_shared;
    use zfw_api::protocol_types::TcpStreamType;
    use crate::server::types::ConnectionGuard;
    use shared_crate::server_provider::ServerSelector;
    use std::time::Duration;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::{TcpListener, TcpStream};

    const STEP: Duration = Duration::from_secs(5);

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn direct_relay_echoes_loopback() {
        ensure_global_process_shared();
        let echo = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let echo_addr = echo.local_addr().unwrap();
        let echo_task = tokio::spawn(async move {
            let (mut s, _) = echo.accept().await.unwrap();
            let mut buf = [0u8; 32];
            if let Ok(n) = s.read(&mut buf).await {
                if n > 0 {
                    let _ = s.write_all(&buf[..n]).await;
                }
            }
        });

        let pair = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let pair_addr = pair.local_addr().unwrap();
        let mut local = TcpStream::connect(pair_addr).await.unwrap();
        let (inbound, incoming) = pair.accept().await.unwrap();

        let factory = create_test_collector_factory();
        let cancel = CancellationToken::new();
        let selector = ServerSelector::Dynamic(
            private_tun::address::Address::Socket(echo_addr),
            format!("{echo_addr}").into_boxed_str(),
        );
        direct_or_socks5_relay(
            TcpStreamType::new_tcp_stream(inbound),
            incoming.port(),
            shared_crate::app_message::PortKey::Legacy(incoming.port()),
            selector,
            create_default_network_config(),
            Some(factory),
            cancel.clone(),
            incoming,
            None,
            ConnectionGuard::noop(),
            Arc::new(ConnProtect::new(
                tokio::sync::Semaphore::new(16),
                8,
                32,
            )),
            Arc::new(ConnStatsManager::new()),
            None,
            None,
            true,
            None,
            zfw_port_backend::OutboundReady::none(),
        )
        .expect("spawn relay");

        local.write_all(b"tcp-echo").await.unwrap();
        let mut got = [0u8; 8];
        tokio::time::timeout(STEP, local.read_exact(&mut got))
            .await
            .expect("echo timeout")
            .expect("echo read");
        assert_eq!(&got, b"tcp-echo");
        cancel.cancel();
        let _ = echo_task.await;
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn proxy_protocol_accept_cancel_unblocks() {
        ensure_global_process_shared();
        let echo = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let echo_addr = echo.local_addr().unwrap();
        let (accepted_tx, accepted_rx) = tokio::sync::oneshot::channel();
        let echo_task = tokio::spawn(async move {
            let (_s, _) = echo.accept().await.unwrap();
            let _ = accepted_tx.send(());
            std::future::pending::<()>().await
        });

        let pair = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let pair_addr = pair.local_addr().unwrap();
        let _local = TcpStream::connect(pair_addr).await.unwrap();
        let (inbound, incoming) = pair.accept().await.unwrap();

        let factory = create_test_collector_factory();
        let collector = factory.create_collector_group(
            Some(incoming),
            smallvec::smallvec![None],
            incoming.port(),
            None,
            None,
            false,
        );
        let cancel = CancellationToken::new();
        let selector = ServerSelector::Dynamic(
            private_tun::address::Address::Socket(echo_addr),
            format!("{echo_addr}").into_boxed_str(),
        );
        let pp = std::sync::Arc::new(ProxyProtocolConfig::new(true, false, None));
        let relay = tokio::spawn(start_tcp_relay(
            inbound,
            incoming.port(),
            shared_crate::app_message::PortKey::Legacy(incoming.port()),
            selector,
            create_default_network_config(),
            collector,
            cancel.clone(),
            incoming,
            None,
            ConnectionGuard::noop(),
            Arc::new(ConnProtect::new(
                tokio::sync::Semaphore::new(16),
                8,
                32,
            )),
            Arc::new(ConnStatsManager::new()),
            None,
            Some(pp),
            true,
            None,
            None,
            zfw_port_backend::OutboundReady::none(),
        ));

        tokio::time::timeout(STEP, accepted_rx)
            .await
            .expect("remote accept")
            .expect("accepted");
        cancel.cancel();
        let result = tokio::time::timeout(Duration::from_secs(1), relay)
            .await
            .expect("cancel during PROXY protocol must not wait for the 10s accept-read timeout")
            .expect("join");
        assert!(
            matches!(result, Err(RealyTcpError::ConnectCanceled)),
            "unexpected result: {result:?}"
        );
        echo_task.abort();
    }

    #[tokio::test]
    async fn outbound_ready_is_err_when_direct_dial_fails() {
        let pair = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let pair_addr = pair.local_addr().unwrap();
        let _local = TcpStream::connect(pair_addr).await.unwrap();
        let (inbound, incoming) = pair.accept().await.unwrap();
        let factory = create_test_collector_factory();
        let collector = factory.create_collector_group(
            Some(incoming),
            smallvec::smallvec![None],
            incoming.port(),
            None,
            None,
            false,
        );
        let cancel = CancellationToken::new();
        // Closed port: connect_one_addr fails.
        let selector = ServerSelector::Dynamic(
            private_tun::address::Address::Socket("127.0.0.1:1".parse().unwrap()),
            Box::<str>::from("127.0.0.1:1"),
        );
        let (tx, rx) = tokio::sync::oneshot::channel();
        let relay = tokio::spawn(start_tcp_relay(
            inbound,
            incoming.port(),
            shared_crate::app_message::PortKey::Legacy(incoming.port()),
            selector,
            create_default_network_config(),
            collector,
            cancel,
            incoming,
            None,
            ConnectionGuard::noop(),
            Arc::new(ConnProtect::new(tokio::sync::Semaphore::new(16), 8, 32)),
            Arc::new(ConnStatsManager::new()),
            None,
            None,
            true,
            None,
            None,
            zfw_port_backend::OutboundReady::new(Some(tx)),
        ));
        let sig = tokio::time::timeout(Duration::from_secs(3), rx)
            .await
            .expect("signal timed out")
            .expect("signal dropped");
        assert!(sig.is_err(), "dial fail must be Err, got {sig:?}");
        let _ = relay.await;
    }
}
