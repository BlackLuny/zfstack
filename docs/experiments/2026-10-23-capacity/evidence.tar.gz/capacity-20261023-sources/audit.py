"""Post-run identity audit. Run from the measured repository root."""
import hashlib
import json
from pathlib import Path

root = Path('qa/results/capacity-20261023')
plan = json.loads((root / 'plan.json').read_text())
errors = []

def check(ok, message):
    if not ok:
        errors.append(message)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for path, expected in plan['sources'].items():
    check(digest(Path(path)) == expected, f'source differs: {path}')
check(digest(Path('target/release/zfbench')) == plan['binary_sha256'], 'binary differs')
check(len(plan['rows']) == 56, 'frozen plan must have 56 attempts')
seen = set()
for row in plan['rows']:
    name = f"{row['index']:03d}-{row['case']}-{row['block']}-{row['position']}-{row['arm']}"
    p = root / name
    start = json.loads((p / 'start.json').read_text())
    end = json.loads((p / 'end.json').read_text())
    result = json.loads((p / 'stdout.json').read_text())
    seen.add(name)
    check(start['row'] == row, f'plan row differs: {name}')
    check(start['binary_sha256'] == plan['binary_sha256'] and end['binary_unchanged'], f'binary identity differs: {name}')
    env = dict(plan['arms'][row['arm']])
    if row['case'].startswith('isolate'):
        env.update(ZFBENCH_RR_RAW='1', ZFBENCH_RR_OPEN_HZ='25', ZFBENCH_RR_ARRIVALS=f'/work/{p}/arrivals.json')
    check(start['env'] == env, f'environment differs: {name}')
    argv = ['docker', 'exec', 'zfstack-capacity-20261023', 'env']
    argv += [f'{k}={v}' for k, v in env.items()]
    argv += ['timeout', '-k', '5', '150', 'python3', '/work/bench/tail69_exec.py',
             f'/work/{p}/resources.json', 'taskset', '-c', '0-3', '/work/target/release/zfbench']
    argv += plan['cases'][row['case']] + ['--label', name]
    # JSON canonicalization sorts the arm map; env command order is immaterial.
    actual = start['argv']
    prefix = actual[:4] == argv[:4]
    env_ok = set(actual[4:4+len(env)]) == set(argv[4:4+len(env)])
    check(prefix and env_ok and actual[4+len(env):] == argv[4+len(env):], f'command differs: {name}')
    check(result['label'] == name, f'result label differs: {name}')
    check(end['returncode'] == 0 and result['ok'], f'process failed: {name}')
actual_runs = {p.name for p in root.glob('[0-9][0-9][0-9]-*')}
check(actual_runs == seen, 'missing or extra run directory')
check(json.loads((root / 'complete.json').read_text())['attempts'] == 56, 'completion differs')
print(json.dumps(dict(ok=not errors, errors=errors, attempts=len(seen),
                     checked_source_files=len(plan['sources']), binary_sha256=plan['binary_sha256'],
                     plan_sha256=digest(root / 'plan.json')), indent=2))
raise SystemExit(bool(errors))
