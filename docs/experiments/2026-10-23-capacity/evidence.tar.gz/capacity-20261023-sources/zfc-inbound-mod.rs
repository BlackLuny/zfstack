//! WireGuard inbound pipeline (config + zfstack userspace + kernel-TUN).
//!
//! Mesh / port-owning instance stays in the bin (`protocol/inbound/wireguard/instance.rs`).

pub mod config;
pub mod common;
pub mod frag;
#[cfg(target_os = "linux")]
pub mod kernel_tun;
pub mod zfstack;

use std::net::SocketAddr;

/// 一条已被 netstack 后端（zfstack 或 kernel-TUN）accept 的入站 TCP 连接，统一形态。
///
/// 后端把各自的流类型（zfstack 的虚拟流或 kernel-TUN 的真实 `TcpStream`）
/// 装进 `AnyStream`，并附上**透明 exit** 语义下的目的地址与客户端
/// overlay 源地址，交给 [`instance`] 的统一 accept 消费循环（防火墙校验 + 出站分派）。
pub struct AcceptedConn {
    /// 已装箱的双向流（`AsyncRead+AsyncWrite+ClientStream`）。
    pub stream: private_tun::client_zfc::AnyStream,
    /// 连接的真实目的地址（= 代理 target，透明 exit 下即客户端原始 dst）。
    pub target: SocketAddr,
    /// 客户端在 overlay 内的源地址（10.x）。仅用于按 peer 反查公网 endpoint 做入站防火墙 + 日志。
    pub remote_overlay: SocketAddr,
}
