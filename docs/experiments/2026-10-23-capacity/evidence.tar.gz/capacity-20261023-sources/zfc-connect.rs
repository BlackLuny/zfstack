//! Remote connection with retry/fallback logic

use tokio::sync::AcquireError;

#[derive(thiserror::Error, Debug)]
pub enum RealyTcpError {
    #[error("socks5 connect failed")]
    Socks5ConnectFailed,
    #[error("socks5 connect timeout")]
    Socks5ConnectTimeout,
    #[error("socks5 handle failed: {0}")]
    Socks5HandleFailed(anyhow::Error),
    #[error("remote connect failed: {0}")]
    RemoteConnectFailed(#[from] std::io::Error),
    #[error("Connect canceled")]
    ConnectCanceled,
    #[error("get target info failed")]
    GetTargetInfoFailed(#[from] anyhow::Error),
    #[error("get semaphore failed")]
    GetSemaphoreFailed(#[from] AcquireError),
}


use anyhow::Result;
use log::{debug, error};
use shared_crate::server_provider::{ServerInfo, ServerSelector};
use private_tun::net_ns::NetNS;
use zfw_common::network_config::NetworkConfig;
use zfw_common::socks5_client;
use zfw_common::socks_backend::SocksBackend;
use futures::TryFutureExt;
use private_tun::address::Address;
use shared_crate::conn_protect::ConnProtect;
use shared_crate::constant::{TCP_CONNECT_TIMEOUT, TCP_FAST_CONNECT_TIMEOUT};
use shared_crate::rechecker::Checker;
use smallvec::SmallVec;
use std::future::Future;
use std::net::{IpAddr, SocketAddr};
use std::sync::Arc;
use std::time::Duration;
use tokio::net::{TcpSocket, TcpStream};
use tokio::sync::SemaphorePermit;
use private_tun::conn_outcome::diagnostics::{self, Phase};
use private_tun::conn_outcome::{ConnRow, FailKind, Outcome, OutcomeGuard};

/// #686 拨号用途：只有逻辑目标拨号计入 Target/TCP 连接结果。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DialPurpose {
    /// 连用户配置的业务目标。
    Target,
    /// 连中转节点、出口代理控制连接等内部链路：不计连接结果。
    Internal,
}

pub fn connect_to_remote<'a>(
    server_selector: &'a ServerSelector,
    socks5_server: Option<&'a SocksBackend>,
    net_config: Option<&'a NetworkConfig>,
    conn_protect: Option<&'a ConnProtect>,
    allow_private_ip: bool,
    purpose: DialPurpose,
) -> impl Future<Output = Result<TcpStream, RealyTcpError>> + 'a {
    connect_to_remote_for(
        server_selector,
        socks5_server,
        net_config,
        conn_protect,
        allow_private_ip,
        None,
        purpose,
    )
    .map_ok(|(stream, _)| stream)
}

/// [`connect_to_remote`] for one member of a caller-owned multi-address race
/// (Chain direct hop, #804): every member already dials its own tuple, so a
/// sole address here must not add same-address backups on top (N → 3N sockets).
pub fn connect_to_remote_in_race<'a>(
    server_selector: &'a ServerSelector,
    net_config: Option<&'a NetworkConfig>,
    conn_protect: Option<&'a ConnProtect>,
    allow_private_ip: bool,
    purpose: DialPurpose,
) -> impl Future<Output = Result<TcpStream, RealyTcpError>> + 'a {
    connect_to_remote_with(
        server_selector,
        None,
        net_config,
        conn_protect,
        allow_private_ip,
        None,
        purpose,
        false,
    )
    .map_ok(|(stream, _)| stream)
}

/// Connect to remote with optional preferred server.
/// If `preferred_server` is provided, it will be tried first before falling back to
/// normal server selection logic. This is used for traffic routing rule-based server selection.
///
/// Every worker dial to a real target funnels through here, so the target
/// receive-buffer cap (#684, `ZFW_TCP_TARGET_RCVBUF_KB`, off by default) is applied
/// once on the returned stream — the same function the Hammer / TOT landings use.
pub fn connect_to_remote_with_preference<'a>(
    server_selector: &'a ServerSelector,
    socks5_server: Option<&'a SocksBackend>,
    net_config: Option<&'a NetworkConfig>,
    conn_protect: Option<&'a ConnProtect>,
    allow_private_ip: bool,
    preferred_server: Option<Arc<ServerInfo>>,
) -> impl Future<Output = Result<(TcpStream, Address), RealyTcpError>> + 'a {
    connect_to_remote_for(
        server_selector,
        socks5_server,
        net_config,
        conn_protect,
        allow_private_ip,
        preferred_server,
        DialPurpose::Target,
    )
}

fn connect_to_remote_for<'a>(
    server_selector: &'a ServerSelector,
    socks5_server: Option<&'a SocksBackend>,
    net_config: Option<&'a NetworkConfig>,
    conn_protect: Option<&'a ConnProtect>,
    allow_private_ip: bool,
    preferred_server: Option<Arc<ServerInfo>>,
    purpose: DialPurpose,
) -> impl Future<Output = Result<(TcpStream, Address), RealyTcpError>> + 'a {
    connect_to_remote_with(
        server_selector,
        socks5_server,
        net_config,
        conn_protect,
        allow_private_ip,
        preferred_server,
        purpose,
        true,
    )
}

async fn connect_to_remote_with(
    server_selector: &ServerSelector,
    socks5_server: Option<&SocksBackend>,
    net_config: Option<&NetworkConfig>,
    conn_protect: Option<&ConnProtect>,
    allow_private_ip: bool,
    preferred_server: Option<Arc<ServerInfo>>,
    purpose: DialPurpose,
    hedge: bool,
) -> Result<(TcpStream, Address), RealyTcpError> {
    diagnostics::scope(async {
        // 调用方在拨号途中丢弃本 future（`select!` 取消分支）时由 guard 记 Cancelled。
        let mut guard = (purpose == DialPurpose::Target).then(|| OutcomeGuard::cancel_on_drop(ConnRow::TargetTcp));
        let mut observed = None;
        let conn = connect_to_remote_inner(
            server_selector,
            socks5_server,
            net_config,
            None,
            conn_protect,
            allow_private_ip,
            preferred_server,
            hedge,
            &mut observed,
        )
        .await;
        if let Err(e) = &conn { diagnostics::message(e); }
        if let Some(g) = guard.as_mut() {
            g.finish(target_tcp_outcome(&conn, observed));
        }
        if let Ok((stream, _)) = &conn {
            private_tun::tune_target_socket_rcvbuf(stream);
        }
        conn
    }).await
}

/// #686 Target/TCP 连接结果：一次逻辑目标拨号（内部换 server 重试算一次）记一次。
///
/// 分类取**最后一次实际尝试**在错误点记下的观测分类（`observed`，旁路状态，不改业务
/// 返回值）；选择器从未给出任何可尝试目标 → `NoCandidate`。
fn target_tcp_outcome<T>(conn: &Result<T, RealyTcpError>, observed: Option<FailKind>) -> Outcome {
    match conn {
        Ok(_) => Outcome::Ok,
        Err(RealyTcpError::ConnectCanceled) => Outcome::Cancelled,
        Err(e) => Outcome::Fail(observed.unwrap_or_else(|| realy_error_kind(e))),
    }
}

fn realy_error_kind(e: &RealyTcpError) -> FailKind {
    match e {
        RealyTcpError::Socks5ConnectFailed => FailKind::Other,
        RealyTcpError::Socks5ConnectTimeout => FailKind::Timeout,
        RealyTcpError::Socks5HandleFailed(e) => {
            shared_crate::cached_connect::classify_target_anyhow(e, FailKind::Handshake)
        }
        RealyTcpError::RemoteConnectFailed(e) => {
            shared_crate::cached_connect::classify_target_io(e)
        }
        RealyTcpError::ConnectCanceled => FailKind::Other,
        // 只有「选择器从未给出目标」会在没有任何观测分类的情况下走到这里。
        RealyTcpError::GetTargetInfoFailed(_) => FailKind::NoCandidate,
        RealyTcpError::GetSemaphoreFailed(_) => FailKind::Resource,
    }
}

/// **netns-only** dial: sockets are created inside `net_ns`, and nothing else
/// from a `NetworkConfig` is applied — no `out_ip` bind, no outbound firewall,
/// no IP-version strategy, no config-provided SOCKS backend.
///
/// This is the API the NAT-traversal server control connection needs (#415):
/// it used to get netns by wrapping `connect_to_remote(.., net_config=None, ..)`
/// in `NetNS::run_async`, which held `setns` across the whole DNS + connect
/// await. Passing `Some(&net_config)` instead is **not** a substitute — it would
/// silently start applying out_ip / filter / strategy and change which servers
/// are reachable.
pub async fn connect_to_remote_in_netns(
    server_selector: &ServerSelector,
    socks5_server: Option<&SocksBackend>,
    net_ns: &NetNS,
    conn_protect: Option<&ConnProtect>,
    allow_private_ip: bool,
) -> Result<TcpStream, RealyTcpError> {
    // 控制连接（NAT 穿透服务端），不是目标拨号：不计连接结果。
    connect_to_remote_inner(
        server_selector,
        socks5_server,
        None,
        Some(net_ns),
        conn_protect,
        allow_private_ip,
        None,
        true,
        &mut None,
    )
    .await
    .map(|(stream, _)| stream)
}

/// Shared body. `net_config` carries dial **policy** (out_ip / filter / strategy
/// / netns); `dial_ns` overrides only the namespace the sockets are created in
/// and is used by [`connect_to_remote_in_netns`] when there is no policy at all.
async fn connect_to_remote_inner(
    server_selector: &ServerSelector,
    socks5_server: Option<&SocksBackend>,
    net_config: Option<&NetworkConfig>,
    dial_ns: Option<&NetNS>,
    conn_protect: Option<&ConnProtect>,
    allow_private_ip: bool,
    mut preferred_server: Option<Arc<ServerInfo>>,
    // #804: same-address hedging for a sole candidate; false when the caller
    // already races several addresses.
    hedge: bool,
    // #686 旁路：最后一次实际尝试在错误点的观测分类（只写不读，不影响控制流）。
    observed: &mut Option<FailKind>,
) -> Result<(TcpStream, Address), RealyTcpError> {
    // Socket-creation namespace: an explicit `dial_ns` wins, else the one the
    // policy config carries. Both are `None` for a plain no-config dial.
    let dial_ns: Option<&NetNS> = dial_ns.or_else(|| net_config.map(|nc| nc.net_ns()));
    let dns_cache = crate::process_shared::get_process_shared_info().get_dns_cache();
    let mut black_server_list = SmallVec::<[Arc<ServerInfo>; 3]>::new();
    let mut sem_guard: Option<SemaphorePermit> = None;
    let mut last_err: Option<RealyTcpError> = None;
    for i in 0..3 {
        // First iteration takes preferred if present; later retries fall back to selector.
        let target = if let Some(preferred) = preferred_server.take() {
            preferred
        } else {
            match server_selector.get_target_info(None, Some(black_server_list.as_slice())) {
                Some(t) => t,
                None => {
                    last_err = Some(RealyTcpError::GetTargetInfoFailed(anyhow::anyhow!(
                        "no floor-eligible server"
                    )));
                    continue;
                }
            }
        };
        diagnostics::target(&target.target);
        diagnostics::phase(Phase::Dns);
        let target_port = target.port();

        // Resolve target to preferred + fallback address groups
        let (preferred_addrs, fallback_addrs) =
            match resolve_server_target_addrs(&target, allow_private_ip, net_config).await {
                Ok(addrs) => addrs,
                Err(e) => {
                    match &e {
                        RealyTcpError::GetTargetInfoFailed(inner) => diagnostics::error(Phase::Dns, format_args!("{inner:#}")),
                        other => diagnostics::error(Phase::Dns, other),
                    }
                    *observed = Some(match &e {
                        RealyTcpError::GetTargetInfoFailed(inner) => {
                            shared_crate::cached_connect::classify_target_anyhow(inner, FailKind::Dns)
                        }
                        other => realy_error_kind(other),
                    });
                    last_err = Some(e);
                    if i == 0 {
                        if let Some(e) = last_err.as_ref() {
                            error!(
                                "resolve target addr failed: {target} error: {e} retry after 50ms"
                            );
                        }
                        if let Address::Domain(domain, _port) = &target.target {
                            dns_cache.clear_cache(domain.as_ref());
                        }
                        server_selector.recheck().await;
                        // #268/#272：日志一直写「retry after 50ms」，但实际没有任何等待——
                        // 失败洪峰时每条连接都会立刻 recheck + 重试，放大探测风暴。
                        tokio::time::sleep(Duration::from_millis(50)).await;
                    }
                    black_server_list.push(target);
                    let _ = sem_guard.take();
                    sem_guard = if let Some(conn_protect) = conn_protect.as_ref() {
                        conn_protect
                            .acquire_and_wait_for_conn()
                            .await
                            .map_err(RealyTcpError::GetSemaphoreFailed)?
                    } else {
                        None
                    };
                    continue;
                }
            };

        diagnostics::resolved(preferred_addrs.iter().chain(&fallback_addrs).copied());
        diagnostics::phase(Phase::Policy);
        // Outbound FW: filter **each** candidate before the connect race
        // (S5 / P1-3). Rejected IPs must never enter select_ok racing.
        // Domain targets pass `Some(host)` so DomainSuffix/Keyword rules apply;
        // filter is bound to the firewall's lane at construction.
        let domain_hint: Option<&str> = match &target.target {
            Address::Domain(h, _) => Some(h.as_ref()),
            _ => None,
        };
        let outbound_filter = net_config.and_then(|nc| nc.outbound_filter());
        let preferred_addrs =
            filter_outbound_connect_candidates(preferred_addrs, outbound_filter, domain_hint);
        let fallback_addrs =
            filter_outbound_connect_candidates(fallback_addrs, outbound_filter, domain_hint);

        // Build ordered address groups: try preferred first, then fallback.
        // Keep empty preferred slot so fallback-only still works for both SOCKS
        // and direct (pick first non-empty group's first addr for SOCKS).
        let mut addr_groups = SmallVec::<[Vec<SocketAddr>; 2]>::new();
        addr_groups.push(preferred_addrs);
        if !fallback_addrs.is_empty() {
            addr_groups.push(fallback_addrs);
        }

        // Unified no-candidate check (S5 P1-3 / re-review-2): FW may empty both
        // groups. Direct already handled this; SOCKS used to index [0][0] and
        // panic (release panic=abort kills the worker). Fail-closed before either branch.
        let first_candidate = addr_groups.iter().flatten().next().copied();
        let Some(first_candidate) = first_candidate else {
            *observed = Some(FailKind::Policy);
            last_err = Some(RealyTcpError::GetTargetInfoFailed(anyhow::anyhow!(
                "no addresses to connect after outbound filter"
            )));
            black_server_list.push(target);
            continue;
        };

        if let Some(SocksBackend {
            auth,
            socks5_server,
        }) = socks5_server.as_deref()
        {
            // SOCKS5 CONNECT destination: first non-empty group's first addr
            // (preferred if any remain; else fallback). Never index empty groups.
            // #686：SOCKS 分支的错误直接返回，分类由返回的错误本身决定。
            *observed = None;
            let target_addr = first_candidate;
            diagnostics::phase(Phase::Socket);
            let sock = make_socket_in_netns(dial_ns, *socks5_server, None)
                .map_err(|e| { diagnostics::error(Phase::Socket, e); RealyTcpError::Socks5ConnectFailed })?;
            diagnostics::attempt(*socks5_server);
            diagnostics::phase(Phase::ProxyConnect);
            let mut stream = tokio::time::timeout(
                Duration::from_secs(TCP_CONNECT_TIMEOUT),
                connect_with(sock, *socks5_server),
            )
            .await
            .map_err(|e| { diagnostics::message(e); RealyTcpError::Socks5ConnectTimeout })?
            .map_err(|e| { diagnostics::error(Phase::ProxyConnect, e); RealyTcpError::Socks5ConnectFailed })?;
            let target_addr = Address::Socket(SocketAddr::new(target_addr.ip(), target_port));
            diagnostics::phase(Phase::ProxyHandshake);
            let addr = tokio::time::timeout(
                Duration::from_secs(TCP_CONNECT_TIMEOUT),
                socks5_client::connect(&mut stream, &target_addr, auth.as_ref()),
            )
            .await
            .map_err(|e| { diagnostics::message(e); RealyTcpError::Socks5ConnectTimeout })?
            .map_err(|e| { diagnostics::error(Phase::ProxyHandshake, &e); RealyTcpError::Socks5HandleFailed(e) })?;
            debug!("socks5 connect success: {addr:?}, target: {target}, port: {target_port}");
            return Ok((stream, target.target.clone()));
        } else {
            // Direct connection: try address groups sequentially (preferred first, then fallback)
            let connect_timeout = Duration::from_secs(TCP_FAST_CONNECT_TIMEOUT * (i + 1));

            let total_addrs: usize = addr_groups.iter().map(|g| g.len()).sum();
            log::trace!(
                "attempting connection to target: {target} with {} addresses in {} group(s)",
                total_addrs,
                addr_groups.len()
            );

            let out_ip = net_config.and_then(|nc| nc.out_ip_ref()).copied();

            // Try each address group sequentially; within each group, race in parallel.
            // Sockets are built per group inside netns (sync), connect stays outside
            // the guard. Fallback sockets are only created after the preferred group
            // has failed and released its fds, so peak fd count stays |group| (same
            // as the pre-batch per-address connect). 只有 setns 本身失败才让整轮
            // 失败；单个候选建 socket 失败（EMFILE/该 family 不可用）只淘汰该候选。
            for group_addrs in addr_groups.iter() {
                diagnostics::phase(Phase::Socket);
                let group_socks = match make_group_sockets(dial_ns, group_addrs, out_ip) {
                    Ok(s) => s,
                    Err(e) => {
                        diagnostics::error(Phase::Socket, &e);
                        *observed = Some(shared_crate::cached_connect::classify_target_io(&e));
                        last_err = Some(RealyTcpError::RemoteConnectFailed(e));
                        break;
                    }
                };
                let mut ready: Vec<(SocketAddr, TcpSocket)> =
                    Vec::with_capacity(group_socks.len());
                for (addr, res) in group_socks {
                    match res {
                        Ok(sock) => ready.push((addr, sock)),
                        Err(e) => {
                            log::trace!("make_socket for {addr} failed, skipping candidate: {e}");
                            diagnostics::error(Phase::Socket, &e);
                            *observed = Some(shared_crate::cached_connect::classify_target_io(&e));
                            last_err = Some(RealyTcpError::RemoteConnectFailed(e));
                        }
                    }
                }
                let group = ready;
                if group.is_empty() {
                    continue;
                }

                let stream_result = if group.len() == 1 {
                    let (target_addr, sock) = group.into_iter().next().unwrap();
                    if hedge {
                        tokio::time::timeout(
                            connect_timeout,
                            connect_hedged(sock, target_addr, dial_ns, out_ip, connect_timeout),
                        )
                        .await
                    } else {
                        tokio::time::timeout(connect_timeout, connect_one_addr(sock, target_addr)).await
                    }
                } else {
                    let connect_futures: Vec<_> = group
                        .into_iter()
                        .map(|(target_addr, sock)| Box::pin(connect_one_addr(sock, target_addr)))
                        .collect();

                    tokio::time::timeout(connect_timeout, async {
                        match futures::future::select_ok(connect_futures).await {
                            Ok((stream, remaining)) => {
                                log::trace!(
                                    "connect success, canceling {} remaining connection attempts",
                                    remaining.len()
                                );
                                drop(remaining);
                                Ok(stream)
                            }
                            Err(e) => Err(e),
                        }
                    })
                    .await
                };

                match stream_result {
                    Ok(Ok(stream)) => {
                        if let Ok(peer_addr) = stream.peer_addr() {
                            log::trace!("connect to target: {target} success, established connection to {peer_addr}");
                        } else {
                            log::trace!("connect to target: {target} success");
                        }
                        return Ok((stream, target.target.clone()));
                    }
                    Ok(Err(e)) => {
                        log::trace!(
                            "address group failed for target: {target}, trying next group: {e}"
                        );
                        diagnostics::error(Phase::Connect, &e);
                        *observed = Some(shared_crate::cached_connect::classify_target_io(&e));
                        last_err = Some(RealyTcpError::RemoteConnectFailed(e));
                    }
                    Err(_) => {
                        log::trace!(
                            "address group timed out for target: {target}, trying next group"
                        );
                        diagnostics::error(Phase::Connect, format_args!("connect timed out after {} ms", connect_timeout.as_millis()));
                        *observed = Some(FailKind::Timeout);
                        last_err = Some(RealyTcpError::RemoteConnectFailed(std::io::Error::new(
                            std::io::ErrorKind::TimedOut,
                            "connect timeout",
                        )));
                    }
                }
            }

            // All groups failed for this server
            if i == 0 {
                if let Some(e) = last_err.as_ref() {
                    // First-attempt connect failures (ENETUNREACH / refused / timeout)
                    // are common on multi-IP race and retry immediately — not ERROR.
                    log::debug!("connect to target: {target} failed: {e} retry after 50ms");
                }
                if let Address::Domain(domain, _port) = &target.target {
                    dns_cache.clear_cache(domain.as_ref());
                }
                server_selector.recheck().await;
                // #268/#272：同上，补上日志承诺的 50ms 退避（原来是立即重试）。
                tokio::time::sleep(Duration::from_millis(50)).await;
            }
        }

        black_server_list.push(target);
        let _ = sem_guard.take();
        sem_guard = if let Some(conn_protect) = conn_protect.as_ref() {
            conn_protect
                .acquire_and_wait_for_conn()
                .await
                .map_err(RealyTcpError::GetSemaphoreFailed)?
        } else {
            None
        };
    }
    if let Some(err) = last_err {
        Err(err)
    } else {
        Err(RealyTcpError::RemoteConnectFailed(std::io::Error::new(
            std::io::ErrorKind::Other,
            "connect to target failed",
        )))
    }
}

/// Drop candidates rejected by the per-worker outbound filter **before** connect race.
/// Fail-closed invariant (S5 P1-3): a rejected SocketAddr never reaches `connect_with`.
fn filter_outbound_connect_candidates(
    addrs: Vec<SocketAddr>,
    filter: Option<&private_tun::client::OutboundFilter>,
    domain_hint: Option<&str>,
) -> Vec<SocketAddr> {
    let Some(f) = filter else {
        return addrs;
    };
    addrs
        .into_iter()
        .filter(|sa| match f(sa, domain_hint) {
            Ok(()) => true,
            Err(rej) => {
                log::debug!(
                    "outbound FW rejected connect candidate {sa} (domain={domain_hint:?}): {rej}"
                );
                false
            }
        })
        .collect()
}

/// Test spy: every SocketAddr that enters the connect race (post-FW filter).
#[cfg(any(test, feature = "test-util"))]
static CONNECT_CANDIDATE_SPY: std::sync::Mutex<
    Option<std::sync::Arc<std::sync::Mutex<Vec<SocketAddr>>>>,
> = std::sync::Mutex::new(None);

/// Install (or clear with `None`) the connect-candidate spy for production-path tests.
#[cfg(any(test, feature = "test-util"))]
pub fn set_connect_candidate_spy(
    spy: Option<std::sync::Arc<std::sync::Mutex<Vec<SocketAddr>>>>,
) {
    *CONNECT_CANDIDATE_SPY.lock().unwrap() = spy;
}

#[cfg(any(test, feature = "test-util"))]
fn record_connect_candidate(addr: SocketAddr) {
    if let Some(spy) = CONNECT_CANDIDATE_SPY.lock().unwrap().as_ref() {
        spy.lock().unwrap().push(addr);
    }
}

/// Create a TCP socket in the current thread's netns (sync; no runtime).
/// Family follows `target_addr`. `out_ip` is bound only when families match;
/// mismatch / no `out_ip` creates an unbound socket of the target family
/// (same as `TcpStream::connect(SocketAddr)`).
pub fn make_socket(
    target_addr: SocketAddr,
    out_ip: Option<IpAddr>,
) -> std::io::Result<TcpSocket> {
    match out_ip {
        Some(IpAddr::V4(v4)) if target_addr.ip().is_ipv4() => {
            let socket = TcpSocket::new_v4()?;
            socket.bind((v4, 0).into())?;
            Ok(socket)
        }
        Some(IpAddr::V6(v6)) if target_addr.ip().is_ipv6() => {
            let socket = TcpSocket::new_v6()?;
            socket.bind((v6, 0).into())?;
            Ok(socket)
        }
        _ => {
            if target_addr.ip().is_ipv4() {
                TcpSocket::new_v4()
            } else {
                TcpSocket::new_v6()
            }
        }
    }
}

/// Connect an already-created socket. Must run **outside** a netns guard.
pub async fn connect_with(sock: TcpSocket, addr: SocketAddr) -> std::io::Result<TcpStream> {
    sock.connect(addr).await
}

#[cfg(test)]
type InjectedNetnsErrorFn = fn(&str) -> std::io::Error;

#[cfg(test)]
struct InjectedNetnsState {
    target_ns: &'static str,
    make_err: InjectedNetnsErrorFn,
    hits: std::sync::Arc<std::sync::atomic::AtomicUsize>,
}

#[cfg(test)]
static INJECTED_NETNS_ERROR: std::sync::Mutex<Option<InjectedNetnsState>> =
    std::sync::Mutex::new(None);

#[cfg(test)]
struct NetnsInjectGuard {
    hits: std::sync::Arc<std::sync::atomic::AtomicUsize>,
}

#[cfg(test)]
impl NetnsInjectGuard {
    fn install(target_ns: &'static str, make_err: InjectedNetnsErrorFn) -> Self {
        let hits = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
        *INJECTED_NETNS_ERROR.lock().unwrap() = Some(InjectedNetnsState {
            target_ns,
            make_err,
            hits: std::sync::Arc::clone(&hits),
        });
        Self { hits }
    }

    fn hits(&self) -> usize {
        self.hits.load(std::sync::atomic::Ordering::SeqCst)
    }
}

#[cfg(test)]
impl Drop for NetnsInjectGuard {
    fn drop(&mut self) {
        if let Ok(mut slot) = INJECTED_NETNS_ERROR.lock() {
            *slot = None;
        }
    }
}

fn flatten_try_run<T>(
    net_ns: Option<&NetNS>,
    f: impl FnOnce() -> std::io::Result<T>,
) -> std::io::Result<T> {
    #[cfg(test)]
    if let Some(name) = net_ns.and_then(|ns| ns.name()) {
        if let Some((make_err, hits)) = INJECTED_NETNS_ERROR.lock().unwrap().as_ref().and_then(|s| {
            (s.target_ns == name.as_ref()).then(|| (s.make_err, std::sync::Arc::clone(&s.hits)))
        }) {
            hits.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            return Err(make_err(&name));
        }
    }
    match net_ns {
        Some(ns) => match ns.try_run(f) {
            Ok(inner) => inner,
            Err(e) => Err(e),
        },
        None => f(),
    }
}

fn make_socket_in_netns(
    net_ns: Option<&NetNS>,
    addr: SocketAddr,
    out_ip: Option<IpAddr>,
) -> std::io::Result<TcpSocket> {
    flatten_try_run(net_ns, || make_socket(addr, out_ip))
}

/// Build one address group's sockets under a single netns switch.
/// Outer `Err` = the netns switch itself failed (whole round unusable). Inner
/// per-candidate `Err` = that socket could not be created; caller skips it.
fn make_group_sockets(
    net_ns: Option<&NetNS>,
    group: &[SocketAddr],
    out_ip: Option<IpAddr>,
) -> std::io::Result<Vec<(SocketAddr, std::io::Result<TcpSocket>)>> {
    flatten_try_run(net_ns, || {
        Ok(group
            .iter()
            .copied()
            .map(|addr| (addr, make_socket(addr, out_ip)))
            .collect())
    })
}

async fn connect_one_addr(sock: TcpSocket, target_addr: SocketAddr) -> std::io::Result<TcpStream> {
    diagnostics::attempt(target_addr);
    #[cfg(any(test, feature = "test-util"))]
    record_connect_candidate(target_addr);
    connect_with(sock, target_addr).await
}

/// #804: a sole candidate also dials new sockets (new source ports) at ~1s/2s
/// while the first handshake is still pending, sharing `budget`. A SYN-ACK
/// lost on a per-tuple bad return path otherwise retransmits on the same tuple
/// until the timeout. Backups are created like the first (netns, `out_ip` with
/// port 0); the first success wins and the rest are dropped. Multi-address
/// groups already race distinct tuples and stay unchanged. `deadline` is the
/// caller's outer timeout, which must wrap this call: the race runs one hedge
/// delay longer and never resolves on its own budget, so exhaustion is always
/// reported by that outer timeout.
async fn connect_hedged(
    sock: TcpSocket,
    target_addr: SocketAddr,
    net_ns: Option<&NetNS>,
    out_ip: Option<IpAddr>,
    deadline: Duration,
) -> std::io::Result<TcpStream> {
    use private_tun::connect_hedge;
    let mut first = Some(sock);
    let raced = connect_hedge::race(
        |index| match first.take() {
            Some(sock) => futures::future::Either::Left(connect_one_addr(sock, target_addr)),
            None => {
                debug!("connect hedge: target={target_addr} attempt={}", index + 1);
                let sock = make_socket_in_netns(net_ns, target_addr, out_ip);
                futures::future::Either::Right(async move { connect_with(sock?, target_addr).await })
            }
        },
        connect_hedge::HEDGE_DELAY,
        deadline + connect_hedge::HEDGE_DELAY,
        connect_hedge::MAX_ATTEMPTS,
    )
    .await;
    let (stream, winner) = connect_hedge::defer_budget_to_outer(raced).await?;
    if winner > 0 {
        pt_core::relay_outcome::recovered();
        debug!("connect rescued: target={target_addr} winner={}", winner + 1);
    }
    Ok(stream)
}

/// Pure helper for unit tests: apply outbound filter to candidates (same as production).
#[cfg(any(test, feature = "test-util"))]
pub fn filter_connect_candidates_for_test(
    addrs: Vec<SocketAddr>,
    filter: Option<&private_tun::client::OutboundFilter>,
    domain_hint: Option<&str>,
) -> Vec<SocketAddr> {
    filter_outbound_connect_candidates(addrs, filter, domain_hint)
}

/// Shared function to resolve and validate address with private IP filtering.
/// This function is used by both TCP and UDP to avoid code duplication.
///
/// # Arguments
/// * `address` - The address to resolve and validate
/// * `allow_private_ip` - Whether to allow private IP addresses
///
/// # Returns
/// * `Ok(SocketAddr)` - The resolved and validated socket address
/// * `Err(anyhow::Error)` - If resolution fails or private IP is not allowed
pub async fn resolve_and_validate_address<F>(
    address: &Address,
    allow_private_ip: bool,
    strategy_fn: F,
    net_config: Option<&NetworkConfig>,
) -> anyhow::Result<SocketAddr>
where
    F: FnOnce() -> zfw_common::net_utils::IpStrategy,
{
    zfw_common::net_utils::resolve_to_socket_addr(address, strategy_fn, net_config, allow_private_ip)
        .await
}

/// Resolve server target to all possible socket addresses
/// Returns a list of SocketAddr to attempt connecting in parallel
/// When out_ip is specified, only addresses matching the outbound IP family are returned
/// Resolve server target addresses, split into preferred and fallback groups based on IP strategy.
/// When strategy is DonCare, all addresses go into preferred (raced in parallel as before).
/// When strategy is Ipv4First/Ipv6First, preferred family addresses are tried first;
/// fallback addresses are only used if all preferred ones fail.
async fn resolve_server_target_addrs(
    target: &ServerInfo,
    allow_private_ip: bool,
    net_config: Option<&NetworkConfig>,
) -> Result<(Vec<SocketAddr>, Vec<SocketAddr>), RealyTcpError> {
    let candidates =
        zfw_common::net_utils::resolve_to_socket_addrs(&target.target, net_config, allow_private_ip)
            .await
            .map_err(RealyTcpError::GetTargetInfoFailed)?;

    let strategy = net_config
        .map(|nc| nc.ip_version_priority())
        .unwrap_or(zfw_common::net_utils::IpStrategy::DonCare);

    match strategy {
        zfw_common::net_utils::IpStrategy::Ipv4First => {
            let (preferred, fallback): (Vec<_>, Vec<_>) =
                candidates.into_iter().partition(|a| a.is_ipv4());
            if preferred.is_empty() {
                Ok((fallback, vec![]))
            } else {
                Ok((preferred, fallback))
            }
        }
        zfw_common::net_utils::IpStrategy::Ipv6First => {
            let (preferred, fallback): (Vec<_>, Vec<_>) =
                candidates.into_iter().partition(|a| a.is_ipv6());
            if preferred.is_empty() {
                Ok((fallback, vec![]))
            } else {
                Ok((preferred, fallback))
            }
        }
        zfw_common::net_utils::IpStrategy::DonCare => Ok((candidates, vec![])),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::{Ipv4Addr, Ipv6Addr};

    #[test]
    fn make_socket_v4_no_out_ip_is_v4() {
        let addr = SocketAddr::from((Ipv4Addr::new(8, 8, 8, 8), 53));
        let sock = make_socket(addr, None).expect("new_v4");
        sock.bind(SocketAddr::from((Ipv4Addr::UNSPECIFIED, 0)))
            .expect("bind v4 unspecified");
        assert!(sock.local_addr().unwrap().is_ipv4());
    }

    #[test]
    fn make_socket_v4_binds_out_ip() {
        let addr = SocketAddr::from((Ipv4Addr::new(8, 8, 8, 8), 53));
        let sock = make_socket(addr, Some(IpAddr::V4(Ipv4Addr::LOCALHOST))).expect("bind 127.0.0.1");
        assert_eq!(sock.local_addr().unwrap().ip(), IpAddr::V4(Ipv4Addr::LOCALHOST));
    }

    #[test]
    fn make_socket_v4_target_ignores_v6_out_ip() {
        let addr = SocketAddr::from((Ipv4Addr::new(8, 8, 8, 8), 53));
        let sock = make_socket(addr, Some(IpAddr::V6(Ipv6Addr::LOCALHOST))).expect("new_v4");
        sock.bind(SocketAddr::from((Ipv4Addr::UNSPECIFIED, 0)))
            .expect("mismatch must leave socket unbound so v4 bind works");
        assert!(sock.local_addr().unwrap().is_ipv4());
    }

    #[test]
    fn make_socket_v6_no_out_ip_is_v6() {
        let addr = SocketAddr::from((Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1), 53));
        let sock = match make_socket(addr, None) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("skip ipv6 new_v6: {e}");
                return;
            }
        };
        if let Err(e) = sock.bind(SocketAddr::from((Ipv6Addr::UNSPECIFIED, 0))) {
            eprintln!("skip ipv6 bind: {e}");
            return;
        }
        assert!(sock.local_addr().unwrap().is_ipv6());
    }

    #[test]
    fn make_socket_v6_binds_out_ip() {
        let addr = SocketAddr::from((Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1), 53));
        let sock = match make_socket(addr, Some(IpAddr::V6(Ipv6Addr::LOCALHOST))) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("skip ipv6 bind ::1: {e}");
                return;
            }
        };
        assert_eq!(sock.local_addr().unwrap().ip(), IpAddr::V6(Ipv6Addr::LOCALHOST));
    }

    #[test]
    fn make_socket_v6_target_ignores_v4_out_ip() {
        let addr = SocketAddr::from((Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1), 53));
        let sock = match make_socket(addr, Some(IpAddr::V4(Ipv4Addr::LOCALHOST))) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("skip ipv6 new_v6: {e}");
                return;
            }
        };
        if let Err(e) = sock.bind(SocketAddr::from((Ipv6Addr::UNSPECIFIED, 0))) {
            eprintln!("skip ipv6 bind: {e}");
            return;
        }
        assert!(sock.local_addr().unwrap().is_ipv6());
    }

    /// #804: a fast sole-candidate connect returns directly; when every SYN is
    /// dropped only the outer timeout ends the dial, even past the race budget.
    #[cfg(target_os = "linux")]
    #[tokio::test]
    async fn sole_candidate_hedge_succeeds_fast_and_respects_budget() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let sock = make_socket(addr, None).unwrap();
        let stream = connect_hedged(sock, addr, None, None, Duration::from_secs(3)).await.unwrap();
        assert_eq!(listener.accept().await.unwrap().1, stream.local_addr().unwrap());

        // A full accept queue makes Linux drop new SYNs: every handshake stays pending.
        let socket = TcpSocket::new_v4().unwrap();
        socket.bind("127.0.0.1:0".parse().unwrap()).unwrap();
        let addr = socket.local_addr().unwrap();
        let _listener = socket.listen(0).unwrap();
        let mut fillers = Vec::new();
        while let Ok(Ok(stream)) =
            tokio::time::timeout(Duration::from_millis(300), TcpStream::connect(addr)).await
        {
            fillers.push(stream);
            assert!(fillers.len() < 64, "accept queue never filled");
        }
        // The race's own budget (deadline + one hedge delay) passes without
        // resolving; only the outer timeout ends it.
        let deadline = Duration::from_millis(1500);
        let budget = deadline + private_tun::connect_hedge::HEDGE_DELAY;
        let sock = make_socket(addr, None).unwrap();
        let outer = tokio::time::timeout(
            budget + Duration::from_millis(500),
            connect_hedged(sock, addr, None, None, deadline),
        )
        .await;
        assert!(outer.is_err(), "race budget must defer to the outer timeout");
    }

    static TARGET_TCP_COUNTER_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

    #[tokio::test]
    async fn target_dial_keeps_active_policy_and_maps_netns_permission_to_other() {
        let _counter_guard = TARGET_TCP_COUNTER_LOCK.lock().await;
        crate::test_util::ensure_global_process_shared_info();
        let _ = private_tun::net_ns::init_home_ns();

        let bind_cfg = Arc::new(zfw_common::network_config::BindConfig {
            bind_addr_list: None,
            udp_siso: None,
            all_if_addresses: Arc::new(Vec::new()),
        });

        // 1. 底层 netns / socket 权限错误（EPERM / EACCES / PermissionDenied）与原生 EAFNOSUPPORT
        //    在目标拨号路径必须记 Other，不能混入 Policy / AddressFamily
        let perm_err = std::io::Error::new(
            std::io::ErrorKind::PermissionDenied,
            "setns /var/run/netns/wg0: Operation not permitted (os error 1)",
        );
        let observed = Some(shared_crate::cached_connect::classify_target_io(&perm_err));
        let conn_res: Result<(), RealyTcpError> = Err(RealyTcpError::RemoteConnectFailed(perm_err));
        assert_eq!(
            target_tcp_outcome(&conn_res, observed),
            Outcome::Fail(FailKind::Other)
        );
        assert_eq!(
            target_tcp_outcome(&conn_res, None),
            Outcome::Fail(FailKind::Other)
        );

        let row_now = || private_tun::conn_outcome::snapshot().rows[ConnRow::TargetTcp as usize].clone();

        // 2. 私网 IP 主动策略拒绝（allow_private_ip = false）→ TargetTcp 记 Policy
        let before = row_now();
        let priv_target = Address::Socket("10.0.0.1:80".parse().unwrap());
        let priv_selector = ServerSelector::Dynamic(priv_target, "10.0.0.1:80".into());
        let res = connect_to_remote_with_preference(&priv_selector, None, None, None, false, None).await;
        assert!(res.is_err());
        let after = row_now();
        assert_eq!(
            after.fail[FailKind::Policy as usize] - before.fail[FailKind::Policy as usize],
            1,
            "private IP rejection must still record FailKind::Policy"
        );
        assert_eq!(
            after.fail[FailKind::Other as usize] - before.fail[FailKind::Other as usize],
            0
        );

        // 3. 出站防火墙主动策略拒绝（OutboundFilter 过滤清空候选）→ TargetTcp 记 Policy
        let before = row_now();
        let fw_filter: private_tun::client::OutboundFilter = Arc::new(|sa, _| {
            Err(private_tun::client::OutboundReject::new(
                *sa,
                Some(9),
                "blocked-by-outbound-fw",
            ))
        });
        let fw_net_cfg = NetworkConfig::new(
            None,
            None,
            bind_cfg.clone(),
            None,
            None,
            None,
            Some(fw_filter),
        );
        let pub_target = Address::Socket("203.0.113.9:443".parse().unwrap());
        let pub_selector = ServerSelector::Dynamic(pub_target.clone(), "203.0.113.9:443".into());
        let res = connect_to_remote_with_preference(
            &pub_selector,
            None,
            Some(&fw_net_cfg),
            None,
            true,
            None,
        )
        .await;
        assert!(res.is_err());
        let after = row_now();
        assert_eq!(
            after.fail[FailKind::Policy as usize] - before.fail[FailKind::Policy as usize],
            1,
            "outbound firewall rejection must still record FailKind::Policy"
        );
        assert_eq!(
            after.fail[FailKind::Other as usize] - before.fail[FailKind::Other as usize],
            0
        );

        // 4. 主动地址族限制（IPv6 出口绑定 IP 访问 IPv4 目标）→ TargetTcp 记 AddressFamily
        let before = row_now();
        let v6_out_cfg = NetworkConfig::new(
            Some("2001:db8::1".parse().unwrap()),
            None,
            bind_cfg.clone(),
            None,
            None,
            None,
            None,
        );
        let res = connect_to_remote_with_preference(
            &pub_selector,
            None,
            Some(&v6_out_cfg),
            None,
            true,
            None,
        )
        .await;
        assert!(res.is_err());
        let after = row_now();
        assert_eq!(
            after.fail[FailKind::AddressFamily as usize]
                - before.fail[FailKind::AddressFamily as usize],
            1,
            "active outbound IP family mismatch must still record FailKind::AddressFamily"
        );

        // 5. 确定性注入 netns/socket PermissionDenied（EPERM）与 EAFNOSUPPORT 经过完整拨号路径 → 记 Other
        const TARGET_INJECT_NS: &str = "zfc-injected-netns-906";
        let ns_cfg = NetworkConfig::new(
            None,
            Some(TARGET_INJECT_NS.to_string()),
            bind_cfg.clone(),
            None,
            None,
            None,
            None,
        );
        #[cfg(target_os = "linux")]
        const EAFNOSUPPORT: i32 = 97;
        #[cfg(target_os = "macos")]
        const EAFNOSUPPORT: i32 = 47;
        #[cfg(windows)]
        const EAFNOSUPPORT: i32 = 10047;
        fn inject_eperm(name: &str) -> std::io::Error {
            std::io::Error::new(
                std::io::ErrorKind::PermissionDenied,
                format!("setns /var/run/netns/{name}: Operation not permitted (os error 1)"),
            )
        }
        fn inject_eafnosupport(_name: &str) -> std::io::Error {
            std::io::Error::from_raw_os_error(EAFNOSUPPORT)
        }
        for (inject, expect_eperm) in [
            (inject_eperm as InjectedNetnsErrorFn, true),
            (inject_eafnosupport as InjectedNetnsErrorFn, false),
        ] {
            let inject_guard = NetnsInjectGuard::install(TARGET_INJECT_NS, inject);
            let before = row_now();
            let res = connect_to_remote_with_preference(
                &pub_selector,
                None,
                Some(&ns_cfg),
                None,
                true,
                None,
            )
            .await;
            let hits = inject_guard.hits();
            drop(inject_guard);
            assert!(
                hits >= 1,
                "netns error injector must be hit at least once (got {hits})"
            );
            let err = res.expect_err("injected netns failure must fail connect");
            match &err {
                RealyTcpError::RemoteConnectFailed(io_err) if expect_eperm => {
                    assert_eq!(
                        io_err.kind(),
                        std::io::ErrorKind::PermissionDenied,
                        "expected injected PermissionDenied, got {io_err:?}"
                    );
                }
                RealyTcpError::RemoteConnectFailed(io_err) => {
                    assert_eq!(
                        io_err.raw_os_error(),
                        Some(EAFNOSUPPORT),
                        "expected injected EAFNOSUPPORT ({EAFNOSUPPORT}), got {io_err:?}"
                    );
                }
                other => panic!("expected RemoteConnectFailed from injected netns error, got {other:?}"),
            }
            let after = row_now();
            assert_eq!(
                after.fail[FailKind::Policy as usize] - before.fail[FailKind::Policy as usize],
                0,
                "underlying permission/EAFNOSUPPORT must never be classified as Policy"
            );
            assert_eq!(
                after.fail[FailKind::AddressFamily as usize]
                    - before.fail[FailKind::AddressFamily as usize],
                0,
                "underlying EAFNOSUPPORT must never be classified as AddressFamily"
            );
            assert_eq!(
                after.fail[FailKind::Other as usize] - before.fail[FailKind::Other as usize],
                1,
                "underlying permission/EAFNOSUPPORT must be recorded as FailKind::Other"
            );
        }

        // 6. Linux 下真实经过 NetNS::try_run（_root_ns 在非 root 下触发真实内核 EACCES/EPERM）→ 记 Other
        #[cfg(target_os = "linux")]
        {
            let ns_name = if unsafe { libc::geteuid() } != 0 {
                private_tun::net_ns::ROOT_NETNS_NAME.to_string()
            } else {
                "zfc-nonexistent-or-unprivileged-netns-906".to_string()
            };
            let before = row_now();
            let bad_ns_cfg = NetworkConfig::new(
                None,
                Some(ns_name),
                bind_cfg,
                None,
                None,
                None,
                None,
            );
            let res = connect_to_remote_with_preference(
                &pub_selector,
                None,
                Some(&bad_ns_cfg),
                None,
                true,
                None,
            )
            .await;
            let err = res.expect_err("netns dial must fail");
            if unsafe { libc::geteuid() } != 0 {
                assert!(
                    matches!(&err, RealyTcpError::RemoteConnectFailed(io_err) if io_err.kind() == std::io::ErrorKind::PermissionDenied),
                    "expected real kernel PermissionDenied from _root_ns (/proc/1/ns/net), got: {err:?}"
                );
            }
            let after = row_now();
            assert_eq!(
                after.fail[FailKind::Policy as usize] - before.fail[FailKind::Policy as usize],
                0,
                "netns dial failure must never be classified as FailKind::Policy"
            );
            assert_eq!(
                after.fail[FailKind::Other as usize] - before.fail[FailKind::Other as usize],
                1,
                "netns dial failure must be recorded as FailKind::Other"
            );
        }
    }
}

