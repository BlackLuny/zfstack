use cfg_if::cfg_if;
use num_traits::clamp;
use serde::{Deserialize, Serialize};
use socket2::{Domain, Protocol, Socket, Type};
use std::{
    net::SocketAddr,
    ops::{Deref, DerefMut},
};
use tokio::net::TcpStream as TokioTcpStream;

pub struct GuardFor<T, F: FnOnce(T)> {
    t: Option<T>,
    f: Option<F>,
}

impl<T, F: FnOnce(T)> GuardFor<T, F> {
    pub fn new(t: T, f: F) -> Self {
        Self {
            t: Some(t),
            f: Some(f),
        }
    }
    pub fn take(mut self) -> T {
        self.t.take().unwrap()
    }
}

impl<T, F: FnOnce(T)> Deref for GuardFor<T, F> {
    type Target = T;
    fn deref(&self) -> &Self::Target {
        self.t.as_ref().unwrap()
    }
}

impl<T, F: FnOnce(T)> DerefMut for GuardFor<T, F> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.t.as_mut().unwrap()
    }
}

impl<T, F: FnOnce(T)> Drop for GuardFor<T, F> {
    fn drop(&mut self) {
        if let (Some(t), Some(f)) = (self.t.take(), self.f.take()) {
            f(t);
        }
    }
}

/// 给所有走 TCP 转发的 socket 调一次：
/// - `TCP_NOTSENT_LOWAT = 256KB`：默认 ≈ SO_SNDBUF（常见 4MB），改到 256KB
///   可在高并发下大幅降低单连接 kernel 内存占用；relay 16KB 循环填得过来，
///   吞吐影响可忽略。可用环境变量 `TCP_NOTSENT_LOWAT`（字节）覆盖默认值以便
///   压测调参；设为 `0` 则跳过该 sockopt（用内核默认 = 关闭 not-sent low watermark）。
/// - `TCP_CONGESTION = bbr`：相比默认 cubic，BBR 在跨境 / 高 RTT / 有随机
///   丢包的链路上显著提升带宽利用率；内核没编译 BBR 时 setsockopt 失败、回退
///   到默认 cc。可用环境变量 `TCP_CONGESTION` 覆盖算法名（如 `cubic`/`reno`/`bbr2`），
///   设为 `off`/`none`/`default`（或空串）则不设置该 sockopt（用内核默认 cc）。
///
/// 整个函数可用环境变量 `TUNE_TCP_RELAY_SOCKET=0`（或 `false`/`off`/`no`/`disable`）
/// 整体关闭（全部 no-op），便于 A/B 压测对照。
///
/// Linux only；其它平台 no-op。所有 env 进程生命周期内只读一次（LazyLock 缓存）。
pub const TCP_NOTSENT_LOWAT_DEFAULT: u32 = 256 * 1024;

/// `TCP_NOTSENT_LOWAT` 的实际生效值（字节）。可用同名环境变量 `TCP_NOTSENT_LOWAT`
/// 覆盖 [`TCP_NOTSENT_LOWAT_DEFAULT`] 以便压测调参；解析失败 / 未设置时回退默认值，
/// 设为 `0` 表示跳过该 sockopt。进程生命周期内只读一次（LazyLock 缓存）。
#[cfg(target_os = "linux")]
static TCP_NOTSENT_LOWAT_BYTES: std::sync::LazyLock<u32> = std::sync::LazyLock::new(|| {
    std::env::var("TCP_NOTSENT_LOWAT")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(TCP_NOTSENT_LOWAT_DEFAULT)
});

/// 拥塞控制算法名（默认 `bbr`）。可用环境变量 `TCP_CONGESTION` 覆盖（如 `cubic`/`reno`/`bbr2`）
/// 以便压测对比；设为 `off`/`none`/`default`（或空串）→ `None` = 跳过该 sockopt（用内核默认 cc）。
/// 进程生命周期内只读一次（LazyLock 缓存）。
#[cfg(target_os = "linux")]
static TCP_CONGESTION_NAME: std::sync::LazyLock<Option<String>> =
    std::sync::LazyLock::new(|| match std::env::var("TCP_CONGESTION") {
        Err(_) => Some("bbr".to_string()),
        Ok(v) => {
            let name = v.trim().to_ascii_lowercase();
            if matches!(name.as_str(), "" | "off" | "none" | "default") {
                None
            } else {
                Some(name)
            }
        }
    });

/// 总开关：默认关闭。仅当设 `TUNE_TCP_RELAY_SOCKET=1`/`true`/`on`/`yes`/`enable` 时
/// [`tune_tcp_relay_socket`] 才生效，否则整体 no-op，便于 A/B 压测对照。
/// 进程生命周期内只读一次（LazyLock 缓存）。
#[cfg(target_os = "linux")]
static TUNE_RELAY_SOCKET_ENABLED: std::sync::LazyLock<bool> = std::sync::LazyLock::new(|| {
    matches!(
        std::env::var("TUNE_TCP_RELAY_SOCKET")
            .ok()
            .as_deref()
            .map(str::to_ascii_lowercase)
            .as_deref(),
        Some("1") | Some("true") | Some("on") | Some("yes") | Some("enable") | Some("enabled")
    )
});

#[cfg(target_os = "linux")]
pub fn tune_tcp_relay_socket(fd: &impl std::os::unix::io::AsRawFd) {
    if !*TUNE_RELAY_SOCKET_ENABLED {
        return;
    }
    let raw_fd = fd.as_raw_fd();

    let lowat: libc::c_int = *TCP_NOTSENT_LOWAT_BYTES as libc::c_int;
    if lowat > 0 {
        let rc = unsafe {
            libc::setsockopt(
                raw_fd,
                libc::IPPROTO_TCP,
                libc::TCP_NOTSENT_LOWAT,
                &lowat as *const _ as *const _,
                std::mem::size_of_val(&lowat) as libc::socklen_t,
            )
        };
        if rc < 0 {
            log::trace!(
                "set TCP_NOTSENT_LOWAT failed (non-fatal): {}",
                std::io::Error::last_os_error()
            );
        }
    }

    // best-effort 拥塞控制（默认 bbr，可经 TCP_CONGESTION env 覆盖 / 关闭）。
    // 不带 \0 因为 TCP_CONGESTION 用的是带长度的字符串。
    if let Some(cc) = TCP_CONGESTION_NAME.as_deref() {
        let rc = unsafe {
            libc::setsockopt(
                raw_fd,
                libc::IPPROTO_TCP,
                libc::TCP_CONGESTION,
                cc.as_ptr() as *const _,
                cc.len() as libc::socklen_t,
            )
        };
        if rc < 0 {
            log::trace!(
                "set TCP_CONGESTION={} failed (non-fatal, kernel may not have it): {}",
                cc,
                std::io::Error::last_os_error()
            );
        }
    }
}

#[cfg(not(target_os = "linux"))]
pub fn tune_tcp_relay_socket<S>(_fd: &S) {}

/// 连真实目标的出站 TCP 的接收缓冲上限（字节）。环境变量 `ZFW_TCP_TARGET_RCVBUF_KB`（KiB），
/// 未设置 / 解析失败 / `0` → `None` = 不设置（内核自动调优，默认行为）。
/// 进程生命周期内只读一次（LazyLock 缓存）。
#[cfg(target_os = "linux")]
static TARGET_RCVBUF_BYTES: std::sync::LazyLock<Option<libc::c_int>> =
    std::sync::LazyLock::new(|| {
        let kb: u64 = std::env::var("ZFW_TCP_TARGET_RCVBUF_KB").ok()?.trim().parse().ok()?;
        (kb > 0).then(|| (kb * 1024).min(libc::c_int::MAX as u64 / 2) as libc::c_int)
    });

/// 给「连真实目标」的出站 TCP 设接收缓冲上限（zfc #684），**默认关闭**。
///
/// 快源 → 慢下游时，这类 socket 的接收队列会被内核自动调优涨到 `tcp_rmem[2]`
/// （常见 25MB/条）；大量并发时会把整机 TCP 内存推过 `tcp_mem` 压力线，压力期内核
/// 对超均值的 socket 丢包，持续过久会让上游重传预算耗尽。设 `ZFW_TCP_TARGET_RCVBUF_KB`
/// 后每条连接的收向内存有上限。
///
/// - 压内存靠 `SO_RCVBUF`：单用 `TCP_WINDOW_CLAMP` 会被自动调优改写（内核
///   `tcp_rcv_space_adjust` 每次涨 `sk_rcvbuf` 都把 `window_clamp` 跟着重置，6.1 至
///   mainline 均如此）；`SO_RCVBUF` 锁定缓冲并关闭该 socket 的自动调优。
/// - 锁定后必须再设 `TCP_WINDOW_CLAMP`：本函数在连上**之后**调用，建连时
///   `tcp_init_buffer_space` 已按默认缓冲（`tcp_rmem[1]`≈85KB）把 `window_clamp` 定在
///   ≈43KB，平时靠自动调优往上抬；自动调优关掉后它就冻在 43KB，窗口永远到不了设定值
///   （真机 RTT 80ms 实测单流被压到 ~4Mbit/s）。缓冲已锁，clamp 不会再被改写。
///   取值 = `bytes`：内核按 2 倍记账，窗口约为记账值的一半。
/// - 先试 `SO_RCVBUFFORCE`（需 CAP_NET_ADMIN），否则 `SO_RCVBUF` 会被
///   `net.core.rmem_max`（默认 208KB）截断。
/// - 值要按 BDP 取数 MB 量级：过小会限住高 RTT 链路吞吐（256KB@200ms ≈ 10Mbit/s）。
/// - best-effort：失败只记一次 warn，连接照常可用。
#[cfg(target_os = "linux")]
pub fn tune_target_socket_rcvbuf(fd: &impl std::os::unix::io::AsRawFd) {
    let Some(bytes) = *TARGET_RCVBUF_BYTES else {
        return;
    };
    let set = |level: libc::c_int, opt: libc::c_int| {
        let rc = unsafe {
            libc::setsockopt(
                fd.as_raw_fd(),
                level,
                opt,
                &bytes as *const _ as *const _,
                std::mem::size_of_val(&bytes) as libc::socklen_t,
            )
        };
        (rc == 0).then_some(()).ok_or_else(std::io::Error::last_os_error)
    };
    let res = set(libc::SOL_SOCKET, libc::SO_RCVBUFFORCE)
        .or_else(|_| set(libc::SOL_SOCKET, libc::SO_RCVBUF))
        .and_then(|()| set(libc::IPPROTO_TCP, libc::TCP_WINDOW_CLAMP));
    if let Err(e) = res {
        static WARNED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
        if !WARNED.swap(true, std::sync::atomic::Ordering::Relaxed) {
            log::warn!("set target SO_RCVBUF/TCP_WINDOW_CLAMP={bytes} failed (non-fatal): {e}");
        }
    }
}

#[cfg(not(target_os = "linux"))]
pub fn tune_target_socket_rcvbuf<S>(_fd: &S) {}

#[allow(unused)]
pub fn create_socket(domain: Domain, use_mptcp: bool) -> Result<Socket, std::io::Error> {
    let s = {
        cfg_if! {
                if #[cfg(target_os = "linux")] {
                    use std::os::fd::FromRawFd;
                    fn create_for_linux(domain: Domain, use_mptcp: bool) -> Result<Socket, std::io::Error> {
                        if use_mptcp {
                            let family = if domain == Domain::IPV4 {libc::AF_INET} else {libc::AF_INET6};
                            let fd = unsafe { libc::socket(family,libc::SOCK_STREAM,libc::IPPROTO_MPTCP) };
                            Ok(unsafe { Socket::from_raw_fd(fd) })
                        } else {
                            Socket::new(domain, Type::STREAM, Some(Protocol::TCP))
                        }
                    }
                    create_for_linux(domain, use_mptcp)?
                } else {
                    { let _ = use_mptcp; Socket::new(domain, Type::STREAM, Some(Protocol::TCP))? }
                }
        }
    };
    Ok(s)
}

#[derive(Debug, Serialize, Deserialize, Clone, Copy)]
pub enum SelectMode {
    Repeat,
    RoundRoubin,
    Fallback,
}

pub fn create_runtime(
    single_runtime: bool,
    default_runtime: bool,
) -> anyhow::Result<tokio::runtime::Runtime> {
    let core_num = std::thread::available_parallelism()?.get();
    let mut builder = if core_num > 1 && !single_runtime {
        let max_cores = if default_runtime { core_num } else { 4 };
        let mut builder = tokio::runtime::Builder::new_multi_thread();
        builder.worker_threads(clamp(core_num, 2, max_cores))
            .max_blocking_threads(clamp(core_num, 2, max_cores));
        builder
    } else {
        let mut builder = tokio::runtime::Builder::new_current_thread();
        builder.max_blocking_threads(2);
        builder
    };
    builder.enable_all();
    let registration = crate::runtime_diag::configure(&mut builder, crate::runtime_diag::RuntimeKind::Main);
    let runtime = builder.build()?;
    if core_num <= 1 || single_runtime { crate::runtime_diag::thread_started(registration.as_ref()); }
    crate::runtime_diag::attach(registration, runtime.handle());
    Ok(runtime)
}

pub async fn supports_ipv6(target: &str) -> bool {
    // 首先检查系统是否支持 IPv6
    if let Err(_) = Socket::new(Domain::IPV6, Type::STREAM, Some(Protocol::TCP)) {
        return false;
    }
    let addrs: Vec<SocketAddr> = match tokio::net::lookup_host(target).await {
        Ok(addrs) => addrs.collect(),
        Err(_) => return false,
    };

    for addr in addrs {
        if addr.is_ipv6() {
            // 创建一个具体的 IPv6 socket 来测试。这是 startup-time probe，
            // 必须快速 fallback——若 IPv6 路由黑洞，Linux 内核默认 ~127s
            // SYN 重传会拖死整个初始化流程。
            const IPV6_PROBE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(3);
            match tokio::time::timeout(IPV6_PROBE_TIMEOUT, TokioTcpStream::connect(addr)).await {
                Ok(Ok(_)) => return true,
                Ok(Err(e)) => {
                    log::info!("Failed to connect to IPv6 address {}: {}", addr, e);
                    return false;
                }
                Err(_) => {
                    log::info!(
                        "IPv6 probe to {} timed out after {:?}",
                        addr,
                        IPV6_PROBE_TIMEOUT
                    );
                    return false;
                }
            }
        }
    }
    false
}

pub fn print_size<T>(f: T, name: &str) -> T {
    log::trace!("{} size: {:?}", name, std::mem::size_of_val(&f));
    f
}

/// Default deadline for protocol handshakes (obfs / SOCKS5 / TLS / Shadow-TLS).
/// Keep low enough that a slow-loris peer cannot hold a worker task forever,
/// but high enough that a legitimate handshake over a slow link can finish.
pub const HANDSHAKE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(15);

/// Default deadline for short, infrequent protocol control / latency-response
/// frames (UdpConnect, TestLatencyResp, send_zero_chunk end-of-stream marker,
/// etc.). NOT for bulk data — those run in tight loops and rely on TCP
/// back-pressure plus per-session idle timeouts instead.
pub const PROTOCOL_SEND_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(10);
