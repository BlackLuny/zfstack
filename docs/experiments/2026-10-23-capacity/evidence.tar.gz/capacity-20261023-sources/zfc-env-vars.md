# 环境变量参考

> **速查**: 如果你在调试 zf-worker 行为，想通过环境变量调整参数但不确定有哪些可用、默认值是什么、它们之间有什么交互，看这篇。

---

## 连接与并发控制

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `REUSE_TCP` | `true` | bool | TCP 连接池复用开关 |
| `CONN_RETRY_SEM_PERMITS` | `256` | usize | 连接重试最大并发数（Semaphore） |
| `CONN_RETRY_REPLENISH_1_NUM_PER_SEC` | `100` | usize | 连接重试令牌桶每秒补充速率 |
| `CONN_RETRY_MAX_BURST` | `1024` | usize | 连接重试令牌桶最大突发 |
| `PORT_MEASURE_SEM_PERMITS` | `512` | usize | 端口测量最大并发数 |

**交互**: `CONN_RETRY_SEM_PERMITS`、`CONN_RETRY_REPLENISH_1_NUM_PER_SEC`、`CONN_RETRY_MAX_BURST` 三者共同配置 `ConnProtect` 速率限制器。`CONN_RETRY_SEM_PERMITS` 可被配置文件中的 `conn_retry_sem_permits` 字段覆盖。

## 缓冲区

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `DIRECT_UP_BUFFER_SIZE` | `4096` | bytes | 直连 TCP 中继上行缓冲 |
| `DIRECT_DOWN_BUFFER_SIZE` | `8192` | bytes | 直连 TCP 中继下行缓冲 |
| `ZFW_DIRECT_TCP_SPLICE` | `true`（仅 Linux） | bool | 无限速裸 TCP 直连达到 256 KiB 后尝试 splice；`false`/`0` 并重启恢复原 copy。过滤器须先放行，切换前排空缓冲；不支持或 pipe 资源不足自动回退，非 Linux 始终使用原 copy |
| `BUFFER_POOL_GLOBAL_BYTES` | `262144`（`64×4096`） | bytes | 进程全局 buffer pool **按字节**预算。每 size class 上限 = `clamp(BYTES/size, 8, 512)`（S3'）。默认使 4 KiB class 仍为历史 64 槽 |
| `BUFFER_POOL_TL_LIMIT` | `16` [1–4096] | usize | 每线程本地 pool 每 class 上限 |
| `COPY_BUFFER_IDLE_MS` | `500` [0–60000] | ms | S3'：拷贝缓冲空闲超过此时长归还池。`0` = 立即归还 |
| `COPY_BUFFER_EAGER_ACQUIRE` | `false` | bool | 保险丝：`true` 退回「`CopyBuffer::new` 即 acquire、不做 idle 归还」 |

### 连目标 TCP 的接收缓冲上限（`ZFW_TCP_TARGET_RCVBUF_KB`，#684）

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `ZFW_TCP_TARGET_RCVBUF_KB` | 未设置（=0，关闭） | KiB | 给「连真实目标」的出站 TCP 设 `SO_RCVBUF`（先 `SO_RCVBUFFORCE`，不受 `net.core.rmem_max` 限制）。zf-worker 直连出站、forwarder Hammer 落地、TOT 落地三处生效；worker 与 forwarder 各读自己进程的环境变量，需分别设置并重启 |

**为什么有这个开关**：Linux 默认对每条连接的接收缓冲做自动调优，快源站 → 慢下游时单条可涨到 `tcp_rmem` 上限（常见 25MB）。大量并发大下载时，整机 TCP 内存会被推过 `tcp_mem` 第二个值（压力线，单位页；8GB 机器约 488MB，1GB 机器约 50–60MB）。进入压力后，内核对占用超均值的 socket 丢包，压力持续过久会让上游重传退避或放弃，表现为下载长时间只进零星字节或被截断。短暂的压力（秒级）只造成少量重传，对使用无感知。主流工具（Xray、sing-box、haproxy、nginx）默认都不设置这类缓冲，本开关同样默认关闭，仅给小内存、高并发大流量节点按需开启。

**为什么不能只用 `TCP_WINDOW_CLAMP`**（Xray 的 `tcpWindowClamp`）：内核自动调优每次扩大接收缓冲时都会把 `window_clamp` 改回跟随缓冲大小（6.1 至 mainline 的 `tcp_rcv_space_adjust`/`tcp_rcvbuf_grow`），所以单用它压不住内存。本开关先用 `SO_RCVBUF` 锁定缓冲（同时关闭该 socket 的自动调优），再把 `TCP_WINDOW_CLAMP` 设为同一个值。后一步不可省：设置发生在连上之后，建连时内核已按默认缓冲把窗口上限定在约 43KB，自动调优关掉后没人再把它抬高（真机 RTT 80ms 下单流只剩约 4Mbit/s）。

**对吞吐的影响**：开启后，每条连接从目标方向收数据的速度上限约为 `设定值 ÷ RTT(本节点→目标)`（窗口约等于设定值；内核按 2 倍记账，含包开销）。上传方向（发往目标）不受影响。

| 设定值 | RTT 10ms | RTT 50ms | RTT 150ms | RTT 250ms |
|---|---|---|---|---|
| 1024（1MB） | ~800 Mbit/s | ~160 Mbit/s | ~53 Mbit/s | ~32 Mbit/s |
| 4096（4MB） | ~3.2 Gbit/s | ~640 Mbit/s | ~210 Mbit/s | ~130 Mbit/s |
| 8192（8MB） | ~6.4 Gbit/s | ~1.3 Gbit/s | ~430 Mbit/s | ~260 Mbit/s |

- 会限速的情况：单条大流量，且「本节点→目标」RTT 高、带宽大，上限低于实际瓶颈。例如落地离源站很远的单线程测速或大文件下载。
- 基本无影响的情况：源站离落地近（多数 CDN 场景 RTT 在十几 ms 以内）；瓶颈在下游（客户端带宽、跨境隧道），且上限高于瓶颈；多条并发的小流量。
- 自动调优关闭后，内存仍然是用多少占多少，不会预先占满设定值。

**取值与容量**：先看压力线 `cat /proc/sys/net/ipv4/tcp_mem`，取第二个值乘以 4KiB。内核按设定值的 **2 倍**记账（例如设 4096 时 `ss -m` 里显示 `rb8388608`），所以「2 × 设定值 × 同时积压的大流量连接数」应明显低于压力线。例如 8GB 机器的压力线约 488MB，64 条并发时 4096 已贴线，2048 才有余量。同时用上表确认单连接上限不低于你关心的目标带宽。本开关只管本进程连目标的 socket；源站与 worker 在同一台机器时，源站的发送缓冲也计入本机 TCP 内存，不在本开关控制范围内。二者冲突时（小内存节点、远距离源站），与其把值压得很小，不如调大 `net.ipv4.tcp_mem`（例如按内存 10%–20% 计算三个值）。是否进过压力可以看 `nstat -az TcpExtTCPMemoryPressures TcpExtTCPMemoryPressuresChrono`（次数与累计毫秒）。

**迁移**: `BUFFER_POOL_GLOBAL_LIMIT` **已废弃**（代码不再读取，设置了也静默失效）。请改用 `BUFFER_POOL_GLOBAL_BYTES`。旧默认 `LIMIT=64` 在 4 KiB class 上与 `BYTES=64×4096` 的 `clamp(64,8,512)=64` 碰巧相同；自定义旧值（如 128）升级后不会再生效。

## 分配器（jemalloc）

**产物线（先认产物再谈 RSS）**：
- `scripts/release-all.sh`：显式 `--jemalloc`，产物带 jemalloc，`MALLOC_CONF` 才生效。
- `scripts/build-musl.sh`：**默认关 jemalloc**（musl malloc），此时 `MALLOC_CONF` **空操作**。
- 真机 RSS 只能在同一产物线内比（历史：jemalloc 版 ~130–142 MB vs musl 版 ~80 MB，见 `docs/design/wireguard-inbound-memory.md`）。跨 allocator 对比无效。

**建议值只有一套**（S9' 收口；与三份 `install_zfc_worker*.sh` 注释一致，**不要另起一套**）：

```
MALLOC_CONF=dirty_decay_ms:1000,muzzy_decay_ms:0,narenas:2,background_thread:true,thp:never,lg_tcache_max:12,abort_conf:true
```

`dirty_decay_ms` 取 1000 而不是 0：decay=0 每次 free 立刻 `madvise(MADV_DONTNEED)`，数据面热路径多 purge + 缺页。`muzzy_decay_ms` 必须保持 0（muzzy 的 `MADV_FREE` 不降 RSS）。**`dirty_decay_ms` 的 0 / 1000 / 2000 待 U3 实测再调；`narenas` 是 CPU/内存权衡，不盲调。**

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `MALLOC_CONF` | 未设置（jemalloc 内置默认） | string | 仅 jemalloc 产物生效。建议值见上。unit 默认**不**写入，需 drop-in 显式加 |
| `JEMALLOC_STATS_PRINT` | 关 | bool (`1`/`true`/`yes`/`on`) | **显式**打开 accept 热路径 `print_stats()`（每次 accept **7 行** stdout）。**生产禁止全程开**；与 `MALLOC_CONF` **无关** |

**交互**:
- 若宿主机 `transparent_hugepage=always`，匿名堆易被提成 2 MiB 大页、RSS 虚高；优先把主机 THP 设为 `madvise`（`thp-madvise.service`），再考虑 `MALLOC_CONF`。
- **禁止**用 `MALLOC_CONF` 的有无去门控日志；stats 只认 `JEMALLOC_STATS_PRINT`。

**U3 取证（allocated / resident / retained）**：
- **不要**在线上高 CPS 全程开 `JEMALLOC_STATS_PRINT=1`（F28：每 accept 7 行，打爆 journal）。
- 做法：确认产物线是 jemalloc 后，在**空闲/低 CPS 测试实例**上短窗打开采几拍即关；或一次性启动带 `stats_print` 的 spare 进程打一份 dump。
- 读三个数：`allocated`（应用问过的）、`resident`（RSS 口径）、`retained`（arena 握着不还给内核的）。
- **`resident - allocated ≠ 未还内核量`**。差值含 dirty/muzzy、碎片、jemalloc 元数据、THP 对齐；「握着不还」更接近 `retained`。
- 只在同一产物线、同一 THP 设置下比前后 RSS。

## 延迟测量

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `HAMMER_CHAIN_LATENCY_MEASURE_METHOD` | `BySum` | enum | HammerChain 延迟测量方法：`sum`/`piped` |
| `ENABLE_LATENCY_TEST_LONG_CONN` | `true` | bool | 使用持久长连接做延迟测试 |
| `ENABLE_SPEED_TEST` | `false` | bool | Hammer 选择器中的速度测试（影响服务器选择） |

## 丢包惩罚系统

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `FWD_LATENCY_LOST_PENALTY_FACTOR` | `50.0` | f64 | 转发器丢包率 → 虚拟延迟惩罚的倍数（1%丢包 = 50ms） |
| `FWD_TO_TARGET_LATENCY_LOST_PENALTY_FACTOR` | `50.0` | f64 | 同上，用于转发器→目标这一段 |
| `FWD_LOST_RECOVERY_HALF_LIFE_SECS` | `600` [30-3600] | secs | 惩罚半衰期（多久减半） |

**交互**: 三者构成丢包惩罚评分系统。前两个决定惩罚严重程度，后一个决定恢复速度。

## HammerChain 路径选择

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `ZF_CHAIN_SUPPRESS_PATH_TTL_SECS` | `30` | secs | 失败路径 suppress 黑名单 TTL |
| `ZF_CHAIN_POLICY_CANDIDATE_OPT_ENABLED` | `true` | bool | 候选路径数量上限优化总开关 |
| `ZF_CHAIN_POLICY_CANDIDATE_CAP_FALLBACK` | `4` | usize | Fallback 策略候选上限 |
| `ZF_CHAIN_POLICY_CANDIDATE_CAP_BALANCE_RR_RANDOM` | `32` | usize | RR/Random/WRR 策略候选上限 |
| `ZF_CHAIN_POLICY_CANDIDATE_CAP_BALANCE_DOMAIN_FOLLOW` | `96` | usize | DomainFollow 策略候选上限 |

**交互**: `OPT_ENABLED=false` 时，后续三个 CAP 变量完全无效，所有策略使用 1024 上限。`BestLatency` 始终使用 1024，不受 CAP 影响。

## 协议实现

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `HAMMER_CHAIN_CHAIN_METHOD` | `New` | enum | 链路 TCP 流实现：`new`/`old` |
| `ENABLE_UDP_OVER_MULTI_TCP` | `false` | bool | UDP 多 TCP 聚合路径（实验性） |

**注意**: `HAMMER_CHAIN_CHAIN_METHOD` 未设置时默认 `New`，但设置了无法识别的值时回退到 `Old`（不是 `New`）。

## 并发限流补充（HammerChain 初始化）

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `HAMMER_CHAIN_INIT_SEM_PERMITS` | `1024` | usize | HammerChain 初始化最大并发数（Semaphore） |
| `HAMMER_CHAIN_INIT_REPLENISH_1_NUM_PER_SEC` | `512` | usize | HammerChain 初始化令牌桶每秒补充速率 |
| `HAMMER_CHAIN_INIT_MAX_BURST` | `2048` | usize | HammerChain 初始化令牌桶最大突发 |

## 延迟统计平滑（EWMA / Graph）

| 环境变量 | 默认值 | 范围 | 类型 | 作用 |
|---------|--------|------|------|------|
| `FWD_LATENCY_EWMA_ALPHA` | `0.125` | `[0.001, 1.0]` | f64 | 转发器延迟 EWMA 平滑系数 |
| `FWD_LATENCY_EWMA_BETA` | `0.25` | `[0.001, 1.0]` | f64 | 转发器延迟 EWMA 二阶系数 |
| `FWD_LATENCY_JITTER_WEIGHT` | `4.0` | `[0.0, 16.0]` | f64 | 转发器延迟抖动权重 |
| `GRAPH_JITTER_WEIGHT` | `1.5` | `[0.0, 8.0]` | f64 | 图算法边权重中的抖动权重 |
| `GRAPH_MIN_STABLE_TESTS` | `20` | `[1, 20]` | u64 | 图算法判定"稳定"所需最少测试次数（默认值恰为上限） |
| `GRAPH_RTTVAR_CAP_RATIO` | `0.3` | `[0.1, 2.0]` | f64 | 图算法 RTT 方差惩罚占比上限 |

## P2P / 直连探测节流（`ZFW_P2P_*` / `ZFW_FWD_*` / `ZFW_DIRECT_FWD_*`）

> 详细设计见 `docs/p2p-latency-soft-fail-design.md` §3.3。edge（fwd↔fwd）用 `ZFW_P2P_*`，worker→fwder 直连用 `ZFW_FWD_*`/`ZFW_DIRECT_FWD_*`。

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `ZFW_P2P_SOFT_TO_HARD_GRACE_SECS` | `120`（clamp 10-3600） | secs | P2P 软失败→硬失败的宽限期 |
| `ZFW_P2P_MIN_HARDEN_FAILURES` | `3`（clamp 1-100） | u32 | 判定硬失败所需最少连续失败次数 |
| `ZFW_FWD_SOFT_TO_HARD_GRACE_SECS` | `120`（clamp 10-3600） | secs | 同上，用于 worker→fwder 直连 |
| `ZFW_FWD_MIN_HARDEN_FAILURES` | `3`（clamp 1-100） | u32 | 同上 |
| `ZFW_P2P_PROBE_THROTTLE_ENABLED` | `true` | bool | P2P edge 探测节流总开关 |
| `ZFW_P2P_PROBE_BASE_RATE` | `0.10` | f64 | 探测基础概率 |
| `ZFW_P2P_PROBE_W_STALENESS` / `_W_TRAFFIC` / `_W_VOLATILITY` / `_LOST_BOOST` | `0.40` / `0.50` / `0.50` / `0.40` | f64 | 探测概率打分的各维度权重 |
| `ZFW_P2P_PROBE_TRAFFIC_HALFLIFE_SECS` | `300`（clamp 30-1800） | secs | 流量新鲜度半衰期 |
| `ZFW_P2P_PROBE_FORCE_AGE_HEALTHY_SECS` / `_LOST_SECS` | `540` / `300`（均 clamp 60-540） | secs | 健康/丢失状态下强制重探的最大间隔（540s 硬上限对齐 `detect_dead_nodes` 600s 新鲜度窗口，留 60s 余量） |
| `ZFW_P2P_PROBE_MIN_SAMPLES_FOR_STABILITY` | `5`（clamp 1-100） | u64 | 判定"稳定"所需最少样本数 |
| `ZFW_P2P_PROBE_MIN_PROBABILITY` | `0.05` | f64 | 探测概率下限 |
| `ZFW_P2P_PROBE_HIGH_LAT_THRESHOLD_US` | `400_000`（clamp 5万-500万） | us | 判定"高延迟稳定"边的阈值 |
| `ZFW_P2P_PROBE_HIGH_LAT_STABLE_CV_MAX` | `0.15` | f64 | 高延迟稳定判定的变异系数上限 |
| `ZFW_P2P_PROBE_HIGH_LAT_STABLE_PASSIVE_FACTOR` | `0.25` | f64 | 命中高延迟稳定后被动探测概率折减系数 |
| `ZFW_P2P_PROBE_FORCE_AGE_HIGH_LAT_STABLE_SECS` | `1500`（clamp 60-1800） | secs | 高延迟稳定边的强制重探间隔（可以比 healthy 更长，理由见源码注释） |
| `ZFW_DIRECT_FWD_PROBE_THROTTLE_ENABLED` | `true` | bool | self→fwder 直连探测节流开关（可独立 kill） |
| `ZFW_DIRECT_FWD_PROBE_MIN_PROBABILITY` | `0.25` | f64 | 直连探测概率下限（比 edge 更高，保首跳选路刷新频率） |
| `ZFW_P2P_SOURCE_THROTTLE_ENABLED` | `true` | bool | fwd→fwd 探测改为按 source 节流的开关（一源一批判定，非按边判定） |

**已知限制**：以上参数均定义在 `zf-worker/src/env_var.rs`，本表按该文件当前状态摘录；后续新增/调整建议在此处同步更新，避免再次积累成批遗漏。

## Hammer UDP 探测（`ZFW_UDP_*`，详见 `docs/design/hammer-udp-probe-selection.md`）

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `ZFW_UDP_NATIVE_PROBE_ENABLED` | `true` | bool | self→fwder 原生 UDP 探测总开关（决定该腿走 native 还是降级 UOT） |
| `ZFW_UDP_EGRESS_PROBE_ENABLED` | `true` | bool | fwder 对公网 UDP 出口探测总开关（STUN/DNS） |
| `ZFW_UDP_NATIVE_PROBE_INTERVAL_SECS` | `30`（clamp 5-600） | secs | 原生 UDP 探测间隔 |
| `ZFW_UDP_EGRESS_PROBE_INTERVAL_SECS` | `3600`（clamp 30-86400） | secs | egress UDP 探测间隔（服务器属性变化极少，默认 1 小时一次） |
| `ZFW_UDP_EGRESS_RETRY_FLOOR_SECS` | `300`（clamp 10-3600） | secs | egress 探测"尚无定论"时的短重试间隔 |

## FailoverGroup 紧急切换通道（`ZFW_FAILOVER_*`，详见 `docs/design/failover-urgent-error-channel.md`）

事实性故障（TOT session override / 其 recheck 产物）发生时，supervisor 会 arm 一段 burst：
tick 从 5s 降到 500ms，判死窗从 10s 降到 3s。**只压缩等待时长，不放宽证据**——
double-obs 仍要求第二次「有推进的」观测（Tier-2 recheck 实测）。回切（up 窗）完全不受影响。

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `ZFW_FAILOVER_URGENT_DOWN_WINDOW_SECS` | `3`（另 clamp 到 `1..=DOWN_WINDOW`） | secs | burst 期间的判死窗；永不长于普通窗（配错也只会更快，不会更慢） |
| `ZFW_FAILOVER_BURST_TICK_MS` | `500`（另 clamp 到 `100ms..=TICK`） | ms | burst 期间的 tick 周期；永不慢于普通 tick |
| `ZFW_FAILOVER_BURST_SECS` | `10`（clamp 1-600） | secs | 一次 wake / poll-edge 维持 burst + 短窗的时长 |
| `ZFW_FAILOVER_WAKE_THROTTLE_MS` | `500`（clamp 0-60000） | ms | 发送侧 wake 节流。**best-effort**：发送方不知道接收方是否真的 arm 了，被压掉的那条由 poll-edge（≤1 个普通 tick）兜底，不是正确性论证 |

已退役（#122）：`ZFW_FAILOVER_PROBE_TIMEOUT_MS`、`ZFW_FAILOVER_PROBE_CONCURRENCY` —— 旧 PortProbeDialer 空壳，代码不再读取；机群里若还挂着这两项可删。Tier2 超时仍走 `LATENCY_PROBE_TIMEOUT_MS`。

## 其它子系统旋钮（未逐条核实默认值，见文件自查）

以下变量分散在各子系统文件中定义（非 `zf-worker/src/env_var.rs` 集中管理），本次审计只核实了存在性与定义文件，默认值/交互关系请打开对应文件确认：

| 分类 | 环境变量（部分） | 定义位置 |
|------|-----------------|---------|
| WireGuard 调优 | `ZFW_WG_CC` / `ZFW_WG_BDP_RTT_MS` / `ZFW_WG_ZFSTACK_*` 等一组（`ZFW_WG_BRUTAL_DOWN_MBPS` 及旧 smoltcp `ZFW_WG_SOCK_*` 已退役） | `zf-worker/crates/zfw-wireguard/src/inbound/`，详见 [`project_wg_sock_buffer_autotune`]、[`project_wg_inbound_brutal_cc`] |
| SSH 入站握手限流 | `ZFW_SSH_HANDSHAKE_DEADLINE_SECS` / `ZFW_SSH_HANDSHAKE_GLOBAL_UNAUTH_MAX` / `ZFW_SSH_HANDSHAKE_PER_IP_*` | `zf-worker/src/protocol/inbound/ssh/auth.rs` |
| TOT | `ZFW_TOT_ACCEPT_QUEUE` / `ZFW_TOT_LATENCY_HEARTBEAT_PROBE` | `zf-worker/src/protocol/tot.rs` |
| 流量上报重发 | `ZFW_TRAFFIC_RESEND_BASE_SECS` / `ZFW_TRAFFIC_RESEND_CAP_SECS` | `zf-worker/src/traffic_report.rs` |
| ACK 合并帧 | `ZFW_ACK_COALESCE` | `zf-controler/src/worker/message_handler.rs`，见 [`project_traffic_ack_egress_tier1`] |
| DNS DoT/DoH 回退 | `ZFW_DNS_DOT_SERVERS` / `ZFW_DNS_DOH_SERVERS` / `ZFW_DNS_FALLBACK_ENABLED` / `ZFW_DNS_QUERY_TIMEOUT_MS` | `shared-crate/src/dns_fallback.rs`，见 [`project_dns_dot_doh_fallback`] |
| 蜜罐/探测采集 | `ZFW_PROBE_CAPTURE_MAX_CONCURRENT` / `ZFW_PROBE_CAPTURE_UDP_MAX_PER_SEC` | 见 [`project_inbound_probe_capture`] |
| 出向防火墙 | `ZF_OUTBOUND_FIREWALL`（总开关）/ `ZF_OUTBOUND_FIREWALL_DOMAIN_REFRESH_SECS` | `zf-worker/src/outbound_firewall/mod.rs`，见 [出向防火墙专题](README.md) |
| 出向 egress 探测统计 | `ZFC_EGRESS_PROBE_ENABLED` / `ZFC_EGRESS_LOST_RATE_THOLD` / `ZFC_EGRESS_LOST_STREAK_THOLD` / `ZFC_EGRESS_MIN_SAMPLES` / `ZFC_EGRESS_WINDOW_SIZE` / `ZFC_EGRESS_RESET_IDLE_SECS` / `ZFC_EGRESS_PROBE_INTERVAL_SECS` / `ZFC_EGRESS_PROBE_MIN_INTERVAL_SECS` | 多个 `zf-worker/src/protocol/**` 文件，见 [`project_single_egress_recovery_lag`] |
| 控制器/部署 | `ZFC_API_KEY` / `ZFC_AUTH_SERVER_URL` / `ZF_AUTH_SERVER_URL` / `ZFC_INSTANCE_ID` / `ZFC_GIT_HASH` / `ZFC_SCHEMA_ARTIFACT_SHA256` / `ZFC_ALLOW_SCHEMA_FINGERPRINT_MISMATCH` | `common/src/schema_version.rs` 等，见 [`project_zf_controler_deploy_schema_fingerprint_match`] |
| 其它 | `ZF_CTRL_PONG_DEADLINE_SECS` / `ZF_WRR_WEIGHT_REFRESH_INTERVAL_SECS` | 分散于 controller/hammer 相关文件 |

> 本节是这次审计发现的"文档完全缺失但代码里已存在"的一批变量（约 75 个 vs 此前文档收录的 26 个），先建立索引方便查找；逐条核实默认值/clamp 范围/交互关系是后续待办，不在本次范围内一次做完。

## 非 env_var.rs 中定义的变量

| 环境变量 | 默认值 | 类型 | 作用 | 定义位置 |
|---------|--------|------|------|---------|
| `DRAIN_TIMEOUT_SECS` | `300` | secs | 端口重建时旧连接排水超时 | `controller/port_manager.rs` |
| `GEOIP_DB_PATH` | `Country.mmdb` | path | GeoIP 数据库路径 | `platform/geoip.rs` |
| `ASN_DB_PATH` | `Asn.mmdb` | path | ASN 数据库路径（DB-IP ASN Lite MMDB 格式） | `platform/asn.rs` |
| `SHELL` | `/bin/bash` | path | 远程 shell 二进制 | `remote_shell.rs` |
| `INVOCATION_ID` | — | 存在性检查 | 检测是否在 systemd 下运行 | `upgrade.rs` |
| `REDUCE_PROBE` | `false` | bool | 概率性探测频率降低 | `shared-crate/src/probe_algo.rs` |

## 直连转发内存优化（S0'–S9'，2026-08）

> 设计：`docs/design/zf-worker-direct-forward-memory-cpu-optimization.md`。行为变更见 [direct-fwd-mem-opt-behavior](direct-fwd-mem-opt-behavior.md)。

### 连接统计表（S0' / S2'）

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `CONN_STATS_PAGE_LIMIT` | `2000` [100–10000] | usize | 面板连接统计 newest-first top-N；老 controller 不传 `limit` 时走此默认（fail-closed） |
| `CONN_STATS_MAX_PER_PORT` | `10000`（绝对上限 20000） | usize | 每端口 live 表明细 cap |
| `CONN_STATS_MAX_GLOBAL` | `100000`（绝对上限 200000，拍板 P1） | usize | 进程级 live 表总 cap |

### UDP 下行 idle 分档（S8'）

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `UDP_DOWN_IDLE_NO_RETURN_SECS` | `15` [1–86400] | secs | 未见有效回程时下行 task idle timeout（短档） |
| `UDP_DOWN_IDLE_SEEN_RETURN_SECS` | `300` [1–86400] | secs | 见过有效回程后的 idle（历史 300s） |

`seen_return` = 至少一个**非空且地址校验通过**的下行批。空批 / 伪造源不算；encrypt/send 失败仍算回程。不碰 `TtlCache`。打洞回程慢于短档、合法纯单向 UDP（syslog）会被短档摘掉——见行为变更页。

### 流量 outbox（S7-b）

| 环境变量 | 默认值 | 类型 | 作用 |
|---------|--------|------|------|
| `TRAFFIC_OUTBOX_BACKLOG_WARN` | `2048` | usize | 磁盘 outbox 活文件数（不含本轮年龄闸已删）超过此值打 warn。lazy-load 不删未 ACK 文件 |

## 废弃变量

| 环境变量 | 状态 |
|---------|------|
| `DIRTY_CLEAN_ADDRESS_CACHE` | 已删除（#126 / Z15-03）：定义后零读者，脏地址缓存走 gen/TTL |
| `BUFFER_POOL_GLOBAL_LIMIT` | **已废弃 / 迁移**到 `BUFFER_POOL_GLOBAL_BYTES`。代码不再读取，设置了静默失效 |
